
export const environment = {
  production: true,
  apiBase: 'http://dev-server:4200/app/',
  masterBase: 'https://localhost:59223/api/MasterScreens/',
  userManagementApiBase: 'https://onecdevintaks.cognizant.com/3601/login/',
  env: 'prod'
};
