export const environment = {
  production: false,
  apiBase: 'https://localhost:7085/',
  masterBase: 'https://localhost:7246/MasterMaintenance/',
  userManagementApiBase: 'https://localhost:7128/3601/Login/',
  env: 'dev',
};

// masterBase : 'https://localhost:59223/api/MasterScreens/',
// https://localhost:59360/ImmiWorld/UserManagement/
//https://localhost:7085
