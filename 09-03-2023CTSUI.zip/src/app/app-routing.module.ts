import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '', redirectTo: 'Master', pathMatch: 'full' },
  {
    path: 'Master',
    loadChildren: () =>
      import('./modules/master-maintenance/master-maintenance.module').then(
        (m) => m.MasterMaintenanceModule
      ),
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
