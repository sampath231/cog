export class MasterScreens {
  ScreenID: number = 0;
  ScreenName: string = '';
  SchemaName : string = '';
  PKey_ColumnName : string = '';
  Key_Datatype : string ='INT';
  IsCreated :  Boolean = false;
  IsActive: Boolean = true;
  CreatedBy: string = '';
  CreatedDate: Date = new Date();

  // constructor(){
  //   this.ScreenID =0;
  //   this.ScreenName = '';
  // }
}
