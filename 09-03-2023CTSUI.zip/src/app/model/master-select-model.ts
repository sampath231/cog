export interface mastersearch {

    SelectID: number;
    ApiEndPoint: string;
    KeyColumn: string;
    ValueColumn: string;
    SearchControl: string;
  
  }
  