

export class MasterScreenControl {

  Master_ScreenID: number;
  Control_Type_ID: number;
  Control_Name: string;
  Control_Value_Length: number;
  Control_Required: boolean;
  Control_ColumnType: string;
  AutoIncrement: string;
  Reference_Table: number;
  Reference_Column: number;
  IsCreated: boolean;
  IsActive: boolean;
  CreatedBy: string;
  CreatedDate: Date;

  constructor(Master_ScreenID: number, Control_Type_ID: number, Control_Name: string,
    Control_Value_Length: number, Control_Required: boolean, Control_ColumnType: string,
    AutoIncrement: string, Reference_Table: number, Reference_Column: number, IsCreated: boolean,
    IsActive: boolean, CreatedBy: string, CreatedDate: Date) {

    this.Master_ScreenID = Master_ScreenID;
    this.Control_Type_ID = Control_Type_ID;
    this.Control_Name = Control_Name;
    this.Control_Value_Length = Control_Value_Length;
    this.Control_Required = Control_Required;
    this.Control_ColumnType = Control_ColumnType;
    this.AutoIncrement = AutoIncrement;
    this.Reference_Table = Reference_Table;
    this.Reference_Column = Reference_Column;
    this.IsCreated = IsCreated;
    this.IsActive = IsActive;
    this.CreatedBy = CreatedBy;
    this.CreatedDate = CreatedDate;

  }


}
