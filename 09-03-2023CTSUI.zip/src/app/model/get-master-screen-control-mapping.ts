export class GetMasterScreenControlMapping {
  ScreenControl_MappingID: number = 0;
  Master_ScreenID: number = 0;
  Control_Type_ID: any = 0;
  Control_Name: string = '';
  Control_Required: boolean = false;
  Control_ColumnType: string = '';
  Control_ColumnDataType: string = '';
  Reference_Table: number = 0;
  Reference_Column: number = 0;
  IsCreated: boolean = false;
  IsActive: boolean = true;
}
