export class JsonMaster {
  Master_ScreenID: number = 0;
  jsonData: string = '';
  AssociateId: string = '2150102'
}
