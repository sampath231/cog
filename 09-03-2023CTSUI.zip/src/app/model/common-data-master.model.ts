export interface CommonDataMaster {
  DataKey : number;
  Datavalue: string;
}
