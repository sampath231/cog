export class UpdateJsonMaster {
  Master_ScreenID: number = 0;
  jsonData: string = '';
  AssociateId: string = '2150102';
  PrimaryKey: number = 0;
}
