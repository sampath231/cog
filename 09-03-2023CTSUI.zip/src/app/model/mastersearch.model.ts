export interface mastersearch {

  SearchControlID: number;
  MinLength: string;
  SearchControl: string;
  AutoFieldColumn: string;
  DepColumn: string;
  ApiUrl: string;

}


