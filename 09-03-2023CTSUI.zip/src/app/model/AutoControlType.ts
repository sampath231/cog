export interface AutoControlType
    {
        ControlName  :  any,
        ControlID  :  any

}
