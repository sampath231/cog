
import { ValidatorFn, Validators } from "@angular/forms";

export class samplemodel {
    countryId: number;
    countryName : string;
    countryShortName : string;
   
    


    constructor(countryId: number, countryName: string, countryShortName : string

        ) {
        this.countryId = countryId;
        this.countryName = countryName;
        this.countryShortName = countryShortName;
        
        
        
      }
}
  