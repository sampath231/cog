import { ValidatorFn, Validators } from "@angular/forms";

export class MasterScreenControlConfig {

  id?: number;
  disabled?: boolean;
  label?: string;
  name: string;
  options?: any;
  required?: boolean;
  placeholder?: string;
  type: string;
  validation?: ValidatorFn[];
  value?: any;
  order?: any;
  formtooltip?: string;
  dateFormat?: string;
  pastDate?: string;
  featureDate?: string;

  referenceTable?:number;
  referenceColumn? : number;

  constructor(id: number, disabled: boolean, label: string, name: string, options: any,
    required: boolean, placeholder: string, type: string, value: string, order: number,
    formtooltip: string, dateFormat: string, pastDate: string, featureDate: string,
    referenceTable?:number,referenceColumn?:number
  ) {
    this.id = id;
    this.disabled = disabled;
    this.label = label;
    this.name = name;
    this.options = options;
    this.required = required;
    this.placeholder = placeholder;
    this.type = type;
    this.value = value;
    this.order = order;
    this.formtooltip = formtooltip;
    this.dateFormat = dateFormat;
    this.pastDate = pastDate;
    this.featureDate = featureDate;

    if (required) {
      this.validation = [Validators.required];
    } else {
      this.validation = [];
    }

    this.referenceTable = referenceTable;
    this.referenceColumn = referenceColumn;
  }
}
