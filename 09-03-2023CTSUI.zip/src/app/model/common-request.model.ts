export class RequestModel {
  optionType: string = "";

}
