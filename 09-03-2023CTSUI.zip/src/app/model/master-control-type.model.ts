export interface MasterControlType {
  ControlID: any;
  ControlName: string;
  ControlToolTip: string;
  CreatedBy: string;
  CreatedDate: Date;
  ModifiedBy: string;
  ModifiedDate: Date
}
