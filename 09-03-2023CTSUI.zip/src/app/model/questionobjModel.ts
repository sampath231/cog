import { ValidatorFn, Validators } from "@angular/forms";

export class questionObj{
    id: number;
    countryName : string;
    visaType : string;
    section: string;
    value: string;
    key: string;
    label: string;
    validation : ValidatorFn[];
    order: number;
    controlType: string;
    type: string;
    name : string;
    required: boolean;
    options? : any;
    disabled?: boolean;
    formtabname? : string;
    tableData? :any;
    formtooltip? : string;
    dateFormat? : string;
    pastDate? : string;
    featureDate? : string
    constructor(id: number, countryName: string, visaType : string, section: string,
        value: string, key: string, label: string,required: boolean, order: number,controlType: string,
        type: string,name :string,options? : any,disabled?:boolean,formtabname? : string,tableData? :any,
        formtooltip?:string,dateFormat?:string, pastDate?:string,  featureDate?:string
        ) {
        this.id = id;
        this.countryName = countryName;
        this.visaType = visaType;
        this.section = section;
        this.value = value;
        this.key =key;
        this.label =label;
        this.order = order;
        this.controlType = controlType;
        this.type = type;
        this.name = name;
        this.required = required;
        if(required){
          this.validation = [Validators.required];
        }else{
          this.validation = [];
        }

        this.options = options;

        this.disabled = disabled;

        this.formtabname = formtabname;
        this.tableData = tableData;
        this.formtooltip = formtooltip;
        this.dateFormat = dateFormat;
        this.pastDate = pastDate;
        this.featureDate = featureDate;


      }
}
