import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AppConstants } from '../../app/globals/app-constants';
import { CommonDataMaster } from '../../app/model/common-data-master.model';
import { MasterScreenControlMapping } from '../../app/model/master-screen-control-mapping.model';
import { mergeMap, Observable } from 'rxjs';
import { environment } from '../../environments/environment';


@Injectable({
  providedIn: 'root'
})
export class CommonService {
  masterBase = environment.masterBase;
  apiBase = environment.apiBase;
  baseUrl = environment.apiBase;
  httpClient: any;

  constructor(private http: HttpClient) { }


  getApi(method: string): any {
    return this.http.get(`${this.baseUrl}` + method);
  }

  postApi(postData: any, method: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
      })
    };
    return this.http.post<any>(this.baseUrl + method, postData, httpOptions);
  }

  getReferenceTableDataMaster(masterScreenControlMapping:MasterScreenControlMapping): Observable<CommonDataMaster[]> {
    return this.http.get<CommonDataMaster[]>(this.apiBase + AppConstants.API_GetReferenceTableDataMaster
      + '?reftable=' + masterScreenControlMapping.Reference_Table
      + '&refColumn=' + masterScreenControlMapping.Reference_Column);
  }

  
  

  // getApiDataByApi(url): any {
  //   return this.http.get(url);
  // }

  // getMastersearchdata(id){
  //   return this.http.get('https://localhost:7023/api/AutoSave/GetMasterSearchFieldConfigById?id='+ id )
  // }

  
  // PostMasterdata(data:any){
  //   const httpOptions = {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/json',
  //       'Access-Control-Allow-Origin': '*',
  //       'Access-Control-Allow-Headers': 'Content-Type',
  //       'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
  //     })
  //   };
  //   return this.http.post<any>('https://localhost:7023/api/AutoSave/SaveMasterSearchFieldConfig',data, httpOptions);
  // }
  // getcontroltype()
  // {
  //    var controltype="AutoSearch"
  //    const httpOptions = {
  //     headers: new HttpHeaders({
  //       'Content-Type': 'application/json',
  //       'Access-Control-Allow-Origin': '*',
  //       'Access-Control-Allow-Headers': 'Content-Type',
  //       'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
  //     })
  //   };
  //   return this.http.get<any>('https://localhost:7023/api/AutoSave/GetMasterControlType?controltype='+controltype, httpOptions);

  // }

}
