import { Injectable, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Injectable({
  providedIn: 'root',
})
export class CommonServiceUi {

  associateId = 123456;
  firstName = 'Virat';
  lastName = 'Kohli';
  fullName = `${this.firstName} ${this.lastName}`;
  showCarousel = true;
  greetingText = '';
  date = new Date();
  gmApproved = [];
  associateDetails = new FormGroup({
    associateId: new FormControl({ value: this.associateId, disabled: true }),
    name: new FormControl({ value: this.fullName, disabled: true }),
    travelCountry: new FormControl('Associate'),
    requestPurpose: new FormControl('Associate'),
    proposedDetails: new FormGroup({
      plannedTravelStartDate: new FormControl('1/7/2023'),
      plannedTravelEndDate: new FormControl(),
      proposedProjectDetails: new FormGroup({
        billabilityType: new FormControl('Billable'),
        projectId: new FormControl(12345678),
        projectName: new FormControl(),
        travelJd: new FormControl(),
        onsiteManagerId: new FormControl(),
      }),
    }),
    currentProjectDetails: new FormGroup({
      projectId: new FormControl(),
      projectName: new FormControl(),
      manager: new FormControl(),
    }),
  });
  carouselDatas = [
    {
      image: '../assets/images/carousel-1.png',
      heading: 'Lorem Ipsum - 1',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sed iaculis libero. Proin vel nisi leo..',
    },
    {
      image: '../assets/images/carousel-1.png',
      heading: 'Lorem Ipsum - 2',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sed iaculis libero. Proin vel nisi leo..',
    },
    {
      image: '../assets/images/carousel-1.png',
      heading: 'Lorem Ipsum - 3',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nam sed iaculis libero. Proin vel nisi leo..',
    },
  ];
  tileDescriptions = [
    {
      name: 'profile',
      description:
        'This profile has all your personal and immigration related details. Click the button and navigate to your profile',
      path: '/Profile',
      btnName: 'Profile',
    },
    {
      name: 'nomination',
      description:
        'To start your official travel,the important step is nomination. So why to wait? Lets start your journey!',
      path: '/Nomination',
      btnName: 'Go Nomination',
    },
    {
      name: 'dashboard',
      description:
        'Here we have your complete case details. Click to know more.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam bibendum',
      path: '/View-Dashboard',
      btnName: 'View Dashboard',
    },
    {
      name: 'profile',
      description:
        'This profile has all your personal and immigration related details. Click the button and navigate to your profile',
      path: '/profile',
      btnName: 'Profile',
    },
    {
      name: 'nomination',
      description:
        'To start your official travel,the important step is nomination. So why to wait? Lets start your journey!',
      path: '/nomination',
      btnName: 'Go Nomination',
    },
    {
      name: 'dashboard',
      description:
        'Here we have your complete case details. Click to know more.Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam bibendum',
      path: '/View-Dashboard',
      btnName: 'ViewDashboard',
    },
  ];
  gmNomination = [
    { nominationId: 'GMT12345', associateName: 'Alex Smith', associateId: 123456, countryOfTravel: 'USA', requestPurpose: 'Lorem ipsum', nominationDate: '24/08/2011', nominatiorNameID: 'Lorem ipsum (123456)', failureReason: 'Lorem ipsum' }
  ]
  notificationList = [
    {
      title: 'Lorem Ipsum1',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie, dictum est a, mattis tellus. Sed dignissim, metus nec',
    },
    {
      title: 'Lorem Ipsum2',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie, dictum est a, mattis tellus. Sed dignissim, metus nec'
    },
    {
      title: 'Lorem Ipsum3',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie, dictum est a, mattis tellus. Sed dignissim, metus nec'
    },
    {
      title: 'Lorem Ipsum4',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie, dictum est a, mattis tellus. Sed dignissim, metus nec'
    },
    {
      title: 'Lorem Ipsum',
      description:
        'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam eu turpis molestie, dictum est a, mattis tellus. Sed dignissim, metus nec'
    },
  ]
  constructor() { }
  getGreetingText() {
    let time = this.date.getHours();
    if (time >= 12 && time <= 16) {
      return (this.greetingText = 'Good Afternoon');
    } else if (time >= 17) {
      return (this.greetingText = 'Good Evening');
    } else {
      return (this.greetingText = 'Good Morning');
    }
  }
}
