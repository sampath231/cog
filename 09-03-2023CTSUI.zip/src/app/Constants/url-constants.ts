export class UrlConstants {
  public static URL_MasterSettings: string = '/Master';
  public static URL_MasterData: string = '/Master/MasterData';
}
