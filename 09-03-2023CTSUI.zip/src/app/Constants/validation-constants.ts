export class ValidationConstants {
  public static Required_Const: string = 'This field is Mandatory';
  public static Add_Alert_Const: string = 'Data Added Successfully!!';
  public static Update_Alert_Const: string = 'Data Updated Successfully!!';
  public static Controls_Alert_Const: string = 'Controls Added. Columns Created.';
}
