export class GlobalConstants {

  /* Syncfusion License Key
     Date Received : 02-Feb-2023
     Version: 20.4.0.38  */
  public static Syncfusion_License: string = 'ORg4AjUWIQA/Gnt2VVhkQlFadVdJXGFWfVJpTGpQdk5xdV9DaVZUTWY/P1ZhSXxQdkZjWH1ddXZQQmleVkY=';
}
