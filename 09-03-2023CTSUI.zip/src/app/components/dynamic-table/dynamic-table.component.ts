import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { Route, Router } from '@angular/router';
import { CommandModel, EditEventArgs, EditSettingsModel, GridComponent, IEditCell, ResizeService, ToolbarItems } from '@syncfusion/ej2-angular-grids';
import { DataManager, Query } from '@syncfusion/ej2-data';
import { UrlConstants } from '../../Constants/url-constants';
import { ValidationConstants } from '../../Constants/validation-constants';
import { MasterScreenControlMapping } from '../../model/master-screen-control-mapping.model';
import { UpdateJsonMaster } from '../../model/update-json-master';
import { MasterMaintenanceService } from '../../modules/master-maintenance/master-maintenance.service';
import { CommonService } from '../../services/common.service';

@Component({
  selector: 'app-dynamic-table',
  templateUrl: './dynamic-table.component.html',
  styleUrls: ['./dynamic-table.component.css'],
  providers: [ResizeService],
})
export class DynamicTableComponent implements OnInit {
  alertVal = false;
  editType: string = '';
  boolPK: any = '';
  editParams: IEditCell;
  editControls: any = [];
  dataControls: any = [];
  dropdowndata: any = []
  dropdownValues: object[] = [];
  tempvar: any = []
  controls: any = [];
  field: Object = { text: 'any', value: 'any' }
  public editSettings: EditSettingsModel;
  public toolbar: ToolbarItems[];
  public boolParams: IEditCell;
  tableHeaders: any;
  dataFlag = false;
  tableData: any;
  screenData: any = [];
  screenID: any;
  public flag = true;
  cols: any = [];
  updateJson: UpdateJsonMaster = new UpdateJsonMaster();
  @Input('ScreenId') set _id(value: number) {
    this.screenID = value;
    if (this.route.url === UrlConstants.URL_MasterData) {
      if (this.screenID != undefined) {
        this.getScreenControlByScreenId(this.screenID)
      }
    }
  }
  @Input('TableData') set _data(value: any[]) {
    this.tempvar = value;
    if (this.route.url === UrlConstants.URL_MasterSettings) {
      this.tableData = value;
      this.getTableHeaders();
    }
  }

  editParams1: IEditCell = {
  params: {
      allowFiltering: true,
      dataSource: new DataManager(this.dropdownValues),
      fields: { text: 'dataName', value: 'dataName' },
    query: new Query(),
    actionComplete: () => false
  }
};
  @ViewChild('grid') public grid: GridComponent;

  controlListstoConfigure: any
  masterScreenMapping: MasterScreenControlMapping = {
    Master_ScreenID: 0,
    Control_Type_ID: 2,
    Control_Name: '',
    Control_Value_Length: 0,
    Control_Required: false,
    Control_ColumnType: '',
    AutoIncrement: '',
    Reference_Table: 0,
    Reference_Column: 0,
    IsCreated: false,
    IsActive: false,
    CreatedBy: '',
    CreatedDate: undefined,
    ScreenControl_MappingID: 0,
    Control_ColumnDataType: '',
  };

  constructor(public service: CommonService, public route: Router, public masterService: MasterMaintenanceService) { }

  dataBound(args) {
    let items = [];
    this.tableData.forEach((el) => {
      items = el;
    });
    let properties: string[] = Object.getOwnPropertyNames(items);
    this.grid.autoFitColumns(properties);
    this.grid.height = 200;
  }

  ngOnInit(): void {

    if (this.route.url === UrlConstants.URL_MasterData) {
      this.editSettings = { allowEditing: true, mode: 'Dialog' };
      this.toolbar = ['Edit'];
    }
    this.getAllDataControls();
  }

  getAllDataControls() {
    this.masterService
      .getMasterDataControls()
      .subscribe((data) => {
        this.dataControls = data;
      });
  }

  getScreenControlByScreenId(id: any) {
    this.dropdownValues = [];
    this.masterScreenMapping.Master_ScreenID = id;
    this.masterService.getScreenControlsByScreenID(this.masterScreenMapping).subscribe(res => {
      this.screenData = res;
      this.screenData.forEach(ele => {
        let name = ele.Control_Name;
        let value = ele.Control_Type_ID;
        this.controls.push({ Control_Name: name, Control_Id: value })

        this.dataControls.forEach(element => {
          if (ele.ScreenControl_MappingID == element.ScreenControlID) {
            this.dropdowndata = element.DropdownDataSource.split(',');
            this.dropdowndata.forEach(dataele => {
            this.dropdownValues.push({ dataName:dataele, dataValue:dataele })
            })
          }
        })

      });
      this.tableData = this.tempvar;
      this.getTableHeaders();
    });

  }

  ConfigureScreenControlsByScreenID(id: any) {
    switch (id) {
      case 1: // dropdown
        this.editType = 'dropDownEdit'
        this.editParams = {
          params: {
            allowFiltering: true,
            dataSource: new DataManager(this.dropdownValues),
            fields: { text: 'dataName', value: 'dataValue' },
            query: new Query(),
            actionComplete: () => false
          }
        };
        break;

      case 2: // textbox
        this.editType = 'defaultEdit'
        this.editParams = {}
        break;

      case 3: // Radiobutton
        this.editType = 'booleanEdit'
        this.editParams = {
          params: {
            checked: true,
          }
        };
        break;

      case 7: // DatePicker
        this.editType = 'datePickerEdit'
        this.editParams = {
          params: {
            format: 'dd.MM.yyyy',
          }
        };
        break;
      default:
        this.editType = ''
        this.editParams = {}
        break;
    }
  }

  getTableHeaders() {
    this.tableHeaders = [];
    this.cols = [];
    if (this.route.url == UrlConstants.URL_MasterSettings) {
      this.tableHeaders = Object.keys(this.tableData[0]);
      this.tableHeaders.forEach((element) => {
        this.cols.push({ field: element, header: element });
      });
    }
    else if (this.route.url == UrlConstants.URL_MasterData) {
      if (this.tableData && this.tableData.length > 0) {
        this.tableHeaders = Object.keys(this.tableData[0]);
        this.tableHeaders.forEach((element) => {   //ID
          if (this.tableHeaders.indexOf(element) == 0) {
            this.boolPK = true;
          }
          this.controls.forEach(control => {      //Section_Type
            if (control.Control_Name == element) {
              this.ConfigureScreenControlsByScreenID(control.Control_Id);
            }
          });
          this.cols.push({ field: element, header: element, edit: this.editType, editParam: this.editParams, bool: this.boolPK });  //field: Id ,edit: ''
          this.editType = '';
          this.editParams = {};
          this.boolPK = '';

        });
      }
    }
    this.dataFlag = true;
  }

  actionBegin(args: any): void {
    this.alertVal = false;
    if (args.requestType === 'save' && args.primaryKey != null) {
      let keyname = args.primaryKey[0]
      this.updateJson.AssociateId = sessionStorage.getItem("AssociateId");
      this.updateJson.PrimaryKey = args.data[keyname];
      this.updateJson.Master_ScreenID = this.screenID;
      this.updateJson.jsonData = JSON.stringify(args.data);
      this.masterService.updateScreenControlsData(this.updateJson);
    }
  }

}
