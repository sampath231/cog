export class DynamicItem {
  constructor(public component: any, public data: any) { }
}
