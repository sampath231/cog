export interface DynamicComponent {
  data: {
    errorMessages: Array<string>;
  };
}
