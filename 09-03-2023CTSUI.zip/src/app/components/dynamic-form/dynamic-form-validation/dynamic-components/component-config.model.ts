export interface ComponentConfig {
  componentType: 'validation';
  dynamicComponentType: any;
  data: any;
}
