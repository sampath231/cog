/* eslint-disable no-useless-escape */
export const validationPatterns = {
  name: '^[A-Za-z\s]*$',
  address: '^[A-Za-z0-9_.\/&\s]*$'
};
