import { Pipe, PipeTransform } from '@angular/core';

@Pipe({name: 'productFilter'})
export class ProductFilterPipe implements PipeTransform {
  transform(products: any[], productType: string): any[] {
    debugger;
    if(sessionStorage.getItem("SelectedOption")){
      if(sessionStorage.getItem("SelectedOption") == "Country"){
        return products.filter(p => p.type == sessionStorage.getItem("SelectedOption"));
      }else{
        return products;
      }

    }else{
      return products;
    }
    
    
  }
}
