import { Component, OnInit } from '@angular/core';
import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';
import { FormGroup } from '@angular/forms';
@Component({
  selector: 'app-form-label',
  template: `
    <div 
      class="dynamic-field col"
      [formGroup]="group">
      <label class="col col-form-label" style="font-size: 20px;font-weight: 500;">{{ config.label }}</label>    
    </div>
  `,
  styleUrls: ['./form-label.component.scss']
})
export class FormLabelComponent implements Field {

  config!: FieldConfig;
  group!: FormGroup;

}
