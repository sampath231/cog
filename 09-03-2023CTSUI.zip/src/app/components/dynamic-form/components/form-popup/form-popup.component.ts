import { Component, Inject, ViewContainerRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ModalService } from 'src/app/Service/modal.service';
import { ControlService } from 'src/app/Service/control.service';

@Component({
  selector: 'app-form-popup',
  styleUrls: ['form-popup.component.scss'],
  template: `

      <button mat-raised-button style="margin-right: 5px;"  id="travel-details" class="btn btn-primary"(click)="TravelModal()">Add Prior Travel Details</button>
    
  `
})
export class FormPopupComponent implements Field {
  config!: FieldConfig;
  group!: FormGroup;


  constructor(
    public dialogRef: MatDialogRef<FormPopupComponent>, private modalService: ModalService,private service: ControlService) {

  }
  TravelModal(){
   debugger
    this.modalService.openModal('',true);
  }
}
