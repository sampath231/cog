import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../models/field-config.interface';
import { Field } from '../../models/field.interface';

@Component({
  selector: 'form-check' ,
  template: `
  <div class="dynamic-field form-check col-6"
      [formGroup]="group">
      <label>{{ config.label }}: &nbsp;&nbsp;&nbsp;</label>
      <ul class="list-group">
        <li class="list-group-item" *ngFor="let option of config.options">
           <input type="checkbox"
           [formControlName]="config.name" id="{{ config.name }}" [value]="option.id" />
           {{option.name}}
        </li>
      </ul>
    
  </div>
  `,
  styleUrls: ['./form-check.component.scss']
})
export class FormCheckComponent implements Field {

  config!: FieldConfig;
  group!: FormGroup;

}
