import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';

@Component({
  selector: 'form-table',
  template: `
    <div 
      class="dynamic-field col"
      [formGroup]="group">
      <!-- <label class="col col-form-label" style="font-size: 20px;font-weight: 500;">{{ config.label }}</label>     -->
      <dinamic-table [data]="config.tableData"></dinamic-table>
    </div>
  `
})
export class FormtableComponent implements Field {
  
  config!: FieldConfig;
  group!: FormGroup;
}
