import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';
import { CommonService } from '../../../../../app/services/common.service';
import { MasterScreenControlMapping } from '../../../../../app/model/master-screen-control-mapping.model';

@Component({
  selector: 'form-select',
  styleUrls: ['form-select.component.scss'],
  template: `
    <div class="dynamic-field row mb-3" [formGroup]="group">
      <label class="col-sm-2 col-form-label"
        >{{ config.label }} :<span
          *ngIf="config.required == true"
          style="color: red;"
          >*</span
        >
        &nbsp;&nbsp;&nbsp;</label
      >
      <div class="col-sm-6">

        <ejs-combobox 
          class="mx-2"
          width="250px"
          [fields]="fields"
          [formControlName]="config.name"
          [dataSource]="config.options"
          [placeholder]="config.placeholder"
        ></ejs-combobox>
      </div>
    </div>
  `,
})
export class FormSelectComponent implements Field {
  config!: FieldConfig;
  group!: FormGroup;

  public fields: Object;

  masterScreenMapping: MasterScreenControlMapping = {
    Master_ScreenID: 0,
    Control_Type_ID: 2,
    Control_Name: '',
    Control_Value_Length: 0,
    Control_Required: false,
    Control_ColumnType: '',
    AutoIncrement: '',
    Reference_Table: 0,
    Reference_Column: 0,
    IsCreated: false,
    IsActive: false,
    CreatedBy: '',
    CreatedDate: undefined,
    ScreenControl_MappingID: 0,
    Control_ColumnDataType: '',
  };

  constructor(private service: CommonService) {}
  ngOnInit() {
    this.masterScreenMapping.Reference_Table = this.config.referenceTable;
    this.masterScreenMapping.Reference_Column = this.config.referenceColumn;
    if (this.masterScreenMapping.Reference_Table != 0) {
      this.service
        .getReferenceTableDataMaster(this.masterScreenMapping)
        .subscribe((data) => {
          this.config.options = data;
          this.fields = { text: 'Datavalue', value: 'DataKey' }
        });
    }
  }
}
