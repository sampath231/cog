import { Component, OnInit } from '@angular/core';
import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';
import { FormGroup } from '@angular/forms';


@Component({
  selector: 'app-form-date-picker',
  template: `
        <div
class="dynamic-field row mb-3"
[formGroup]="group">
    <label> {{config.label}}:<span *ngIf="config.required == true"; style = "color:red;">*</span></label>
    <div class="col-sm-6" >
<input class="form-control" type="date" [formControlName]="config.name" required>
</div>
</div>
  `,
  styleUrls: ['./form-date-picker.component.scss']
})    
export class FormDatePickerComponent implements Field {

  config!: FieldConfig;
  group!: FormGroup;

  public today = new Date();


}

