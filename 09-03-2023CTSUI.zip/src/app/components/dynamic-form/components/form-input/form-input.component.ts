import { Component, ViewContainerRef } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';

@Component({
  selector: 'form-input',
  styleUrls: ['form-input.component.scss'],
  template: `
   <div
      class="dynamic-field row mb-3"
      [formGroup]="group">
      <label class="col-sm-2 col-form-label">{{ config.label }}:<span *ngIf="config.required == true" style="color: red;">*</span></label>
      <div class="col-sm-6 form-group">
      <input class="form-control"
      [title]="config.formtooltip"
      type="text" [attr.placeholder]="config.placeholder"
      [formControlName]="config.name"
      appFormControlValidation

      pattern="^[A-Za-z\s]*$"
      >
      <!-- Remove   validationMsgId={{config.id}} for quick fix -->
      </div>
    </div>
  `,
})
export class FormInputComponent implements Field {
  config!: FieldConfig;
  group!: FormGroup;
}
