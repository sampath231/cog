import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { SyncfusionModule } from '../../syncfusion.module';

import { DynamicFieldDirective } from './components/dynamic-field/dynamic-field.directive';
import { DynamicFormComponent } from './containers/dynamic-form/dynamic-form.component';
import { FormButtonComponent } from './components/form-button/form-button.component';
import { FormInputComponent } from './components/form-input/form-input.component';
import { FormSelectComponent } from './components/form-select/form-select.component';
import { FormRadioComponent } from './components/form-radio/form-radio.component';
import { FormCheckComponent } from './components/form-check/form-check.component';
import { FormLabelComponent } from './components/form-label/form-label.component';
import { FormFileUploadComponent } from './components/form-file-upload/form-file-upload.component';
import { ProductFilterPipe } from './filters/select-filter.pipe';
import { FormsModule } from '@angular/forms';
import { ErrorComponent } from '../dynamic-form/dynamic-form-validation//form-validation/error-component/error-component';
import { FormDatePickerComponent } from './components/form-date-picker/form-date-picker.component';

@NgModule({
  imports: [CommonModule, ReactiveFormsModule, FormsModule, SyncfusionModule],
  declarations: [
    DynamicFieldDirective,
    DynamicFormComponent,
    FormButtonComponent,
    FormInputComponent,
    FormDatePickerComponent,
    FormSelectComponent,
    FormRadioComponent,
    FormCheckComponent,
    FormLabelComponent,
    FormFileUploadComponent,
    ProductFilterPipe,
    ErrorComponent,
  ],
  exports: [DynamicFormComponent],
  entryComponents: [
    FormButtonComponent,
    FormInputComponent,
    FormSelectComponent,
    FormRadioComponent,
  ],
})
export class DynamicFormModule {}
