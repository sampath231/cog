import { ValidatorFn } from '@angular/forms';

export interface FieldConfig {
  id?:number,
  disabled?: boolean,
  label?: string,
  name: string,
  options?: any,
  placeholder?: string,
  type: string,
  validation?: ValidatorFn[],
  value?: any,
  order ? : any
  formtooltip?: string;
  dateFormat?:string;
  pastDate?:string;
  featureDate?:string
  tableData?:any;
  required?:boolean;
  fieldsBySection? : any;

  referenceColumn? : number;
  referenceTable?:number;

}
