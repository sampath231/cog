import {
  Component,
  ComponentFactoryResolver,
  ElementRef,
  OnInit,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { DialogComponent } from '@syncfusion/ej2-angular-popups';
import { DynamicFormComponent } from '../../../components/dynamic-form/containers/dynamic-form/dynamic-form.component';
import { FieldConfig } from '../../../components/dynamic-form/models/field-config.interface';
import { ValidationConstants } from '../../../Constants/validation-constants';
import { GetMasterScreenControlMapping } from '../../../model/get-master-screen-control-mapping';
import { MasterScreenControlConfig } from '../../../model/master-config.Model';
import { MasterScreenControlMapping } from '../../../model/master-screen-control-mapping.model';
import { MasterScreens } from '../../../model/master-screens.model';
import { questionObj } from '../../../model/questionobjModel';
import { JsonMaster } from '../../../model/SaveJsonMaster.model';
import { MasterMaintenanceService } from '../master-maintenance.service';

@Component({
  selector: 'app-master-data-view',
  templateUrl: './master-data-view.component.html',
  styleUrls: ['./master-data-view.component.css'],
})
export class MasterDataViewComponent implements OnInit {
  public masterScreenFields: Object = { text: 'ScreenName', value: 'ScreenID' };
  @ViewChild('ejDialog') ejDialog: DialogComponent;
  // Create element reference for dialog target element.
  @ViewChild('container', { read: ElementRef, static: true })
  container: ElementRef;
  // The Dialog shows within the target element.
  public targetElement: HTMLElement;

  @ViewChild('tabPanel', { static: false, read: ViewContainerRef }) entry!: ViewContainerRef;
  addAlert = ValidationConstants.Add_Alert_Const;
  alertVal = false;
  formViewDialog = false;
  controlListstoConfigure: FieldConfig[] = [];
  masterScreenMappingList: GetMasterScreenControlMapping[];
  dataControls: any = [];
  masterScreenMapping: MasterScreenControlMapping = {
    Master_ScreenID: undefined,
    Control_Type_ID: 2,
    Control_Name: '',
    Control_Value_Length: 0,
    Control_Required: false,
    Control_ColumnType: '',
    AutoIncrement: '',
    Reference_Table: 0,
    Reference_Column: 0,
    IsCreated: false,
    IsActive: false,
    CreatedBy: '',
    CreatedDate: undefined,
    ScreenControl_MappingID: 0,
    Control_ColumnDataType: '',
  };

  JsonMaster: JsonMaster = new JsonMaster();
  masterScreens: MasterScreens[];

  screenTableData: any;

  constructor(
    public masterMainService: MasterMaintenanceService,
    private resolver: ComponentFactoryResolver
  ) { }

  ngOnInit(): void {
    this.getAllMasterScreens();
    this.getAllDataControls();
    this.targetElement = this.container.nativeElement.parentElement;
  }
  getAllDataControls() {
    this.masterMainService
      .getMasterDataControls()
      .subscribe((data) => {
        this.dataControls = data;
      });
  }

  getAllMasterScreens() {
    this.masterMainService
      .getAllMasterScreens()
      .subscribe((data: MasterScreens[]) => {
        this.masterScreens = data;
      });
  }

  getScreenControlsByScreenID() {
    this.masterMainService
      .getScreenControlsByScreenID(this.masterScreenMapping)
      .subscribe((data: MasterScreenControlMapping[]) => {
        this.masterScreenMappingList = data;
        this.ConfigureScreenControlsByScreenID();
      });
  }

  getSreenMasterData() {
    this.screenTableData = [];
    this.masterMainService
      .getScreenControlMasterData(this.masterScreenMapping)
      .subscribe((data) => {
        this.screenTableData = data;
      });
  }

  ConfigureScreenControlsByScreenID() {
    this.controlListstoConfigure = [];
    this.masterScreenMappingList.forEach((element) => {
      switch (element.Control_Type_ID) {
        case 1: // dropdown
          let dropdowndata = []
          this.dataControls.forEach(ele => {
            if (element.ScreenControl_MappingID == ele.ScreenControlID) {
              dropdowndata = ele.DropdownDataSource.split(',');
            }
          })
          const Dropdata = new MasterScreenControlConfig(
            element.ScreenControl_MappingID,
            false,
            element.Control_Name,
            element.Control_Name,
            dropdowndata,
            element.Control_Required,
            '',
            'select',
            '',
            0,
            '',
            '',
            '',
            '',
            element.Reference_Table,
            element.Reference_Column
          );

          this.controlListstoConfigure.push(Dropdata);

          break;
        case 2: // Text Box
          const data = new MasterScreenControlConfig(
            element.ScreenControl_MappingID,
            false,
            element.Control_Name,
            element.Control_Name,
            '',
            element.Control_Required,
            '',
            'input',
            '',
            0,
            '',
            '',
            '',
            '',
            0,
            0
          );

          this.controlListstoConfigure.push(data);

          break;
        case 3: // Radio Button
          var Option = [
            { name: 'Yes', id: 1 },
            { name: 'No', id: 0 },
          ];

          const radiodata = new MasterScreenControlConfig(
            element.ScreenControl_MappingID,
            false,
            element.Control_Name,
            element.Control_Name,
            Option,
            element.Control_Required,
            '',
            'Radio',
            '',
            0,
            '',
            '',
            '',
            '',
            0,
            0
          );

          this.controlListstoConfigure.push(radiodata);

          break;

        case 7: // Date Picker
          const datePicker = new MasterScreenControlConfig(element.ScreenControl_MappingID,
            false, element.Control_Name, element.Control_Name, Option, element.Control_Required,
            '', 'DatePicker', '', 0, '', 'YY-MM-DD', '', '', 0, 0
          );
          this.controlListstoConfigure.push(datePicker);
          break;


        case 16: // Uploader
          var Option = [
            { name: 'Yes', id: 1 },
            { name: 'No', id: 0 },
          ];

          const uploader = new MasterScreenControlConfig(
            element.ScreenControl_MappingID,
            false,
            element.Control_Name,
            element.Control_Name,
            Option,
            element.Control_Required,
            '',
            'FileUpload',
            '',
            0,
            '',
            '',
            '',
            '',
            0,
            0
          );

          this.controlListstoConfigure.push(uploader);

          break;

        default:
          break;
      }
    });

    const btnData = new questionObj(
      0,
      '',
      '',
      '',
      '',
      '',
      'Submit',
      true,
      100,
      '',
      'button',
      'submit'
    );
    this.controlListstoConfigure.push(btnData);

    this.entry.clear();
    const factory = this.resolver.resolveComponentFactory(DynamicFormComponent);
    const componentRef = this.entry.createComponent(factory);
    // var cont = this.controlListstoConfigure.filter((control: any) => control.type == 'button');
    componentRef.instance.config = this.controlListstoConfigure;
    componentRef.instance.submit.subscribe((val) => {
      this.submit(val);
    });
  }

  submit(value: any) {
    this.JsonMaster.AssociateId = sessionStorage.getItem("AssociateId");
    this.JsonMaster.Master_ScreenID = this.masterScreenMapping.Master_ScreenID;
    this.JsonMaster.jsonData = JSON.stringify(value);
    
    this.masterMainService.SaveScreenControlsData(this.JsonMaster)
      .subscribe((data: any) => {
        this.alertVal = true;
          this.JsonMaster = new JsonMaster();
          this.ejDialog.hide();
      });
  }

  openNew() {
    this.formViewDialog = true;
    this.ejDialog.show();
    this.getScreenControlsByScreenID();
  }

  hideDialog() {
    this.formViewDialog = false;
  }
}
