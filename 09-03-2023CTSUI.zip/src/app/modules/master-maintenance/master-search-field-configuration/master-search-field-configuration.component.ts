
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms'
import { EditSettingsModel, ToolbarItems, IEditCell } from '@syncfusion/ej2-angular-grids';
import { mastersearch } from 'src/app/model/mastersearch.model';
import { samplemodel } from 'src/app/model/samplemodel';
import { CommonService } from 'src/app/services/common.service';
import { MultiSelectAllModule } from '@syncfusion/ej2-angular-dropdowns';
import { concatMap, debounceTime, delay, takeUntil, tap } from 'rxjs/operators';
import { of, Subject } from 'rxjs';
import { MasterMaintenanceService } from '../master-maintenance.service';
@Component({
  selector: 'app-master-search-field-configuration',
  templateUrl: './master-search-field-configuration.component.html',
  styleUrls: ['./master-search-field-configuration.component.css']
})
export class MasterSearchFieldConfigurationComponent implements OnInit  ,OnDestroy {
  private formDataSubject: Subject<any> = new Subject();
    private _destroy$ = new Subject<void>();
  data : any= [];
  tableData: any;
  TableModel: any;
  TableHeaders: any;
  TableColumns: any;
  apiUrl: any;
  MinimumLength: any
  selectedOption: any;
  datsource = [];
  datsource2 = [];
  DepColumn = [
    '', ''
  ];
  searchControlID: any
  SearchControlID: any
  searchControl: any
  masterdata: any
  public editSettings: EditSettingsModel;
  public toolbar: ToolbarItems[];
  public boolParams: IEditCell;
  nominationModelData: any[];
  autofieldData: any[] = [];
  depfieldData: any[];
  public coloum: string[] = ["", ""];
  auto: any[];
  public value: number;
  public text: string;
  Autocoloum: any
  showMsg : boolean = false
  validMsgs : boolean = false
  Msgs: Object = { Success: 'Data Saved Successfully !'}
  validMsg: string = "";


  public fields: Object = { text: 'ControlName', value: 'ControlID' };
  MasterDetails!: FormGroup;
  constructor(
    public masterMainService: MasterMaintenanceService,private fb: FormBuilder) {
      this.MasterDetails = this.fb.group({
        searchControlID:['', [Validators.required]],
        searchControl: ['', [Validators.required]],
        apiUrl: ['', Validators.required],
        MinLength:['', [Validators.required, Validators.maxLength(3)]],
        AutoFieldColumn:['', Validators.required],
        DepColumn: ['', [Validators.required, Validators.maxLength(3)]],
      })
  }

  

  ngOnInit(): void {
    debugger
    this.masterMainService.getcontroltype().subscribe(resp => {
      this.data = resp

    })


    const draft = localStorage.getItem("RESP1");
    if(draft)
      {
        this.MasterDetails.setValue(JSON.parse(draft))
      }
      this.MasterDetails.valueChanges.subscribe(data => {
        this.formDataSubject.next(data);
      });
  
      this.formDataSubject.pipe(debounceTime(1000))
      .subscribe(data => localStorage.setItem("RESP1",JSON.stringify(data)) );
  
    this.getGetails();
    this.MasterDetails.reset();
    
  }
 
  ngOnDestroy(): void {
    this.formDataSubject.unsubscribe();
  }

  getGetails() {
     this.masterMainService.getApiData().subscribe((data: any) => {
       debugger
       this.datsource = Object.keys(data[0]);
     });
  }

  onChangeEvent(searchControlId) {
    
    this.getGetails();
    this.masterMainService.getMastersearchdata(searchControlId).subscribe((resp: any) => {
      this.MasterDetails.value.apiUrl = resp[0].ApiUrl
      this.MasterDetails.controls['searchControlID'].setValue(resp[0].SearchControlID);
      this.MasterDetails.controls['searchControl'].setValue(resp[0].SearchControl);
      this.MasterDetails.controls['MinLength'].setValue(resp[0].MinLength);
      this.MasterDetails.controls['apiUrl'].setValue(resp[0].ApiUrl);
      //this.MasterDetails.controls['AutoFieldColumn'].setValue(resp[0].AutoFieldColumn);
      this.Autocoloum = resp[0].AutoFieldColumn
      this.coloum = resp[0].DepColumn.split(',');
      
     })


  }

  onSaveChanges() {
    debugger
    this.showMsg = false
    this.MasterDetails["submitted"] = true;
   var data = this.MasterDetails.value
   if(!this.MasterDetails.valid)
   {
    this.showMsg = true;
    this.validMsgs = true;
   }
     else {
    this.MasterDetails.value.DepColumn = this.MasterDetails.value.DepColumn.toString()
     this.masterMainService.PostMasterdata(this.MasterDetails.value).subscribe((data: any) => {
      this.showMsg = true
      this.validMsgs = false
      this.validMsg = 'Data Saved Successfully !';
      this.MasterDetails.reset()
    });
  }
}
}



