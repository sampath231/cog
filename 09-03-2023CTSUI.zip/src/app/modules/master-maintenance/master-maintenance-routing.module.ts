import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { MasterSettingsComponent } from './master-settings/master-settings.component';
import { MasterDataViewComponent } from './master-data-view/master-data-view.component';
///import {NominationMasterComponent} from './nomination-master/nomination-master.component';
import { MasterSearchFieldConfigurationComponent } from './master-search-field-configuration/master-search-field-configuration.component';
import { SelectFieldComponent } from './select-field/select-field.component';



const routes: Routes = [
  { path: '', component: MasterSettingsComponent, pathMatch: 'full' },
  { path: 'MasterSettings', component: MasterSettingsComponent },
  { path: 'MasterData', component: MasterDataViewComponent },
  //{ path: 'NominationMaster', component: NominationMasterComponent },
  { path: 'Autosearch', component: MasterSearchFieldConfigurationComponent },
  { path: 'select', component: SelectFieldComponent },

];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MasterMaintenanceRoutingModule { }
