import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MultiSelectAllModule } from '@syncfusion/ej2-angular-dropdowns';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { SyncfusionModule } from '../../syncfusion.module';
import { MasterMaintenanceService } from './master-maintenance.service';
import { MasterMaintenanceRoutingModule } from './master-maintenance-routing.module';
import { MasterSettingsComponent } from './master-settings/master-settings.component';
import { MasterDataViewComponent } from './master-data-view/master-data-view.component';
import { DynamicTableComponent } from '../../components/dynamic-table/dynamic-table.component';
import { MasterSearchFieldConfigurationComponent } from './master-search-field-configuration/master-search-field-configuration.component';
import { CommandColumnService, EditService, GridModule, PageService, ToolbarService } from '@syncfusion/ej2-angular-grids';
import { SelectFieldComponent } from './select-field/select-field.component';


//import { AutoSearchComponent } from './auto-search/auto-search.component';

@NgModule({
  declarations: [
    MasterSettingsComponent,
    DynamicTableComponent,
    MasterDataViewComponent,MasterSearchFieldConfigurationComponent, SelectFieldComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    SyncfusionModule,
    MasterMaintenanceRoutingModule,
    FormsModule,MultiSelectAllModule,
  ],
  providers: [MasterMaintenanceService,EditService]
})
export class MasterMaintenanceModule {}
