import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders, HttpResponse } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { MasterScreens } from '../../model/master-screens.model';
import { mergeMap, Observable } from 'rxjs';

import { AppConstants } from '../../globals/app-constants';
import { MasterControlType } from '../../../app/model/master-control-type.model';
import { MasterScreenControlMapping } from '../../../app/model/master-screen-control-mapping.model';
// import { MasterScreenControl } from 'app/model/master-scree-mapping.model';
import { JsonMaster } from '../../../app/model/SaveJsonMaster.model';
import { AutoControlType } from '../../model/AutoControlType';
import { mastersearch } from '../../model/mastersearch.model';


@Injectable({
  providedIn: 'root',
})
export class MasterMaintenanceService {
  masterBase = environment.masterBase;
  apiBase = environment.apiBase;

  constructor(private http: HttpClient) {}

  getAllMasterScreens(): Observable<MasterScreens[]> {
    return this.http.get<MasterScreens[]>(
      this.apiBase + AppConstants.API_GetAllMasterScreens
    );
  }

  getAllMasterControlTypes(): Observable<MasterControlType[]> {
    return this.http.get<MasterControlType[]>(
      this.apiBase + AppConstants.API_GetAllMasterControlTypes
    );
  }

  getScreenControlsByScreenID(
    masterScreenControlMapping: MasterScreenControlMapping
  ): Observable<MasterScreenControlMapping[]> {
    return this.http.get<MasterScreenControlMapping[]>(
      this.apiBase + AppConstants.API_GetScreenControlsByScreenID + '?screenID=' +
      masterScreenControlMapping.Master_ScreenID
    );
  }

  getReferenceControlsByScreenID(
    masterScreenControlMapping: MasterScreenControlMapping
  ): Observable<MasterScreenControlMapping[]> {
    return this.http.get<MasterScreenControlMapping[]>(
      this.apiBase + AppConstants.API_GetReferenceControlsByScreenID + '?refTable=' +
      masterScreenControlMapping.Reference_Table
    );
  }

  SaveMasterScreen(masterScreens: MasterScreens): Observable<number> {
    return this.http.post<number>(
      this.apiBase + AppConstants.API_SaveMasterScreen,
      masterScreens
    );
  }

  SaveScreenControlsByScreenID(
    masterScreenControlMapping: MasterScreenControlMapping): Observable<number> {
    return this.http.post<number>(
      this.apiBase + AppConstants.API_SaveScreenControlsByScreenID,
      masterScreenControlMapping
    );
  }

  SaveScreenControlsData(objJsonMaster: JsonMaster): Observable<number> {
    return this.http.post<number>(
      this.apiBase + AppConstants.API_SaveScreenControlsData,
      objJsonMaster
    );
  }

  getApiData() {
    return this.http.get('https://localhost:7023/ImmiWorld/Admin/AlwaysEncrypt/GetCountries?countryName=India');
  }

  getScreenControlMasterData(
    masterScreenControlMapping: MasterScreenControlMapping
  ): Observable<any> {
    return this.http.get<any>(
      this.apiBase + AppConstants.API_GetScreenControlMasterData + '?masterscreenid=' +  masterScreenControlMapping.Master_ScreenID
    );
  }
  getMasterDataControls(): Observable<any> {
    return this.http.get<any>(this.apiBase + AppConstants.API_GetMasterDataControls);
  }
  updateScreenControlsData(data: any) {
    return this.http.put(this.apiBase + AppConstants.API_UpdateScreenControlsData, data);
  }

 

  getcontroltype(): Observable<AutoControlType> {
    return this.http.get<AutoControlType>(
      this.apiBase + AppConstants.API_GetAutoSaveControl
    );
  }

  getMastersearchdata(searchControlId) {
    debugger;
    return this.http.get<mastersearch>(this.apiBase + AppConstants.API_GetMasterSearch + '?controlId=' + searchControlId);

  }


  


  PostMasterdata(data: any): Observable<number> {
    return this.http.post<number>(this.apiBase + AppConstants.API_SaveGetMasterSearch, data);

  }



  

}
