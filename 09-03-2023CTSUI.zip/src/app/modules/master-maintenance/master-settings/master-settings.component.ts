import {
  Component,
  ElementRef,
  OnInit,
  ViewChild,
  ViewContainerRef,
} from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { RequestModel } from '../../../model/common-request.model';
import { MasterMaintenanceService } from '../master-maintenance.service';
import { MasterScreens } from '../../../model/master-screens.model';
import { MasterControlType } from '../../../model/master-control-type.model';
import { MasterScreenControlMapping } from '../../../model/master-screen-control-mapping.model';
import { questionObj } from '../../../model/questionobjModel';
import { JsonMaster } from '../../../model/SaveJsonMaster.model';
import { DialogComponent } from '@syncfusion/ej2-angular-popups';
import { EmitType } from '@syncfusion/ej2-base';
import { MasterScreenControlConfig } from '../../../model/master-config.Model';
import { GetMasterScreenControlMapping } from '../../../model/get-master-screen-control-mapping';
import { ValidationConstants } from '../../../Constants/validation-constants';
import { timeout } from 'rxjs';

@Component({
  selector: 'app-master-settings',
  templateUrl: './master-settings.component.html',
  styleUrls: ['./master-settings.component.css'],
})
export class MasterSettingsComponent implements OnInit {
  public masterScreenFields: Object = { text: 'ScreenName', value: 'ScreenID' };
  public refControlFields: Object = {
    text: 'Control_Name',
    value: 'ScreenControl_MappingID',
  };
  public columnTypeFields: Object = { text: 'name', value: 'code' };
  public controlDataTypeFields: Object = { text: 'name', value: 'code' };
  public controlTypeFields: Object = {
    text: 'ControlName',
    value: 'ControlID',
  };
  @ViewChild('ejDialog') ejDialog: DialogComponent;
  // Create element reference for dialog target element.
  @ViewChild('container', { read: ElementRef, static: true })
  container: ElementRef;
  // The Dialog shows within the target element.
  public targetElement: HTMLElement;
  required = ValidationConstants.Required_Const;
  controlAlert = ValidationConstants.Controls_Alert_Const;
  addAlert = ValidationConstants.Add_Alert_Const;
  alertVal = false;
  selectedCity: any;
  reqModel: RequestModel = new RequestModel();
  masterScreen: MasterScreens = new MasterScreens();
  masterScreens: MasterScreens[];
  masterControlType: MasterControlType[];
  masterScreenMappingList: GetMasterScreenControlMapping[];
  referenceControlsList: MasterScreenControlMapping[];
  controlReqOption: any;
  referenceTableID: number;
  referenceColumnID: number;
  JsonMaster: JsonMaster = {
    Master_ScreenID: 0,
    jsonData: '',
    AssociateId: '2150102'
  };
  masterScreenMapping: MasterScreenControlMapping = new MasterScreenControlMapping();

  cities: any;
  controlType: any;
  ControlDatatypes: any;
  ControlColumntypes: any;

  projQustionModel: questionObj;

  @ViewChild('tabPanel', { static: false, read: ViewContainerRef })
  entry!: ViewContainerRef;
  formViewDialog = false;
  MasterViewDialog = false;

  constructor(
    public commonService: CommonService,
    public masterMainService: MasterMaintenanceService
  ) {
    this.controlReqOption = [
      { label: 'Yes', value: true },
      { label: 'No', value: false },
    ];

    this.ControlDatatypes = [
      { name: 'Select DataType', code: '0' },
      { name: 'varchar', code: 'varchar' },
      { name: 'bit', code: 'bit' },
      { name: 'int', code: 'int' },
      { name: 'date', code: 'date' },
    ];

    this.ControlColumntypes = [
      { name: 'Select ColumnType', code: '0' },
      { name: 'Standord Column', code: 'SC' },
      { name: 'Reference Column', code: 'RC' },
    ];
  }

  ngOnInit(): void {
    this.getAllMasterScreens();
    this.getAllMasterControlTypes();
    this.initilaizeTarget();
  }

  public initilaizeTarget: EmitType<object> = () => {
    this.targetElement = this.container.nativeElement.parentElement;
  };

  public onOpenDialog = function (event: any): void {
    // Call the show method to open the Dialog
    this.ejDialog.show();

  };

  getAllMasterScreens() {
    this.masterMainService
      .getAllMasterScreens()
      .subscribe((data: MasterScreens[]) => {
        this.masterScreens = data;
      });
  }

  getAllMasterControlTypes() {
    this.masterMainService
      .getAllMasterControlTypes()
      .subscribe((data: MasterControlType[]) => {
        this.masterControlType = data;
      });
  }

  getScreenControlsByScreenID() {
    this.masterMainService
      .getScreenControlsByScreenID(this.masterScreenMapping)
      .subscribe((data: MasterScreenControlMapping[]) => {
        this.masterScreenMappingList = data;
      });
  }

  getReferenceControlsByScreenID() {
    this.masterMainService
      .getReferenceControlsByScreenID(this.masterScreenMapping)
      .subscribe((data: MasterScreenControlMapping[]) => {
        this.referenceControlsList = data;
      });
  }

  saveControl() {
    this.masterScreenMapping.CreatedBy = sessionStorage.getItem("AssociateId");
    this.masterScreenMapping.IsActive = true;
    this.masterScreenMapping.IsCreated = false;
    this.masterScreenMapping.AutoIncrement = 'N';
    if (this.masterScreenMapping.Control_ColumnType == 'RC') {
      this.masterScreenMapping.Control_Type_ID = 1;
    }

    this.masterMainService
      .SaveScreenControlsByScreenID(this.masterScreenMapping)
      .subscribe(data => {
        if (data) {
          this.getScreenControlsByScreenID();
          this.masterScreenMapping = new MasterScreenControlMapping();
          this.alertInterval()
        }
      });
  }

  alertInterval() {
    this.alertVal = true;
    timeout(3000);
    this.alertVal = false;
  }

  saveMasterClick() {
    this.masterScreen.CreatedBy = sessionStorage.getItem("AssociateId");
      this.masterMainService
        .SaveMasterScreen(this.masterScreen)
        .subscribe((data) => {
          if (data) {
            this.masterScreen = new MasterScreens();
            this.hideMaster();
          }
          this.getAllMasterScreens();
          this.alertInterval();
        });
  }

  hideMaster() {
    this.ejDialog.hide();
  }
}
