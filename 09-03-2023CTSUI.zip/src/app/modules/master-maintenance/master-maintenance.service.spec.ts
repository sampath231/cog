import { TestBed } from '@angular/core/testing';

import { MasterMaintenanceService } from './master-maintenance.service';

describe('MasterMaintenanceService', () => {
  let service: MasterMaintenanceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(MasterMaintenanceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
