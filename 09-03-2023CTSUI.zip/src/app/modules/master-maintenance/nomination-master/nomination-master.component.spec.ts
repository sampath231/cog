import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NominationMasterComponent } from './nomination-master.component';

describe('NominationMasterComponent', () => {
  let component: NominationMasterComponent;
  let fixture: ComponentFixture<NominationMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ NominationMasterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(NominationMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
