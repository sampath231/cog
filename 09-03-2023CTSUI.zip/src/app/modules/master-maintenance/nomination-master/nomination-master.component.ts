import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-nomination-master',
  templateUrl: './nomination-master.component.html',
  styleUrls: ['./nomination-master.component.css']
})
export class NominationMasterComponent implements OnInit {
  controlsType: string[] = ['Text', 'Select','Radio','DatePicker'];
  screenName: string[] = ['Nomination', 'DashBoard'];
  sectionType: string[] = ['Associate Details ', 'Proposed Details', 'Base Case', 'Current Project Details'];
  subSecType: string[] = ['Proposed Project Details', 'Proposed Job Details'];
  controlType: string[] = ['Associate ID', 'Associate Name', 'Country of Travel', 'Purpose of request', 'Planned travel start date', 'Planned travel end date', 'Billability Type'];
  data: string[] = ['Associate', 'GM Lead', 'Extension to stay'];
  prData: string[] = ['Relocation / New Permit', 'Business Travel', 'Conversions', 'Extension of Stay', 'PR'];
  baseCaseNominationLink = false;
  selectedBasecase = null;
  showAccord: boolean = false;
  showCheckBox = true;
  associateDetails = new FormGroup({
    associateId: new FormControl({ value: '', disabled: true }),
    name: new FormControl({ value: '', disabled: true }),
    travelCountry: new FormControl('Associate'),
    requestPurpose: new FormControl('Associate'),
    proposedDetails: new FormGroup({
      plannedTravelStartDate: new FormControl('1/7/2023'),
      plannedTravelEndDate: new FormControl(),
      proposedProjectDetails: new FormGroup({
        billabilityType: new FormControl('Billable'),
        projectId: new FormControl(12345678),
        projectName: new FormControl(),
        travelJd: new FormControl(),
        onsiteManagerId: new FormControl(),
      }),
    }),
    currentProjectDetails: new FormGroup({
      projectId: new FormControl(),
      projectName: new FormControl(),
      manager: new FormControl(),
    }),
  });


  public countries: Object[] = [
    { id: 1, name: 'Proposed Details', hasChild: true, expanded: true },
    { id: 2, pid: 1, name: 'Planned travel start date' },
    { id: 3, pid: 1, name: 'Planned travel end date' },
    { id: 4, pid: 1, name: 'Country of Travel' },
    { id: 6, pid: 1, name: 'Western Australia' },
    { id: 7, name: 'Brazil', hasChild: true },
    { id: 8, pid: 7, name: 'Paraná' },
    { id: 9, pid: 7, name: 'Ceará' },
    { id: 10, pid: 7, name: 'Acre' },

  ];

  public hierarchicalData: Object[] = [
    {
      id: '01', name: 'Proposed Details', expanded: false,
      subChild: [
        {
          id: '01-01', name: 'Planned travel start date'
        }, {
          id: '01-02', name: 'Planned travel end date'
        },
        {
          id: '01-03', name: 'Proposed Project Details', expanded: false,
          subChild: [
            { id: '01-03-01', name: 'Billability Type' },
            { id: '01-03-02', name: 'Proposed Porject ID' },
            { id: '01-03-03', name: 'Proposed Porject Name' },
          ]
        },
        {
          id: '01-04', name: 'Proposed Job Details',
          subChild: [
            { id: '01-04-01', name: 'Add client details' }
          ]
        },
      ]
    },
    {
      id: '02', name: 'Current Project Details',
      subChild: [
        {
          id: '02-01', name: 'Current Project ID',

        },
        {
          id: '02-02', name: 'Current Project Name',

        },
        {
          id: '02-03', name: 'Current Project Manager',

        },
      ]
    }, {
      id: '03', name: 'Base Case Selection'}
  ];
  // Mapping TreeView fields property with data source properties
  public field: Object = { dataSource: this.hierarchicalData, id: 'id', text: 'name', child: 'subChild' };

  constructor() { }

  ngOnInit(): void {
  }

}
