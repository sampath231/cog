
import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms'
import { EditSettingsModel, ToolbarItems, IEditCell } from '@syncfusion/ej2-angular-grids';
import { mastersearch } from 'src/app/model/mastersearch.model';
import { samplemodel } from 'src/app/model/samplemodel';
import { CommonService } from 'src/app/services/common.service';
import { MultiSelectAllModule } from '@syncfusion/ej2-angular-dropdowns';
import { concatMap, debounceTime, delay, takeUntil, tap } from 'rxjs/operators';
import { of, Subject } from 'rxjs';
import { MasterMaintenanceService } from '../master-maintenance.service';
@Component({
  selector: 'app-select-field',
  templateUrl: './select-field.component.html',
  styleUrls: ['./select-field.component.css']
})
export class SelectFieldComponent implements OnInit  ,OnDestroy {
  private formDataSubject: Subject<any> = new Subject();
    private _destroy$ = new Subject<void>();
  
  data : any= [];
  tableData: any;
  TableModel: any;
  TableHeaders: any;
  TableColumns: any;
  //fields: any;
  apiUrl: any;
  MinimumLength: any
  selectedOption: any;
  datsource = [];
  datsource2 = [];
  DepColumn = [
    '', ''
  ];
  searchControlID: any
  SearchControlID: any
  searchControl: any
  masterdata: any
  public editSettings: EditSettingsModel;
  public toolbar: ToolbarItems[];
  public boolParams: IEditCell;
  nominationModelData: any[];
  autofieldData: any[] = [];
  depfieldData: any[];
  public coloum: string[] = ["", ""];
  auto: any[];
  public value: number;
  public text: string;
  Autocoloum: any
  showMsg : boolean = false
  validMsgs : boolean = false
  Msgs: Object = { Success: 'Data Saved Successfully !',
  Error: 'Please fill all the fields !' };
  validMsg: string = "";




 
  public fields: Object = { text: 'SearchControl', value: 'SelectID' };
  MasterDetails!: FormGroup;
  constructor(
    public masterMainService: MasterMaintenanceService,private fb: FormBuilder) {

      this.MasterDetails = this.fb.group({
        selectID:['', [Validators.required]],
        apiEndPoint: ['', Validators.required],
        keyColumn:['', Validators.required],
        valueColumn: ['', [Validators.required, Validators.maxLength(3)]],
        searchControl: ['', [Validators.required]],
    
    
    
    
      })
  }

  

  ngOnInit(): void {
    debugger
    // this.masterMainService.getcontroltypeselect().subscribe(resp => {
    //   this.data = resp
    // })
    debugger

    // const draft = localStorage.getItem("RESP1");
    // if(draft)
    //   {
    //     this.MasterDetails.setValue(JSON.parse(draft))
    //   }
    //   this.MasterDetails.valueChanges.subscribe(data => {
    //     this.formDataSubject.next(data);
    //   });
  
    //   this.formDataSubject.pipe(debounceTime(1000))
    //   .subscribe(data => localStorage.setItem("RESP1",JSON.stringify(data)) );
  
    this.getGetails();
   // this.MasterDetails.reset();
    
  }
 
  ngOnDestroy(): void {
    this.formDataSubject.unsubscribe();
  }

  getGetails() {
    //  this.masterMainService.getApiData().subscribe((data: any) => {
    //    debugger
    //    this.datsource = Object.keys(data[0]);
    //  });
  }

  onChangeEvent(selectId) {
    debugger
    // this.masterMainService.getMasterSelect(selectId).subscribe((resp: any) => {
    //   debugger
    //    this.MasterDetails.controls['selectID'].setValue(resp.SelectID);
    //    this.MasterDetails.controls['apiEndPoint'].setValue(resp.ApiEndPoint);
    //    //this.MasterDetails.controls['keyColumn'].setValue(resp.KeyColumn);
    //    //this.MasterDetails.controls['valueColumn'].setValue(resp.ValueColumn);
    //   this.MasterDetails.controls['searchControl'].setValue(resp.SearchControl);
    //   this.datsource = [resp.KeyColumn, resp.ValueColumn];
    //   this.Autocoloum = resp.KeyColumn;
    //   this.coloum = resp.ValueColumn;
    //  })


  }

  
  
 

  
  onSaveChanges() {
    debugger
    this.showMsg = false
    this.MasterDetails["submitted"] = true;
   var data = this.MasterDetails.value
   if(!this.MasterDetails.valid)
   {
    this.showMsg = true;
    this.validMsgs = true;
   // this.validMsg = 'Please fill all the fields !';
   }
     else {
    this.MasterDetails.value.DepColumn = this.MasterDetails.value.DepColumn.toString()
     this.masterMainService.PostMasterdata(this.MasterDetails.value).subscribe((data: any) => {
      this.showMsg = true
      this.validMsgs = false
      this.validMsg = 'Data Saved Successfully !';
      this.MasterDetails.reset()
    });
  }
}
}




