export class CacheApisConstants {
  // public static ItemPerPage: number = 50;
  public static PageNames: string[] = ['GetMasterMaintenance','GetAllMasterScreens','GetAllMasterControlTypes'];
  // public static AllowFiltering: boolean = true;
}
