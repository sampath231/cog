import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class AppConstants {
  // Admin API Constant
  public static API_SaveMasterScreen: string = 'Screens/SaveMasterScreen';
  public static API_GetAllMasterScreens: string = 'Screens/GetMasterScreens';
  public static API_GetAllMasterControlTypes: string ='ControlType/GetAllMasterControlTypes';
  public static API_GetScreenControlsByScreenID: string ='ScreenControls/GetScreenControlsByScreenID';
  public static API_GetReferenceControlsByScreenID: string ='ReferenceControl/GetReferenceControlsByScreenID';
  public static API_SaveScreenControlsByScreenID: string ='ScreenControls/SaveScreenControlsByScreenID';
  public static API_UpdatesScreenControlsByScreenID: string ='ScreenControls/UpdatesScreenControlsByScreenID';
  public static API_SaveScreenControlsData: string = 'ScreenData/SaveScreenControlsData';
  public static API_UpdateScreenControlsData: string = 'ScreenData/UpdateScreenControlData';
  public static API_GetReferenceTableDataMaster: string ='ControlOptions/GetReferenceTableDataMaster';
  public static API_GetScreenControlMasterData: string = 'ScreenData/GetScreenControlMasterData'; 
  public static API_GetMasterDataControls: string ='ControlsData/GetMasterDataControls';
  // UserManagement API Constants
  public static Login_GetUserRolesGMT: string = 'GetUserRolesGMT';

  public static API_GetAutoSaveControl: string = 'Auto/GetAutoSaveControl';
  public static API_GetMasterSearch: string = 'MasterSearchField/GetMasterSearch';
  public static API_SaveGetMasterSearch: string = 'MasterSearchField/SaveGetMasterSearch';

}
