import { NgModule } from '@angular/core';

import { EditService, GridModule } from '@syncfusion/ej2-angular-grids';
import { DialogModule } from '@syncfusion/ej2-angular-popups';
import {
  DropDownListModule,
  ComboBoxModule,
} from '@syncfusion/ej2-angular-dropdowns';
import {
  ButtonModule,
  SwitchModule,
  RadioButtonModule, CheckBoxModule
} from '@syncfusion/ej2-angular-buttons';
import {
  CarouselAllModule,
  ToolbarModule,
  AccordionModule, TreeViewModule
} from '@syncfusion/ej2-angular-navigations';
import { DatePickerModule, DatePickerAllModule } from '@syncfusion/ej2-angular-calendars';
import { UploaderModule } from '@syncfusion/ej2-angular-inputs';

import {
  PageService,
  SortService,
  FilterService,
  GroupService,
  SearchService,
  ToolbarService,
} from '@syncfusion/ej2-angular-grids';

@NgModule({
  exports: [
    GridModule,
    DialogModule,
    DropDownListModule,
    ComboBoxModule,
    ButtonModule,
    RadioButtonModule, CheckBoxModule,
    CarouselAllModule,
    ToolbarModule,
    AccordionModule, TreeViewModule ,
    SwitchModule,
    DatePickerModule,
    DatePickerAllModule,
    UploaderModule,
  ],
  providers: [
    SortService,
    FilterService,
    SearchService,
    ToolbarService,
    PageService,
    GroupService,
    EditService
  ],
})
export class SyncfusionModule {}
