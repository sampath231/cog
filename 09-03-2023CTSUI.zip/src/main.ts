import { registerLicense } from '@syncfusion/ej2-base';
import { GlobalConstants } from './app/Constants/global-constants';
import('./bootstrap')
	.catch(err => console.error(err));

registerLicense(GlobalConstants.Syncfusion_License);
