﻿//-----------------------------------------------------------------------
// <copyright file="ScreenDataController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    /// <summary>
    /// class for Screen Data Controller
    /// </summary>
    [ServiceFilter(typeof(RequestLogFilter))]
    [ApiController]
    [Route("ImmiWorld/[controller]")]
    public class ScreenDataController : Controller
    {
        private readonly IMasterScreen masterScreen;
        /// <summary>
        /// Screen Data constructor 
        /// </summary>
        /// <param name="imasterScreen">Interface for masterScreens</param>
        public ScreenDataController(IMasterScreen imasterScreen)
        {
            masterScreen = imasterScreen;
        }
        /// <summary>
        /// To get the JSON string of Screens Data
        /// </summary>
        /// <param name="masterscreenid">Master Screen Id</param>
        /// <returns>JSON string of Screens Data</returns>
        [HttpGet]
        public string Get(int masterscreenid)
        {
            return masterScreen.GetScreenControlMasterData(masterscreenid);
        }
        /// <summary>
        /// To save the JSON string of Screens Data
        /// </summary>
        /// <param name="jsonMaster">JsonMasterData</param>
        /// <returns>true, for data saved / false, for error</returns>
        [HttpPost]
        public bool Post(SaveJsonMaster jsonMaster)
        {
            return masterScreen.SaveScreenControlsData(jsonMaster);
        }
        /// <summary>
        /// To update the JSON string of Screens Data
        /// </summary>
        /// <param name="jsonMaster">JsonMasterData</param>
        /// <returns>Id of updated record</returns>
        [HttpPut]
        public int Put(UpdateJsonMaster jsonMaster)
        {
            return masterScreen.UpdateScreenControlsData(jsonMaster);
        }
    }
}
