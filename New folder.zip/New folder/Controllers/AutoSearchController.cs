﻿//-----------------------------------------------------------------------
// <copyright file="AutoSearchController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;
    using OneC_3601_AdminAPI.Repositories.Persistence;
    /// <summary>
    /// class for AutoSearch controller
    /// </summary
    /// 
    [ServiceFilter(typeof(RequestLogFilter))]
    [ApiController]
    [Route("ImmiWorld/Admin/[controller]")]
    public class AutoSearchController : ControllerBase
    {
        private readonly IAutoSearch autoSearchServices;
        private readonly IMasterControl masterControlService;
        /// <summary>
        /// AutoSearch Controls constructor 
        /// </summary>
        /// <param name="IAutoSearch">Interface for IAutoSearch</param>
        public AutoSearchController(IAutoSearch AutoSearchServices, IMasterControl imastercontrolservices)
        {
            autoSearchServices = AutoSearchServices;
            masterControlService = imastercontrolservices;
        }

        /// <summary>
        /// To get the List  of Autosearch Controls
        /// </summary>
        /// <param name="id"> Id</param>
        /// <returns>List  of  AutoSearch Controls Data</returns>
        [HttpGet]
        public List<MasterSearchFieldConfiguration> Get(int controlId)
        {
            return autoSearchServices.GetSearchFieldConfigById(controlId);
        }

        /// <summary>
        /// To save the  AutoSearch Controls Data
        /// </summary>
        /// <param name=" fieldConfig">Auto Controls</param>
        /// <returns>Autosearch of saved record</returns>
        [HttpPost]
        public int Post(MasterSearchFieldConfiguration fieldConfig)
        {
            return autoSearchServices.SaveSearchFieldConfig(fieldConfig);
        }

        /// <summary>
        /// To get the control type Autosearch
        /// </summary>
        /// <param name=" AutoSearch"></param>
        /// <returns>Autosearch of control Type </returns>
        [HttpGet("controls")]
        public List<MasterControls> controls()
        {
            return masterControlService.GetControlsByControlType("AutoSearch");
        }
    }
}
