﻿//-----------------------------------------------------------------------
// <copyright file="ControlOptionsController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    /// <summary>
    /// class for Control Options Controller
    /// </summary>
    [ServiceFilter(typeof(RequestLogFilter))]
    [ApiController]
    [Route("ImmiWorld/[controller]")]
    public class ControlOptionsController : Controller
    {
        private readonly IMasterScreen masterScreen;
        /// <summary>
        /// Control Options constructor 
        /// </summary>
        /// <param name="imasterScreen">Interface for masterScreens</param>
        public ControlOptionsController(IMasterScreen imasterScreen)
        {
            masterScreen = imasterScreen;
        }
        /// <summary>
        /// To get the List of Reference table control's Key and value
        /// </summary>
        /// <param name="refTable">Reference Table</param>
        /// <param name="refColumn">Reference Columns</param>
        /// <returns>List  of Reference table control's Key and value</returns>
        [HttpGet]
        public List<CommonDataMaster> Get(int refTable, int refColumn)
        {
            return masterScreen.GetReferenceTableDataMaster(refTable, refColumn);
        }
    }
}
