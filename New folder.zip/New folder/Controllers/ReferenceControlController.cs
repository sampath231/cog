﻿//-----------------------------------------------------------------------
// <copyright file="ReferenceControlController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Controllers
{

    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;
    /// <summary>
    /// class for Reference Controls Controller
    /// </summary>
    [ServiceFilter(typeof(RequestLogFilter))]
    [ApiController]
    [Route("ImmiWorld/[controller]")]
    public class ReferenceControlController : Controller 
    {
        private readonly IMasterScreen masterScreen;
        /// <summary>
        /// Screen Controls constructor 
        /// </summary>
        /// <param name="imasterScreen">Interface for masterScreens</param>
        public ReferenceControlController(IMasterScreen imasterScreen)
        {
            masterScreen = imasterScreen;
        }
        /// <summary>
        /// To get the List of Reference Controls Data
        /// </summary>
        /// <param name="referenceTable">Reference Table</param>
        /// <returns>List  of Reference Controls Data</returns>
        [HttpGet]
        public List<GetMasterScreenControlMapping> Get(int referenceTable)
        {
            return masterScreen.GetReferenceControlsByScreenID(referenceTable);
        }
    }
}
