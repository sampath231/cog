﻿//-----------------------------------------------------------------------
// <copyright file="ScreenDataController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    /// <summary>
    /// class for Screen Controls Controller
    /// </summary>
    [ServiceFilter(typeof(RequestLogFilter))]
    [ApiController]
    [Route("ImmiWorld/[controller]")]
    public class ScreenControlsController : Controller
    {
        private readonly IMasterScreen masterScreen;
        /// <summary>
        /// Screen Controls constructor 
        /// </summary>
        /// <param name="imasterScreen">Interface for masterScreens</param>
        public ScreenControlsController(IMasterScreen imasterScreen)
        {
            masterScreen = imasterScreen;
        }
        /// <summary>
        /// To get the List of Screen Controls Data
        /// </summary>
        /// <param name="screenID">Master Screen Id</param>
        /// <returns>List  of Screen Controls Data</returns>
        [HttpGet]
        public List<GetMasterScreenControlMapping> Get(int screenID)
        {
            return masterScreen.GetScreenControlsByScreenID(screenID);
        }
        /// <summary>
        /// To save the Screen Controls Data
        /// </summary>
        /// <param name="screenControl">MasterScreenControlData</param>
        /// <returns>Id of saved record</returns>
        [HttpPost]
        public int Post(List<MasterScreenControlMapping> screenControl)
        {
            return masterScreen.SaveScreenControlsByScreenID(screenControl);
        }
    }
}
