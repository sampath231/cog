﻿//-----------------------------------------------------------------------
// <copyright file="ErrorController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Diagnostics;
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_CommonHelpers;
    using OneC_3601_AdminAPI.Models;

    /// <summary>
    /// Controller class to handle errors
    /// </summary>
    [Route("ImmiWorld/Nomination/[controller]")]
    [ApiController]
    public class ErrorController : ControllerBase
    {
        /// <summary>
        /// Method to handle errors
        /// </summary>
        /// <returns></returns>
        
        [ApiExplorerSettings(IgnoreApi = true)]
        [HttpGet("/Error")]
        public ErrorDetails Index()
        {
            var exception = HttpContext.Features.Get<IExceptionHandlerFeature>();

            string controllerName = HttpContext.Request.RouteValues["controller"].ToString();
            string actionName = HttpContext.Request.RouteValues["action"].ToString();

            if (exception != null)
                LogHelper.LogExceptionAsync(exception.Error, appConstant.ApplicationName, controllerName + "/" + actionName);

            // Gets the status code from the exception or web server.
            int statusCode = Problem().StatusCode ?? 500;

            var errorModel = new ErrorDetails()
            {
                StatusCode = statusCode,
                Message = "Internal Server Error"
            };
            //return Problem();
            return errorModel;
        }
    }
}
