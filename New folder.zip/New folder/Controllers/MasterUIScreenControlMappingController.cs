﻿//-----------------------------------------------------------------------
// <copyright file="MasterUIScreenController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    /// <summary>
    /// class for master Ui Screen control mapping controller
    /// </summary>
    [ServiceFilter(typeof(RequestLogFilter))]
    [Route("ImmiWorld/Admin/[controller]")]
    [ApiController]
    public class MasterUIScreenControlMappingController : ControllerBase
    {
        private readonly IMasterUIScreenControlMapping iMasterUIScreenControlMapping;
        /// <summary>
        /// master ui screen control mapping constructor 
        /// </summary>
        /// <param name="IMasterUIScreenControlMapping"></param>
        public MasterUIScreenControlMappingController(IMasterUIScreenControlMapping IMasterUIScreenControlMapping)
        {
            iMasterUIScreenControlMapping = IMasterUIScreenControlMapping;
        }
        /// <summary>
        /// To save the master ui screen control mapping
        /// </summary>
        /// <param name=""></param>
        /// <returns>True</returns>
        [HttpPost("Post")]
        public bool SaveMasterUIScreenControlMapping(MasterUIScreenControlMapping masterUIScreenControlMapping)
        {
            return iMasterUIScreenControlMapping.SaveMasterUIScreenControlMapping(masterUIScreenControlMapping);
        }
    }
}
