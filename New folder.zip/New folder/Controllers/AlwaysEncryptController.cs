﻿using Microsoft.AspNetCore.Mvc;
using OneC_3601_AdminAPI.Filters;
using OneC_3601_AdminAPI.Models;
using OneC_3601_AdminAPI.Repositories.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Data.SqlClient;
using Microsoft.Data.SqlClient.AlwaysEncrypted.AzureKeyVaultProvider;
using Microsoft.Extensions.Primitives;
using System.Data;
using Azure.Identity;
//using OneC_3601_AdminAPI.Models.Dto;
using Newtonsoft.Json;

namespace GMT.Services.AdminAPI.Controllers
{
    [ServiceFilter(typeof(RequestLogFilter))]
    [ApiController]
    [Route("ImmiWorld/Admin/[controller]")]
    public class AlwaysEncryptController : Controller
    {
        private readonly IMasterServices _masterServices;
        private readonly ILogger<AlwaysEncryptController> _logger;
        private readonly string HeaderKeyName;
        private readonly string connectionString;
        private static bool isRegisterAKV = false;

        public AlwaysEncryptController(IMasterServices masterServices, ILogger<AlwaysEncryptController> logger, IConfiguration configuration)
        {
            _masterServices = masterServices;
            _logger = logger;
            // connectionString = configuration.GetValue<string>("EncryptedConnectionString");
            connectionString = "Data Source=ctsazsimidstfd1.inso13dfbbbfa2150.database.windows.net;Initial Catalog=OneC_1598;Persist Security Info=False;MultipleActiveResultSets=False;Connect Timeout=30;Encrypt=True;TrustServerCertificate=False;MultiSubnetFailover=True;Uid=OneC_1598;PWd=VRA1598#NonProd;Column Encryption Setting = Enabled";
            HeaderKeyName = "associateid";

            if (!isRegisterAKV)
            {
               // ManagedIdentityCredential credential = new ManagedIdentityCredential();
                SharedTokenCacheCredential credential = new SharedTokenCacheCredential();

                // Initialize AKV provider
                SqlColumnEncryptionAzureKeyVaultProvider akvProvider = new SqlColumnEncryptionAzureKeyVaultProvider(credential);

                // Register AKV provider
                Microsoft.Data.SqlClient.SqlConnection.RegisterColumnEncryptionKeyStoreProviders(customProviders: new Dictionary<string, SqlColumnEncryptionKeyStoreProvider>(capacity: 1, comparer: StringComparer.OrdinalIgnoreCase)
                {
                    { SqlColumnEncryptionAzureKeyVaultProvider.ProviderName, akvProvider}
                });
                Console.WriteLine("AKV provider Registered");
                isRegisterAKV = true;
            }
        }

        /// <summary>
        /// Added for liveness configuration in AKS
        /// </summary>
        /// <returns>string</returns>
        [HttpGet("GetLiveStatus")]
        public string GetLiveStatus()
        {
            return "API is working";
        }


        [HttpGet("GetCountries")]
        public object GetCountries(string? countryName = "")
        {
            _logger.LogInformation(1001, "Getting all the countries name at {time}", DateTime.Now.ToLongTimeString());
            Request.Headers.TryGetValue("Authorization", out var headerValue);
            try
            {
                throw new Exception("This is a test Exception");
            }
            catch (Exception e)
            {
                _logger.LogError(e, headerValue);
            }
            return _masterServices.GetCountries(countryName);
        }
        [HttpGet("GetVisaTypes")]
        public async Task<object> GetVisaTypesAsync(string? visaName = "", int? countryId = 0)
        {

            Request.Headers.TryGetValue(HeaderKeyName, out StringValues headerValue);

            _logger.LogDebug("visaName {0} countryId {2}", visaName, countryId);
            //_logger.LogInformation("Getting all the Visa name");
            _logger.LogInformation(1001, "User: {headerValue} Getting all the Visa name at: {time}", headerValue, DateTime.Now.ToLongTimeString());
            if (countryId == 2)
                _logger.LogWarning("For countryId {1} VisaName are not available", countryId);


            ////ManagedIdentityCredential credential = new ManagedIdentityCredential();
            //SharedTokenCacheCredential credential = new SharedTokenCacheCredential();

            //// Initialize AKV provider
            //SqlColumnEncryptionAzureKeyVaultProvider akvProvider = new SqlColumnEncryptionAzureKeyVaultProvider(credential);
            ////SqlColumnEncryptionAzureKeyVaultProvider azureKeyVaultProvider = new SqlColumnEncryptionAzureKeyVaultProvider(GetToken);
            //// Register AKV provider
            //Microsoft.Data.SqlClient.SqlConnection.RegisterColumnEncryptionKeyStoreProviders(customProviders: new Dictionary<string, SqlColumnEncryptionKeyStoreProvider>(capacity: 1, comparer: StringComparer.OrdinalIgnoreCase)
            //    {
            //        { SqlColumnEncryptionAzureKeyVaultProvider.ProviderName, akvProvider}
            //    });
            //Console.WriteLine("AKV provider Registered");

            using (var conn = new Microsoft.Data.SqlClient.SqlConnection(connectionString))
            {
                await conn.OpenAsync();
                using (Microsoft.Data.SqlClient.SqlCommand cmd = conn.CreateCommand())
                {
                    cmd.CommandText = @"INSERT INTO [dbo].[test_crud_master] ( [associateID] ,[flagType] ,[flagValueAccess] ,[flagExpiryDate] ,[flagComment] ,[countryID],[visaTypeID]) VALUES (@associateID, @flagType, @flagValueAccess, @flagExpiryDate, @flagComment, @countryID, @visaTypeID);";

                    //@associateID, @flagType, @flagValueAccess, @flagExpiryDate, @flagComment, @countryID, @visaTypeID

                    Microsoft.Data.SqlClient.SqlParameter paramassociateID = cmd.CreateParameter();
                    paramassociateID.ParameterName = @"@associateID";
                    paramassociateID.SqlDbType = SqlDbType.VarChar;
                    paramassociateID.Direction = ParameterDirection.Input;
                    paramassociateID.Value = "2058840";
                    cmd.Parameters.Add(paramassociateID);

                    Microsoft.Data.SqlClient.SqlParameter paramflagType = cmd.CreateParameter();
                    paramflagType.ParameterName = @"@flagType";
                    paramflagType.SqlDbType = SqlDbType.VarChar;
                    paramflagType.Direction = ParameterDirection.Input;
                    paramflagType.Value = "Y";
                    paramflagType.Size = 1;
                    cmd.Parameters.Add(paramflagType);

                    Microsoft.Data.SqlClient.SqlParameter paramflagValueAccess = cmd.CreateParameter();
                    paramflagValueAccess.ParameterName = @"@flagValueAccess";
                    paramflagValueAccess.DbType = DbType.AnsiStringFixedLength;
                    paramflagValueAccess.Direction = ParameterDirection.Input;
                    paramflagValueAccess.Value = "GM,PM,AC";
                    paramflagValueAccess.Size = 10;
                    cmd.Parameters.Add(paramflagValueAccess);

                    Microsoft.Data.SqlClient.SqlParameter paramflagExpiryDate = cmd.CreateParameter();
                    paramflagExpiryDate.ParameterName = @"@flagExpiryDate";
                    paramflagExpiryDate.SqlDbType = SqlDbType.Date;
                    paramflagExpiryDate.Direction = ParameterDirection.Input;
                    paramflagExpiryDate.Value = new DateTime(2024, 09, 09);
                    cmd.Parameters.Add(paramflagExpiryDate);

                    Microsoft.Data.SqlClient.SqlParameter paramflagComment = cmd.CreateParameter();
                    paramflagComment.ParameterName = @"@flagComment";
                    paramflagComment.SqlDbType = SqlDbType.VarChar;
                    paramflagComment.Direction = ParameterDirection.Input;
                    paramflagComment.Value = "Test Comment 2058840";
                    cmd.Parameters.Add(paramflagComment);

                    Microsoft.Data.SqlClient.SqlParameter paramcountryID = cmd.CreateParameter();
                    paramcountryID.ParameterName = @"@countryID";
                    paramcountryID.SqlDbType = SqlDbType.Int;
                    paramcountryID.Direction = ParameterDirection.Input;
                    paramcountryID.Value = 1;
                    cmd.Parameters.Add(paramcountryID);

                    Microsoft.Data.SqlClient.SqlParameter paramvisaTypeID = cmd.CreateParameter();
                    paramvisaTypeID.ParameterName = @"@visaTypeID";
                    paramvisaTypeID.SqlDbType = SqlDbType.Int;
                    paramvisaTypeID.Direction = ParameterDirection.Input;
                    paramvisaTypeID.Value = 1;
                    cmd.Parameters.Add(paramvisaTypeID);


                    cmd.ExecuteNonQuery();
                }

                using (Microsoft.Data.SqlClient.SqlDataAdapter sqlDataAdapter = new Microsoft.Data.SqlClient.SqlDataAdapter($"SELECT [associateID], [flagType],[flagValueAccess], [flagExpiryDate], [flagComment], [countryID], [visaTypeID] from test_crud_master order by uniqID desc ",
                                                            conn))
                {
                    DataTable dt = new DataTable();
                    sqlDataAdapter.Fill(dt);

                }
            }


            return _masterServices.GetVisaTypes(visaName, countryId);
        }
        [HttpGet("GetEncryptColumm")]
        public object GetEncryptColumm()
        {
          //  List<Always_Encryptcolumn> encryptcolumns = new List<Always_Encryptcolumn>();
            //string queryString = "Select top 50 EncVisaType from gmt.formdata";

            //using (SqlConnection connection = new SqlConnection(connectionString))            
            //{
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            connection.Open();
            SqlParameter type;
            //Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            command.CommandType = CommandType.StoredProcedure;
            type = new SqlParameter("@type", SqlDbType.VarChar);
            command.Parameters.Add(type);
            type.Value = "GetEncryptColumm";
            DataTable dt = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap = new SqlDataAdapter(command);
            adap.Fill(dt);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " GetEncryptColumm");
            connection.Close();
            //using (SqlDataReader reader = command.ExecuteReader())
            //{
            //    if (reader.HasRows)
            //    {
            //        while (reader.Read())
            //        {
            //            encryptcolumn.visaType = reader["EncVisaType"].ToString();
            //            encryptcolumns.Add(encryptcolumn);
            //        }
            //    }
            //    reader.Close();
            //}
            //Console.WriteLine(DateTime.Now);
            //}
            return JsonConvert.SerializeObject(dt);
        }



        [HttpGet("GetNormaltColumm")]
        public object GetNormaltColumm()
        {

            //List<Always_Encryptcolumn> encryptcolumns = new List<Always_Encryptcolumn>();
            //string queryString = "Select top 50 visaType from gmt.formdata";


            //using (SqlConnection connection = new SqlConnection(connectionString))               
            //{
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            connection.Open();
            SqlParameter type;
           // Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            command.CommandType = CommandType.StoredProcedure;
            type = new SqlParameter("@type", SqlDbType.VarChar);
            command.Parameters.Add(type);
            type.Value = "GetNormaltColumm";
            DataTable dt = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap = new SqlDataAdapter(command);
            adap.Fill(dt);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " GetNormaltColumm");
            connection.Close();

            //using (SqlDataReader reader = command.ExecuteReader())
            //{
            //    if (reader.HasRows)
            //    {
            //        while (reader.Read())
            //        {
            //            encryptcolumn.visaType = reader["visaType"].ToString();
            //            encryptcolumns.Add(encryptcolumn);                            
            //        }
            //    }
            //    reader.Close();
            //}

            //}
            return JsonConvert.SerializeObject(dt);
        }

        [HttpGet("Get1NormalEncryptColumn")]
        public object Get1NormalEncryptColumn()
        {

            //List<Always_Encryptcolumn> encryptcolumns = new List<Always_Encryptcolumn>();
            //string queryString = "Select top 50 visaType from gmt.formdata";


            //using (SqlConnection connection = new SqlConnection(connectionString))               
            //{
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            connection.Open();
            SqlParameter type;
            //Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            command.CommandType = CommandType.StoredProcedure;
            type = new SqlParameter("@type", SqlDbType.VarChar);
            command.Parameters.Add(type);
            type.Value = "Get1NormalEncryptColumn";
            DataTable dt = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap = new SqlDataAdapter(command);
            adap.Fill(dt);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " Get1NormalEncryptColumn");
            connection.Close();

            //using (SqlDataReader reader = command.ExecuteReader())
            //{
            //    if (reader.HasRows)
            //    {
            //        while (reader.Read())
            //        {
            //            encryptcolumn.visaType = reader["visaType"].ToString();
            //            encryptcolumns.Add(encryptcolumn);                            
            //        }
            //    }
            //    reader.Close();
            //}

            //}
            return JsonConvert.SerializeObject(dt);
        }

        [HttpGet("GetEncryptNormalColumn")]
        public object GetEncryptNormalColumn()
        {
           // List<SingleEncrytedColumn> encryptcolumns = new List<SingleEncrytedColumn>();
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            connection.Open();
            SqlParameter type;
            //Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            command.CommandType = CommandType.StoredProcedure;
            type = new SqlParameter("@type", SqlDbType.VarChar);
            command.Parameters.Add(type);
            type.Value = "GetEncryptNormalColumn";
            DataTable dt = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap = new SqlDataAdapter(command);
            adap.Fill(dt);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " GetEncryptNormalColumn");
            connection.Close();
            //string queryString = "Select top 50 ProjectName,Billable from gmt.formdata";
            //using (SqlConnection connection = new SqlConnection(connectionString))
            //using (SqlCommand command = new SqlCommand(queryString, connection))
            //{
            //    connection.Open();
            //    SingleEncrytedColumn encryptcolumn = new SingleEncrytedColumn();
            //    using (SqlDataReader reader = command.ExecuteReader())
            //    {
            //        if (reader.HasRows)
            //        {
            //            while (reader.Read())
            //            {
            //                encryptcolumn.Billable = reader["Billable"].ToString();
            //                encryptcolumn.ProjectName = reader["ProjectName"].ToString();
            //                encryptcolumns.Add(encryptcolumn);
            //            }
            //        }
            //        reader.Close();
            //    }
            //}
            return JsonConvert.SerializeObject(dt);
        }

        [HttpGet("GetMultipleEncryptColumn")]
        public object GetMultipleEncryptColumn()
        {

           // List<MultipleColumnEncryptioncs> encryptcolumns = new List<MultipleColumnEncryptioncs>();
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            connection.Open();
            SqlParameter type;
            //Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            command.CommandType = CommandType.StoredProcedure;
            type = new SqlParameter("@type", SqlDbType.VarChar);
            command.Parameters.Add(type);
            type.Value = "GetMultipleEncryptColumn";
            DataTable dt = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap = new SqlDataAdapter(command);
            adap.Fill(dt);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " GetMultipleEncryptColumn");
            connection.Close();
            //string queryString = "Select top 50 ProjectName,Billable,visaType,EncVisaType,countryType from gmt.formdata";
            //using (SqlConnection connection = new SqlConnection(connectionString))
            //using (SqlCommand command = new SqlCommand(queryString, connection))
            //{
            //    connection.Open();
            //    MultipleColumnEncryptioncs encryptcolumn = new MultipleColumnEncryptioncs();
            //    using (SqlDataReader reader = command.ExecuteReader())
            //    {
            //        if (reader.HasRows)
            //        {
            //            while (reader.Read())
            //            {
            //                encryptcolumn.ProjectName = reader["ProjectName"].ToString();
            //                encryptcolumn.Billable = reader["Billable"].ToString();
            //                encryptcolumn.visaType = reader["visaType"].ToString();
            //                encryptcolumn.EncVisaType = reader["EncVisaType"].ToString();
            //                encryptcolumn.countryType = reader["countryType"].ToString();
            //                encryptcolumns.Add(encryptcolumn);
            //            }
            //        }
            //        reader.Close();
            //    }
            //}
            return JsonConvert.SerializeObject(dt);
        }
        [HttpGet("GetMultipleEncryptColumns")]
        public object GetMultipleEncryptColumns()
        {

            //List<MultipleColumnEncryptioncs> encryptcolumns = new List<MultipleColumnEncryptioncs>();
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            connection.Open();
            SqlParameter type;
            //Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            command.CommandType = CommandType.StoredProcedure;
            type = new SqlParameter("@type", SqlDbType.VarChar);
            command.Parameters.Add(type);
            type.Value = "GetMultipleEncryptColumns";
            DataTable dt = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap = new SqlDataAdapter(command);
            adap.Fill(dt);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " GetMultipleEncryptColumns");
            connection.Close();

            return JsonConvert.SerializeObject(dt);
        }

        [HttpGet("GetParentEncryptColumns")]
        public object GetParentEncryptColumns()
        {
            GetEncryptColumm();
            GetNormaltColumm();
            Get1NormalEncryptColumn();
            GetEncryptNormalColumn();
            GetMultipleEncryptColumn();
            GetMultipleEncryptColumns();

            return "";
        }

        [HttpGet("GetAllEncryptColumns")]
        public object GetAllEncryptColumns()
        {
           // List<MultipleColumnEncryptioncs> encryptcolumns = new List<MultipleColumnEncryptioncs>();
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            connection.Open();
            SqlParameter type;
            //Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            command.CommandType = CommandType.StoredProcedure;
            type = new SqlParameter("@type", SqlDbType.VarChar);
            command.Parameters.Add(type);
            type.Value = "GetEncryptColumm";
            DataTable dt = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap = new SqlDataAdapter(command);
            adap.Fill(dt);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " GetEncryptColumm");

            //List<MultipleColumnEncryptioncs> encryptcolumns = new List<MultipleColumnEncryptioncs>();
            //SqlConnection connection = new SqlConnection(connectionString);
            //SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            //connection.Open();
            //SqlParameter type;
            //Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            //command.CommandType = CommandType.StoredProcedure;
            //type = new SqlParameter("@type", SqlDbType.VarChar);
            //command.Parameters.Add(type);
            type.Value = "GetNormaltColumm";
            DataTable dt6 = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap6 = new SqlDataAdapter(command);
            adap6.Fill(dt6);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " GetNormaltColumm");

            //List<MultipleColumnEncryptioncs> encryptcolumns = new List<MultipleColumnEncryptioncs>();
            //SqlConnection connection = new SqlConnection(connectionString);
            //SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            //connection.Open();
            //SqlParameter type;
            //Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            //command.CommandType = CommandType.StoredProcedure;
            //type = new SqlParameter("@type", SqlDbType.VarChar);
            //command.Parameters.Add(type);
            type.Value = "Get1NormalEncryptColumn";
            DataTable dt5 = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap5 = new SqlDataAdapter(command);
            adap5.Fill(dt5);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " Get1NormalEncryptColumn");


            //List<MultipleColumnEncryptioncs> encryptcolumns = new List<MultipleColumnEncryptioncs>();
            //SqlConnection connection = new SqlConnection(connectionString);
            //SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            //connection.Open();
            //SqlParameter type;
            //Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            //command.CommandType = CommandType.StoredProcedure;
            //type = new SqlParameter("@type", SqlDbType.VarChar);
            //command.Parameters.Add(type);
            type.Value = "GetEncryptNormalColumn";
            DataTable dt4 = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap4 = new SqlDataAdapter(command);
            adap4.Fill(dt4);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " GetEncryptNormalColumn");


            //List<MultipleColumnEncryptioncs> encryptcolumns = new List<MultipleColumnEncryptioncs>();
            //SqlConnection connection = new SqlConnection(connectionString);
            //SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            //connection.Open();
            //SqlParameter type;
            //Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            //command.CommandType = CommandType.StoredProcedure;
            //type = new SqlParameter("@type", SqlDbType.VarChar);
            //command.Parameters.Add(type);
            type.Value = "GetMultipleEncryptColumn";
            DataTable dt2 = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap2 = new SqlDataAdapter(command);
            adap2.Fill(dt2);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " GetMultipleEncryptColumn");

            //List<MultipleColumnEncryptioncs> encryptcolumns = new List<MultipleColumnEncryptioncs>();
            //SqlConnection connection = new SqlConnection(connectionString);
            //SqlCommand command = new SqlCommand("dbo.get_formdata", connection);
            //connection.Open();
            //SqlParameter type;
            //Always_Encryptcolumn encryptcolumn = new Always_Encryptcolumn();
            //command.CommandType = CommandType.StoredProcedure;
            //type = new SqlParameter("@type", SqlDbType.VarChar);
            //command.Parameters.Add(type);
            type.Value = "GetMultipleEncryptColumns";
            DataTable dt1 = new DataTable();
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff"));
            SqlDataAdapter adap1 = new SqlDataAdapter(command);
            adap1.Fill(dt1);
            Console.WriteLine(DateTime.Now.ToString("hh.mm.ss.fff") + " GetMultipleEncryptColumns");


            return JsonConvert.SerializeObject(dt);
        }
    }








    //public static async Task<string> KeyVaultAuthenticationCallback(string authority, string resource, string scope)
    //{
    //    return await Task.Run(() => new ManagedIdentityCredential().GetToken(new TokenRequestContext(new string[] { "https://azsqlmiagkey01.azure.net/.default" })).Token);
    //    /********************** Alternatively, to use User Assigned Managed Identity ****************/
    //    // https://azsqlmiagkey01.vault.azure.net/keys/CMKAuto2/a7f72c1a67404af1a70b0aed1e1333ea
    //    // var clientId = {clientId_of_UserAssigned_Identity};
    //    // return await Task.Run(() => new ManagedIdentityCredential(clientId).GetToken(new TokenRequestContext(new string [] {"https://vault.azure.net/.default"})).Token);
    //}
}
