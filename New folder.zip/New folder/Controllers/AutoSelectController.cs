﻿ //-----------------------------------------------------------------------
        // <copyright file="AutoSelectController.cs" company="CTS">
        //     Copyright (c) . All rights reserved.
        // </copyright>
        //-----------------------------------------------------------------------
    namespace OneC_3601_AdminAPI.Controllers
    {
        using global::OneC_3601_AdminAPI.Filters;
        using global::OneC_3601_AdminAPI.Models;
        using global::OneC_3601_AdminAPI.Repositories.Interfaces;
        using Microsoft.AspNetCore.Mvc;
        using OneC_3601_AdminAPI.Repositories.Persistence;
    /// <summary>
    /// class for AutoSelect controller
    /// </summary
    /// 
    [ServiceFilter(typeof(RequestLogFilter))]
    [ApiController]
    [Route("ImmiWorld/Admin/[controller]")]
    public class AutoSelectController : ControllerBase
    {
        private readonly IAutoSelect autoSelectServices;
        private readonly IMasterControl masterControlService;
        /// <summary>
        /// AutoSelect Controls constructor 
        /// </summary>
        /// <param name="IAutoSelect">Interface for IAutoSelect</param>
        public AutoSelectController(IAutoSelect AutoSelectServices, IMasterControl imastercontrolservices)
        {
            autoSelectServices = AutoSelectServices;
            masterControlService = imastercontrolservices;
        }

        /// <summary>
        /// TO get the data of get AutoSelect setting
        /// </summary>
        /// <param name=" controlId">AutoSelect</param>
        /// <returns> Get the data </returns>

        [HttpGet]
        public List<MasterSelect> Get(int controlId)
        {
            return autoSelectServices.GetSelectControlConfig(controlId);
        }

        /// <summary>
        /// To Get the  AutoSelect Controls Data
        /// </summary>
        /// <param name=" master">AutoSelect Data</param>
        /// <returns>Autosave of control Type </returns>
        /// 

        [HttpPost]
        public int Post(MasterSelect master)
        {
            return autoSelectServices.SaveSelectControlConfig(master);
        }

        /// <summary>
        /// To save the  AutoSelect Controls Data
        /// </summary>
        /// <param name=" Select"></param>
        /// <returns>Autosave of control Type </returns>
        [HttpGet("controls")]
        public List<MasterControls> GetControls()
        {
            return masterControlService.GetControlsByControlType("Select");
        }
    }

}
