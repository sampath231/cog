﻿//-----------------------------------------------------------------------
// <copyright file="MasterUIScreenSectionsController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------


namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    /// <summary>
    /// class for master ui screen section controller
    /// </summary>
    [ServiceFilter(typeof(RequestLogFilter))]
    [Route("ImmiWorld/Admin/[controller]")]
    [ApiController]
    public class MasterUIScreenSectionsController : ControllerBase
    {
        private readonly IMasterUIScreenSections iMasterUIScreenSections;
        /// <summary>
        /// master Screen section constructor 
        /// </summary>
        /// <param name="IMasterUIScreenSections"></param>
        public MasterUIScreenSectionsController(IMasterUIScreenSections IMasterUIScreenSections)
        {
            iMasterUIScreenSections = IMasterUIScreenSections;
        }
        /// <summary>
        /// To get the list of master screens
        /// </summary>
        /// <param name=""></param>
        /// <returns>List of master screens</returns>
        [HttpGet("Get")]
        public List<MasterUIScreenSections> GetMasterUIScreenSectionsData(int screenId)
        {
            return iMasterUIScreenSections.GetMasterUIScreenSections(screenId);
        }
    }
}
