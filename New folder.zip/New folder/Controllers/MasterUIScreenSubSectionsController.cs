﻿//-----------------------------------------------------------------------
// <copyright file="MasterUIScreenSubSectionsController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------


namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    /// <summary>
    /// class for master ui screen subsection controller
    /// </summary>
    [ServiceFilter(typeof(RequestLogFilter))]
    [Route("ImmiWorld/Admin/[controller]")]
    [ApiController]
    public class MasterUIScreenSubSectionsController : ControllerBase
    {
        private readonly IMasterUIScreenSubSections iMasterUIScreenSubSections;
        /// <summary>
        /// master Screen SubSections constructor 
        /// </summary>
        /// <param name="IMasterUIScreenSubSections"></param>
        public MasterUIScreenSubSectionsController(IMasterUIScreenSubSections IMasterUIScreenSubSections)
        {
            iMasterUIScreenSubSections = IMasterUIScreenSubSections;
        }
        /// <summary>
        /// To get the list of master screen subsections
        /// </summary>
        /// <param name=""></param>
        /// <returns>List of master screen subsections</returns>
        [HttpGet("Get")]
        public List<MasterUIScreenSubSections> GetMasterUIScreenSubSectionsData(int SectionId)
        {
            return iMasterUIScreenSubSections.GetMasterUIScreenSubSections(SectionId);
        }
    }
}
