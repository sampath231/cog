﻿//-----------------------------------------------------------------------
// <copyright file="MasterControlController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------


namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    /// <summary>
    /// class for master control controller
    /// </summary>
    [ServiceFilter(typeof(RequestLogFilter))]
    [Route("ImmiWorld/Admin/[controller]")]
    [ApiController]
    public class MasterControlController : ControllerBase
    {
        private readonly IMasterControl iMasterControl;
        /// <summary>
        /// master control constructor 
        /// </summary>
        /// <param name="iMasterControl"></param>
        public MasterControlController(IMasterControl IMasterControl)
        {
            iMasterControl = IMasterControl;
        }
        /// <summary>
        /// To get the list of master controls
        /// </summary>
        /// <param name=""></param>
        /// <returns>List of master controls</returns>
        [HttpGet("Get")]
        public List<MasterControlSettings> GetMasterControlsData()
        {
            return iMasterControl.GetMasterControls();
        }

        /// <summary>
        /// To save the master control
        /// </summary>
        /// <param name=""></param>
        /// <returns>True/False</returns>
        [HttpPost("Post")]
        public bool SaveMasterControlsData(MasterControlSettings masterControl)
        {
            return iMasterControl.SaveMasterControl(masterControl);
        }
    }
}
