﻿//-----------------------------------------------------------------------
// <copyright file="ControlTypeController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    /// <summary>
    /// class for Control Type Controller
    /// </summary>
    [ServiceFilter(typeof(RequestLogFilter))]
    [ApiController]
    [Route("ImmiWorld/[controller]")]
    public class ControlTypeController : Controller
    {
        private readonly IMasterScreen masterScreen;
        /// <summary>
        /// Control Type constructor 
        /// </summary>
        /// <param name="imasterScreen">Interface for masterScreens</param>
        public ControlTypeController(IMasterScreen imasterScreen)
        {
            masterScreen = imasterScreen;
        }
        /// <summary>
        /// To get the list of Master Controls
        /// </summary>
        /// <returns>List of Master Controls</returns>
        [HttpGet]
        public List<MasterControls> Get()
        {
            return masterScreen.GetAllMasterControlTypes();
        }
    }
}
