﻿//-----------------------------------------------------------------------
// <copyright file="ScreensController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    /// <summary>
    /// class for Screens Controller
    /// </summary>
    [ServiceFilter(typeof(RequestLogFilter))]
    [ApiController]
    [Route("ImmiWorld/[controller]")]
    public class ScreensController : Controller
    {
        private readonly IMasterScreen masterScreen;
        /// <summary>
        /// Screens constructor 
        /// </summary>
        /// <param name="imasterScreen">Interface for masterScreens</param>
        public ScreensController(IMasterScreen imasterScreen)
        {
            masterScreen = imasterScreen;
        }
        /// <summary>
        /// To get the list of Master Screens
        /// </summary>
        /// <returns>List of Master Screens</returns>
        [HttpGet]
        public List<MasterScreens> Get()
        {
            return masterScreen.GetMasterScreens();
        }
        /// <summary>
        /// To get the list of countries
        /// </summary>
        /// <param name="masterscreendata">Master Screens</param>
        /// <returns>Integer of ScreenID</returns>
        [HttpPost]
        public int Post(List<MasterScreens> masterscreendata)
        {
            masterScreen.SaveMasterScreens(masterscreendata);
            return 1;

        }
    }
}
