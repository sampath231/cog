﻿//-----------------------------------------------------------------------
// <copyright file="MasterController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Controllers
{
    using System.Collections.Generic;
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    /// <summary>
    /// class for master controller
    /// </summary>
    [ServiceFilter(typeof(RequestLogFilter))]
    [ApiController]
    [Route("/Admin/[controller]")]
    public class MasterController : Controller
    {
        private readonly IMasterServices masterServices;
        /// <summary>
        /// master constructor 
        /// </summary>
        /// <param name="imasterServices"></param>
        public MasterController(IMasterServices imasterServices)
        {
            masterServices = imasterServices;
        }

        /// <summary>
        /// Added for liveness configuration in AKS
        /// </summary>
        /// <returns>string</returns>
        [HttpGet("GetLiveStatus")]
        public string GetLiveStatus()
        {
            return "API is working";
        }

        /// <summary>
        /// To get the list of countries
        /// </summary>
        /// <param name="countryName">Country Name</param>
        /// <returns>List of countries</returns>
        [HttpGet("country")]
        public List<Country> country(string? countryName)
        {
            return masterServices.GetCountries(countryName);
        }

        /// <summary>
        /// To get the list of visa
        /// </summary>
        /// <param name="visaName">Visa Name</param>
        /// <param name="countryId">Country ID</param>
        /// <returns>Lists all visas/ based on country</returns>
        [HttpGet("visa")]
        public List<VisaType> visa(string? visaName, int? countryId)
        {
            return masterServices.GetVisaTypes(visaName, countryId);
        }

        /// <summary>
        /// To get the list of key values
        /// </summary>
        /// <param name="keyName">Key Name</param>
        /// <returns>Lists all Key Values</returns>
        [HttpGet("KeyValue")]
        public List<MasterKeyValues> KeyValue(string? keyName)
        {
            return masterServices.GetMasterKeyValues(keyName);
        }


        /// <summary>
        /// Test method to check logic app access from AKS
        /// </summary>
        /// <returns></returns>

        [HttpGet("GetWorkFlowResponse")]
        public async Task<string> GetWorkFlowResponse()
        {
            var client = new HttpClient();
            try
            {
                var response = await client.GetAsync("https://ctsinaz1clogicapp02.azurewebsites.net:443/api/Stateful/triggers/manual/invoke?api-version=2022-05-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=8_iwcog7Jwbw5Bg_WbwBiaBQnlZZuj4IVmYhcDjjN1g");
                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    return result;
                }
                else
                {
                    return response.ToString();
                }
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
    }
}
