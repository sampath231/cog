﻿//-----------------------------------------------------------------------
// <copyright file="ControlOptionsController.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Controllers
{
    using Microsoft.AspNetCore.Mvc;
    using OneC_3601_AdminAPI.Filters;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    [ServiceFilter(typeof(RequestLogFilter))]
    [ApiController]
    [Route("ImmiWorld/[controller]")]
    public class ControlsDataController : Controller
    {
        private readonly IMasterScreen masterScreen;
        /// <summary>
        /// Controls Data constructor 
        /// </summary>
        /// <param name="imasterScreen">Interface for masterScreens</param>
        public ControlsDataController(IMasterScreen imasterScreen)
        {
            masterScreen = imasterScreen;
        }
        /// <summary>
        /// To get the JSON string of Controls Data
        /// </summary>
        /// <returns>JSON string of Controls Data</returns>
        [HttpGet]
        public string Get()
        {
            return masterScreen.GetMasterDataControls();
        }
    }
}
