﻿namespace OneC_3601_AdminAPI.Models
{
    public class GetMasterScreenControlMapping
    {
        /// <summary>
        /// Gets or sets the ScreenControl_MappingID
        /// </summary>
        public int ScreenControl_MappingID { get; set; }
        /// <summary>
        /// Gets or sets the Master_ScreenID
        /// </summary>
        public int Master_ScreenID { get; set; }
        /// <summary>
        /// Gets or sets the Control_Type_ID
        /// </summary>
        public Int16 Control_Type_ID { get; set; }
        /// <summary>
        /// Gets or sets the Control_Name
        /// </summary>
        public string? Control_Name { get; set; }
        /// <summary>
        /// Gets or sets the Control_Required
        /// </summary>
        public bool Control_Required { get; set; }
        /// <summary>
        /// Gets or sets the Control_ColumnType
        /// </summary>
        public string Control_ColumnType { get; set; }
        /// <summary>
        /// Gets or sets the Reference_Table
        /// </summary>
        public int Reference_Table { get; set; }
        /// <summary>
        /// Gets or sets the Reference_Column
        /// </summary>
        public int Reference_Column { get; set; }
        /// <summary>
        /// Gets or sets the IsCreated
        /// </summary>
        public bool IsCreated { get; set; }
        /// <summary>
        /// Gets or sets the IsActive
        /// </summary>
        public bool IsActive { get; set; }
        /// <summary>
        /// Gets or sets the Control_ColumnDataType
        /// </summary>
        public string Control_ColumnDataType { get; set; }
    }
}
