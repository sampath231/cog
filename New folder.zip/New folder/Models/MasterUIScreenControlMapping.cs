﻿//-----------------------------------------------------------------------
// <copyright file="MasterUIScreenControlMapping.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Models
{
    /// <summary>
    /// class for Master UI Screen Control Mapping
    /// </summary>
    public class MasterUIScreenControlMapping
    {
        /// <summary>
        /// Gets or sets the Mapping Id
        /// </summary>
        public int MappingID { get; set; }
        /// <summary>
        /// Gets or sets the Screen Id
        /// </summary>
        public int ScreenID { get; set; }
        /// <summary>
        /// Gets or sets the Section Id
        /// </summary>
        public int SectionID { get; set; }
        /// <summary>
        /// Gets or sets the SubSection Id
        /// </summary>
        public int SubSectionID { get; set; }
        /// <summary>
        /// Gets or sets the control Id
        /// </summary>
        public int ControlID { get; set; }
        /// <summary>
        /// Gets or sets the control Sequence
        /// </summary>
        public int ControlSequence { get; set; }
        /// <summary>
        /// Gets or sets the list of control dependency Id
        /// </summary>
        public int[] ControlDependencyID { get; set; }
    }




    /// <summary>
    /// class for Control Mapping
    /// </summary>
    public class ControlMapping
    {
        /// <summary>
        /// Gets or sets the dependency control Id
        /// </summary>
        public int DepControlID { get; set; }
    }




    /// <summary>
    /// class for Control
    /// </summary>
    public class Control
    {
        /// <summary>
        /// Gets or sets the control Id
        /// </summary>
        public int controlID { get; set; }
        /// <summary>
        /// Gets or sets the dependency control
        /// </summary>
        public List<ControlMapping> depControl { get; set; }
    }
}
