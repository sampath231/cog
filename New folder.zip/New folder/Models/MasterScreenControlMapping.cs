﻿//-----------------------------------------------------------------------
// <copyright file="MasterScreenControlMapping.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Models
{
    /// <summary>
    /// class for MasterScreenControlMapping
    /// </summary>
    public class MasterScreenControlMapping
    {
        /// <summary>
        /// Gets or sets the ScreenControl_MappingID
        /// </summary>
        public int ScreenControl_MappingID { get; set; }
        /// <summary>
        /// Gets or sets the Master_ScreenID
        /// </summary>
        public int Master_ScreenID { get; set; }
        /// <summary>
        /// Gets or sets the Control_Type_ID
        /// </summary>
        public Int16 Control_Type_ID { get; set; }
        /// <summary>
        /// Gets or sets the Control_Name
        /// </summary>
        public string Control_Name { get; set; }
        /// <summary>
        /// Gets or sets the Control_Value_Length
        /// </summary>
        public int Control_Value_Length { get; set; }
        /// <summary>
        /// Gets or sets the Control_Required
        /// </summary>
        public bool Control_Required { get; set; }
        /// <summary>
        /// Gets or sets the Control_ColumnType
        /// </summary>
        public string Control_ColumnType { get; set; }
        /// <summary>
        /// Gets or sets the AutoIncrement
        /// </summary>
        public string AutoIncrement { get; set; }
        /// <summary>
        /// Gets or sets the Reference_Table
        /// </summary>
        public int Reference_Table { get; set; }
        /// <summary>
        /// Gets or sets the Reference_Column
        /// </summary>
        public int Reference_Column { get; set; }
        /// <summary>
        /// Gets or sets the IsCreated
        /// </summary>
        public bool IsCreated { get; set; }
        /// <summary>
        /// Gets or sets the IsActive
        /// </summary>
        public bool IsActive { get; set; }
        /// <summary>
        /// Gets or sets the CreatedBy
        /// </summary>
        public string CreatedBy { get; set; }
        /// <summary>
        /// Gets or sets the CreatedDate
        /// </summary>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// Gets or sets the Control_ColumnDataType
        /// </summary>
        public string Control_ColumnDataType { get; set; }
    }
}
