﻿namespace OneC_3601_AdminAPI.Models
{
    public class MasterTableColumnSetting
    {
        public int TableColumnId { get; set; }
        public int TableId { get; set; }
        public string TableName { get; set; }
        public string TableColumnName { get; set; }
        public string SelectedColumn { get; set; }
        public string FilterColumn { get; set; }
        public string SortColumn { get; set; }
        public string SearchColumn { get; set; }
        public string FreezeColumn { get; set; }
        public DateTime InsertedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
    }
}
