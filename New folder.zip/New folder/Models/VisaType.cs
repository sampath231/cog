﻿//-----------------------------------------------------------------------
// <copyright file="VisaType.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Models
{
    /// <summary>
    /// Class for Visa Type
    /// </summary>
    public class VisaType
    {
        /// <summary>
        /// Gets or sets the Visa Type ID
        /// </summary>
        public int VisaTypeId { get; set; }
        /// <summary>
        /// Gets or sets the Visa Name
        /// </summary>
        public string VisaName { get; set; }
        /// <summary>
        /// Gets or sets the Visa Short Name
        /// </summary>
        public string VisaShortName { get; set; }
    }
}
