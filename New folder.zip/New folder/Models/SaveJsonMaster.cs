﻿//-----------------------------------------------------------------------
// <copyright file="SaveJsonMaster.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Models
{
    /// <summary>
    /// class for SaveJsonMaster
    /// </summary>
    public class SaveJsonMaster
    {
        /// <summary>
        /// Gets or sets the jsonData
        /// </summary>
        public string? jsonData { get; set; }
        /// <summary>
        /// Gets or sets the Master_ScreenID
        /// </summary>
        public int Master_ScreenID { get; set; }
        /// <summary>
        /// Gets or sets the AssociateId
        /// </summary>
        public string? AssociateId { get; set; }

    }
}
