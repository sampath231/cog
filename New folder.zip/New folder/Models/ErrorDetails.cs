﻿//-----------------------------------------------------------------------
// <copyright file="ErrorDetails.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Models
{
    using System.Text.Json;

    /// <summary>
    /// Class for Error Model
    /// </summary>
    public class ErrorDetails
    {
        /// <summary>
        /// Gets or sets Status Code
        /// </summary>
        public int StatusCode { get; set; }

        /// <summary>
        /// Gets or sets Message
        /// </summary>
        public string Message { get; set; }

        /// <summary>
        /// Method to convert model to Json string by overriding ToString()
        /// </summary>
        /// <returns></returns>
        public override string ToString()
        {
            return JsonSerializer.Serialize(this);
        }
    }
}
