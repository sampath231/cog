﻿//-----------------------------------------------------------------------
// <copyright file="MasterControlSettings.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Models
{
    /// <summary>
    /// class for MasterControls
    /// </summary>
    public class MasterControlSettings
    {
        /// <summary>
        /// Gets or sets the control Id
        /// </summary>
        public int controlId { get; set; }
        /// <summary>
        /// Gets or sets the control Name
        /// </summary>
        public string controlName { get; set; }
        /// <summary>
        /// Gets or sets the control Type
        /// </summary>
        public string controlType { get; set; }
        /// <summary>
        /// Gets or sets the control Required
        /// </summary>
        public string controlRequired { get; set; }
        /// <summary>
        /// Gets or sets the control Radio and Checkbox Options 
        /// </summary>
        public string controlTypeOptions { get; set; } = null;
        /// <summary>
        /// Gets or sets the control Created DateTime
        /// </summary>
        public DateTime controlsIsCreatedAt { get; set; }
        /// <summary>
        /// Gets or sets the control ToolTip
        /// </summary>
        public string controlTooltip { get; set; }
        /// <summary>
        /// Gets or sets the control Validation Type
        /// </summary>
        public string controlValidationType { get; set; } = null;
        /// <summary>
        /// Gets or sets the control Validation Message
        /// </summary>
        public string controlValidationMessage { get; set; } = null;
        /// <summary>
        /// Gets or sets the control ClassName
        /// </summary>
        public string controlClassName { get; set; } = null;
        /// <summary>
        /// Gets or sets the control Maximum value
        /// </summary>
        public int controlMaxValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the control minimum value
        /// </summary>
        public int controlMinValue { get; set; } = 0;
        /// <summary>
        /// Gets or sets the control DataType
        /// </summary>
        public string controlDataType { get; set; } = null;
        /// <summary>
        /// Gets or sets the control TabName
        /// </summary>
        public string controlTabNmae { get; set; } = null;
        /// <summary>
        /// Gets or sets the control Date Format
        /// </summary>
        public string controlDateFormat { get; set; } = null;
        /// <summary>
        /// Gets or sets the control Past Date
        /// </summary>
        public string controlPastDate { get; set; } = null;
        /// <summary>
        /// Gets or sets the control Future Date
        /// </summary>
        public string controlFutureDate { get; set; } = null;
        /// <summary>
        /// Gets or sets the control Dynamic Coloumn Name
        /// </summary>
        public string controlDynamicColName { get; set; } = null;
        /// <summary>
        /// Gets or sets the control Searchable
        /// </summary>
        public string controlSearchable { get; set; } = null;
        /// <summary>
        /// Gets or sets the control Select Screen
        /// </summary>
        public string controlSelectScreen { get; set; } = null;
        /// <summary>
        /// Gets or sets the control Purpose Request
        /// </summary>
        public string controlPurposeRequest { get; set; } = null;
        /// <summary>
        /// Gets or sets the control Select Section
        /// </summary>
        public string controlSelectSection { get; set; } = null;
    }
}
