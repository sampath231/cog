﻿//-----------------------------------------------------------------------
// <copyright file="CommonDataMaster.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Models
{
    /// <summary>
    /// class for CommonDataMaster
    /// </summary>
    public class CommonDataMaster
    {
        /// <summary>
        /// Gets or sets the DataKey
        /// </summary>
        public int DataKey { get; set; }
        /// <summary>
        /// Gets or sets the DataValue
        /// </summary>
        public string? Datavalue { get; set; }
    }
}
