﻿//-----------------------------------------------------------------------
// <copyright file="MasterUIScreenSubSections.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Models
{
    public class MasterUIScreenSubSections
    {
        /// <summary>
        /// Gets or sets the SubSection Id
        /// </summary>
        public string SubSectionId { get; set; }

        // <summary>
        /// Gets or sets the SubSection Name
        /// </summary>
        public string SubSectionName { get; set; }
    }
}
