﻿namespace OneC_3601_AdminAPI.Models
{
    public class ChildControlDetails
    {
        public int childControlId { get; set; }
        public string childControlName { get; set; }
        public string childControlType { get; set; }
        public string childControlRequired { get; set; }
    }
}
