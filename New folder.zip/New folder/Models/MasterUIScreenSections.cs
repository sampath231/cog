﻿//-----------------------------------------------------------------------
// <copyright file="MasterUIScreenSections.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Models
{
    public class MasterUIScreenSections
    {
        /// <summary>
        /// Gets or sets the Section Id
        /// </summary>
        public int SectionId { get; set; }

        /// <summary>
        /// Gets or sets the Section Name
        /// </summary>
        public string SectionName { get; set; }
    }
}
