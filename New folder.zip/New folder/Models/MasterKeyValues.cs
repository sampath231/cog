﻿//-----------------------------------------------------------------------
// <copyright file="MasterKeyValues.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Models
{
    /// <summary>
    /// class for MasterKeyValues
    /// </summary>
    public class MasterKeyValues
    {
        /// <summary>
        /// Gets or sets the KeyText
        /// </summary>
        public string KeyText { get; set; }

        /// <summary>
        /// Gets or sets the KeyValue
        /// </summary>
        public string KeyValue { get; set; }
    }
}
