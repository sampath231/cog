﻿//-----------------------------------------------------------------------
// <copyright file="MasterSearchFieldConfiguration.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Models
{ 

    /// <summary>
    /// class for MasterSearchFieldConfiguration
    /// </summary>
    public class MasterSearchFieldConfiguration
    {
    /// <summary>
    /// Gets or sets the SearchControlID
    /// </summary>
    public int SearchControlID { get; set; }
    /// <summary>
    /// Gets or sets the MinLength
    /// </summary>
    public string MinLength { get; set; }
    /// <summary>
    /// Gets or sets the SearchControl
    /// </summary>
    public string SearchControl { get; set; }
    /// <summary>
    /// Gets or sets the AutoFieldColumn
    /// </summary>
    public string AutoFieldColumn { get; set; }
    /// <summary>
    /// Gets or sets the DepColumn
    /// </summary>
    public string DepColumn { get; set; }
    /// <summary>
    /// Gets or sets the ApiUrl
    /// </summary>
    public string ApiUrl { get; set; }
      
    }
}
