﻿//-----------------------------------------------------------------------
// <copyright file="Country.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Models
{
    /// <summary>
    /// class for country
    /// </summary>
    public class Country
    {
        /// <summary>
        /// Gets or sets the Country ID
        /// </summary>
        public int CountryId { get; set; }
        /// <summary>
        /// Gets or sets the Country Name
        /// </summary>
        public string CountryName { get; set; }
        /// <summary>
        /// Gets or sets  the Country Short Name
        /// </summary>
        public string CountryShortName { get; set; }
    }
}
