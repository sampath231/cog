﻿//-----------------------------------------------------------------------
// <copyright file="MasterUIScreens.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Models
{
    public class MasterUIScreens
    {
        /// <summary>
        /// Gets or sets the screen Id
        /// </summary>
        public int ScreenId { get; set; }

        /// <summary>
        /// Gets or sets the screen Name
        /// </summary>
        public string ScreenName { get; set; }
    }
}
