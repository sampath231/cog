﻿//-----------------------------------------------------------------------
// <copyright file="MasterSelect.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Models
{
    /// <summary>
    /// class for MasterSelect
    /// </summary>
    public class MasterSelect
    {
        /// <summary>
        /// Gets or sets the SelectID
        /// </summary>
        public int SelectID { get; set; }
        /// <summary>
        /// Gets or sets the ApiEndPoint
        /// </summary>
        public string ApiEndPoint { get; set; }
        /// <summary>
        /// Gets or sets the KeyColumn
        /// </summary>
        public string KeyColumn { get; set; }
        /// <summary>
        /// Gets or sets the ValueColumn
        /// </summary>
        public string ValueColumn { get; set; }
        /// <summary>
        /// Gets or sets the SearchControl
        /// </summary>
        public string SearchControl { get; set; }
    }
}
