﻿//-----------------------------------------------------------------------
// <copyright file="MasterControls.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Models
{
    /// <summary>
    /// class for MasterControls
    /// </summary>
    public class MasterControls
    {
        /// <summary>
        /// Gets or sets the ControlID
        /// </summary>
        public Int16 ControlID { get; set; }
        /// <summary>
        /// Gets or sets the ControlName
        /// </summary>
        public string? ControlName { get; set; }
        /// <summary>
        /// Gets or sets the ControlToolTip
        /// </summary>
        public string? ControlToolTip { get; set; }
        
    }
}
