﻿//-----------------------------------------------------------------------
// <copyright file="MasterScreens.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Models
{
    /// <summary>
    /// class for MasterScreens
    /// </summary>
    public class MasterScreens
    {
        /// <summary>
        /// Gets or sets the ScreenID
        /// </summary>
        public int ScreenID { get; set; }
        /// <summary>
        /// Gets or sets the ScreenName
        /// </summary>
        public string? ScreenName { get; set; }
        /// <summary>
        /// Gets or sets the IsActive
        /// </summary>
        public bool IsActive { get; set; }
        /// <summary>
        /// Gets or sets the CreatedBy
        /// </summary>
        public string? CreatedBy { get; set; }
        /// <summary>
        /// Gets or sets the CreatedDate
        /// </summary>
        public DateTime CreatedDate { get; set; }
        /// <summary>
        /// Gets or sets the PKey_ColumnName
        /// </summary>
        public string? PKey_ColumnName { get; set; }
        /// <summary>
        /// Gets or sets the Key_Datatype
        /// </summary>
        public string? Key_Datatype { get; set; }
        /// <summary>
        /// Gets or sets the IsCreated
        /// </summary>
        public bool IsCreated { get; set; }
        /// <summary>
        /// Gets or sets the SchemaName
        /// </summary>
        public string? SchemaName { get; set; }

    }
}
