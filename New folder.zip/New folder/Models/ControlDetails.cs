﻿namespace OneC_3601_AdminAPI.Models
{
    public class ControlDetails
    {
        public int controlId { get; set; }
        public string controlName { get; set; }
        public string controlType { get; set; }
        public string controlRequired { get; set; }
        public List<ChildControlDetails> childControl { get; set; }
    }
}
