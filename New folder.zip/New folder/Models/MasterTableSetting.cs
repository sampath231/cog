﻿namespace OneC_3601_AdminAPI.Models
{
    public class MasterTableSetting
    {
        public int TableId { get; set; }
        public string TableName { get; set; }
        public string ApiEndPoint { get; set; }
        public bool Pagination { get; set; }
        public int PageSize { get; set; }
        public bool SelectAll { get; set; }
        public int FreezeRow { get; set; }
        public DateTime InsertedDate { get; set; }
        public DateTime ModifiedDate { get; set; }
        public List<MasterTableColumnSetting> ColumnSetting { get; set; }
    }
}
