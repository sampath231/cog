﻿//-----------------------------------------------------------------------
// <copyright file="appConstant.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI
{
    /// <summary>
    /// Static Class to Store Constant
    /// </summary>
    public static class appConstant
    {
        public static string ApplicationName = "AdminAPI";
    }
}
