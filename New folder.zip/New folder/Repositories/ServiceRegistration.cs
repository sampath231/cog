﻿//-----------------------------------------------------------------------
// <copyright file="ServiceRegistration.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories
{
    using Microsoft.Extensions.DependencyInjection;
    using OneC_3601_AdminAPI.Repositories.Interfaces;
    using OneC_3601_AdminAPI.Repositories.Persistence;

    /// <summary>
    /// Class to register services in application runtime
    /// </summary>
    public static class ServiceRegistration
    {
        /// <summary>
        /// To add services in the service collection as dependency
        /// </summary>
        /// <param name="services">Services</param>
        public static void AddPersistenceInfrastructure(this IServiceCollection services)
        {
            services.AddScoped<IMasterServices, MasterServices>();
            services.AddScoped<IMasterScreen, MasterScreenService>();
            services.AddScoped<IMasterControl, MasterControlServices>();
            services.AddScoped<IMasterUIScreen, MasterUIScreenServices>();
            services.AddScoped<IMasterUIScreenSections, MasterUIScreenSectionServices>();
            services.AddScoped<IMasterUIScreenSubSections, MasterUIScreenSubSectionServices>();
            services.AddScoped<IMasterUIScreenControlMapping, MasterUIScreenControlMappingServices>();
            services.AddScoped<IAutoSearch,AutoSearchServices>();
            services.AddScoped<IAutoSelect, AutoSelectServices>();


        }
    }
}
