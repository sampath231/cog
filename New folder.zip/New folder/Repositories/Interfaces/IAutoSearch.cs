﻿//-----------------------------------------------------------------------
// <copyright file="IAutoSearch.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Repositories.Interfaces
    {
        using OneC_3601_AdminAPI.Models;
    /// <summary>
    /// Interface for AutoSearch
    /// </summary>
    public interface IAutoSearch
        {
        /// <summary>
        /// Method to get the list of AutoSearch
        /// </summary>
        /// <returns>List of AutoSearch</returns>
        public List<MasterSearchFieldConfiguration> GetSearchFieldConfigById(int fieldId);
        /// <summary>
        /// Method to get the AutoSearch data
        /// </summary>
        /// <param name="master">AutoSearch</param>
        /// <returns>Integer of AutoSearch</returns>

        public int SaveSearchFieldConfig(MasterSearchFieldConfiguration fieldConfig);

        /// <summary>
        /// Method to save the AutoSearch data
        /// </summary>
        /// <param name="controltype">AutoSearch</param>
        /// <returns>Integer of AutoSearch</returns>
        
    }
}
