﻿//-----------------------------------------------------------------------
// <copyright file="IMasterServices.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Interfaces
{
    using System.Collections.Generic;
    using OneC_3601_AdminAPI.Models;

    /// <summary>
    /// Interface for Master services
    /// </summary>
    public interface IMasterServices
    {
        /// <summary>
        /// Method to get the list of countries
        /// </summary>
        /// <param name="countryName">Country Name</param>
        /// <returns>List of countries</returns>
        public List<Country> GetCountries(string? countryName);
        /// <summary>
        /// Method to get the list of visas
        /// </summary>
        /// <param name="visaName">Visa Name</param>
        /// <param name="countryId">Country ID</param>
        /// <returns>List of Visa Types</returns>
        public List<VisaType> GetVisaTypes(string? visaName, int? countryId);

        /// <summary>
        /// Method to get the list of key values
        /// </summary>
        /// <param name="keyName">Key Name</param>
        /// <returns>List of Key Values</returns>
        public List<MasterKeyValues> GetMasterKeyValues(string? keyName);
    }
}
