﻿//-----------------------------------------------------------------------
// <copyright file="IAutoSelect.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Repositories.Interfaces
{
    using OneC_3601_AdminAPI.Models;

    /// <summary>
    /// Interface for AutoSelect
    /// </summary>
    public interface IAutoSelect
    {
        /// <summary>
        /// Method to get the control type is IAutoSelect
        /// </summary>
        /// <param name="controltype">.IAutoSelect</param>
        /// <returns>.Integer of IAutoSelect</returns>
        public List<MasterSelect> GetSelectControlConfig(int controlId);
        /// <summary>
        /// Method to get the Getmastersetting
        /// </summary>
        /// <param name="SelectID">.IAutoSelect</param>
        /// <returns>.Integer of IAutoSelect</returns>
        public int SaveSelectControlConfig(MasterSelect selectConfig);
        /// <summary>
        /// Method to Save the control type is Select
        /// </summary>
        /// <param name="master">.IAutoSelect</param>
        /// <returns>.Integer of IAutoSelect</returns>
    }
}

