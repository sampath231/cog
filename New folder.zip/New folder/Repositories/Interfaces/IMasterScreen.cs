﻿//-----------------------------------------------------------------------
// <copyright file="IMasterScreen.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Interfaces
{
    using OneC_3601_AdminAPI.Models;

    /// <summary>
    /// Interface for Master Screens
    /// </summary>
    public interface IMasterScreen
    {
        /// <summary>
        /// Method to get the list of MasterScreens
        /// </summary>
        /// <returns>List of MasterScreens</returns>
        public List<MasterScreens> GetMasterScreens();
        /// <summary>
        /// Method to save the MasterScreen data
        /// </summary>
        /// <param name="masterScreens">MasterScreens</param>
        /// <returns>Integer of MasterScreen_ID</returns>
        public int SaveMasterScreens(List<MasterScreens> masterScreens);
        /// <summary>
        /// Method to get the list of MasterControls
        /// </summary>
        /// <returns>List of MasterControls</returns>
        public List<MasterControls> GetAllMasterControlTypes();
        /// <summary>
        /// Method to get the list of Screen Controls mapped 
        /// </summary>
        /// <param name="screenID">Screen Id</param>
        /// <returns>List of Screen Controls</returns>
        public List<GetMasterScreenControlMapping> GetScreenControlsByScreenID(int screenID);
        /// <summary>
        /// Method to get the list of Reference Controls mapped 
        /// </summary>
        /// <param name="screenID">Screen Id</param>
        /// <returns>List of Reference Controls</returns>
        public List<GetMasterScreenControlMapping> GetReferenceControlsByScreenID(int screenID);
        /// <summary>
        /// Method to save the MasterScreenControlMapping data
        /// </summary>
        /// <param name="masterScreenControlMappingDto">MasterScreens</param>
        /// <returns>Integer of ScreenControl_MappingID</returns>
        public int SaveScreenControlsByScreenID(List<MasterScreenControlMapping> masterScreenControlMappingDto);
        /// <summary>
        /// Method to save the ScreenControls data
        /// </summary>
        /// <param name="saveJsonMasterDto">MasterScreens</param>
        /// <returns>boolean of Control Data</returns>
        public bool SaveScreenControlsData(SaveJsonMaster saveJsonMasterDto);
        /// <summary>
        /// Method to get the list of Reference table's data
        /// </summary>
        /// <param name="refTable">Reference Table</param>
        /// <param name="refColumn">Reference Column</param>
        /// <returns>List of Reference table's data</returns>
        public List<CommonDataMaster> GetReferenceTableDataMaster(int refTable, int refColumn);
        /// <summary>
        /// Method to get the list of ScreenControlsMaster mapped for Dynamic Form
        /// </summary>
        /// <param name="master">Master Screen Id</param>
        /// <returns>Serialized String of ScreenControlsMaster data</returns>
        public string GetScreenControlMasterData(int master);
        /// <summary>
        /// Method to get the list of Data mapped for master screens
        /// </summary>
        /// <returns>Serialized String of ScreenControlsMaster data</returns>
        public string GetMasterDataControls();
        /// <summary>
        /// Method to update the MasterScreen data
        /// </summary>
        /// <param name="data">MasterScreens</param>
        /// <returns>Integer of MasterScreen_ID</returns>
        public int UpdateScreenControlsData(UpdateJsonMaster data);

        /// <summary>
        /// Method to update the MasterScreen data
        /// </summary>
        /// <param name="id">MasterScreens</param>
        /// <returns>Integer of MasterScreen_ID</returns>
    }
}
