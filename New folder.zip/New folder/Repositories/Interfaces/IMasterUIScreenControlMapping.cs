﻿//-----------------------------------------------------------------------
// <copyright file="IMasterUIScreen.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Interfaces
{
    using OneC_3601_AdminAPI.Models;

    // <summary>
    /// Interface for Master UI Screen Control Mapping 
    /// </summary>
    public interface IMasterUIScreenControlMapping
    {
        /// <summary>
        /// Method to save master ui screen control mapping
        /// </summary>
        /// <param name=""></param>
        /// <returns>List of master UI Screen control mapping</returns>
        public bool SaveMasterUIScreenControlMapping(MasterUIScreenControlMapping masterUIScreenControlMapping);
    }
}
