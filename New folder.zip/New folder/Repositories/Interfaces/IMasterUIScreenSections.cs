﻿//-----------------------------------------------------------------------
// <copyright file="IMasterUIScreenSections.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Interfaces
{
    using OneC_3601_AdminAPI.Models;

    /// <summary>
    /// Interface for Master UI Screen Sections
    /// </summary>
    public interface IMasterUIScreenSections
    {
        /// <summary>
        /// Method to get the list of master UI Screen Sections
        /// </summary>
        /// <param name="screenId">screen Id</param>
        /// <returns>List of master UI Screen Sections</returns>
        public List<MasterUIScreenSections> GetMasterUIScreenSections(int screenId);
    }
}
