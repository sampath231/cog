﻿//-----------------------------------------------------------------------
// <copyright file="IMasterUIScreenSubSections.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Interfaces
{
    using OneC_3601_AdminAPI.Models;

    /// <summary>
    /// Interface for Master UI Screen SubSections
    /// </summary>
    public interface IMasterUIScreenSubSections
    {
        /// <summary>
        /// Method to get the list of master UI Screen SubSections
        /// </summary>
        /// <param name=""></param>
        /// <returns>List of master UI Screen SubSections</returns>
        public List<MasterUIScreenSubSections> GetMasterUIScreenSubSections(int SectionId);
    }
}
