﻿//-----------------------------------------------------------------------
// <copyright file="IMasterUIScreen.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Interfaces
{
    using OneC_3601_AdminAPI.Models;

    /// <summary>
    /// Interface for Master UI Screen 
    /// </summary>
    public interface IMasterUIScreen
    {
        /// <summary>
        /// Method to get the list of master UI Screens
        /// </summary>
        /// <param name=""></param>
        /// <returns>List of master UI Screens</returns>
        public List<MasterUIScreens> GetMasterUIScreens();
    }
}
