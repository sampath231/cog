﻿//-----------------------------------------------------------------------
// <copyright file="ICacheServices.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Interfaces
{
    /// <summary>
    /// Interface for Cache services
    /// </summary>
    public interface ICacheServices
    {
        /// <summary>
        /// To Get the State
        /// </summary>
        /// <param name="key">key name</param>
        /// <returns>string value</returns>
        public Task<string> GetState(string key);
      
    }
}
