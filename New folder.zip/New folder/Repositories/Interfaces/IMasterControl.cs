﻿//-----------------------------------------------------------------------
// <copyright file="IMasterControlServices.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Interfaces
{
    using OneC_3601_AdminAPI.Models;

    /// <summary>
    /// Interface for Master Control services
    /// </summary>
    public interface IMasterControl
    {
        /// <summary>
        /// Method to get the list of master controls
        /// </summary>
        /// <param name=""></param>
        /// <returns>List of master controls</returns>
        public List<MasterControlSettings> GetMasterControls();

        /// <summary>
        /// Method to save the master control
        /// </summary>
        /// <param name="masterControls">MasterControls</param>
        /// <returns>List of master controls</returns>
        public bool SaveMasterControl(MasterControlSettings masterControls);

        public List<MasterControls> GetControlsByControlType(string controltype);
    }
}
