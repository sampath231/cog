﻿//-----------------------------------------------------------------------
// <copyright file="MasterUIScreenServices.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------


namespace OneC_3601_AdminAPI.Repositories.Persistence
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Text;
    using Microsoft.Extensions.Configuration;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;
    using OneC_3601_CommonHelpers;

    // <summary>
    /// Class to get master screen details
    /// </summary>
    public class MasterUIScreenServices : IMasterUIScreen
    {
        private string connectionString;
        private SqlConnection connection = new SqlConnection();

        /// <summary>
        /// Constructor for Master screen Service
        /// </summary>
        /// <param name="config"></param>
        public MasterUIScreenServices(IConfiguration config)
        {
            connectionString = config.GetConnectionString("DefaultConnection");
            connection.ConnectionString = connectionString;
        }

        /// <summary>
        /// Method to get the list of master ui screens
        /// </summary>
        /// <param name=""></param>
        /// <returns>List of master ui screens</returns>
        public List<MasterUIScreens> GetMasterUIScreens()
        {
            List<MasterUIScreens> screens = new List<MasterUIScreens> { };
            StringBuilder JsonResult = new StringBuilder();
            SqlDataReader dr = SqlHelper.ExecuteReader(connection, "[dbo].[usp_GetMasterUIScreensData]");
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    JsonResult.Append(Convert.ToString(dr[0]));
                }
                screens = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MasterUIScreens>>(JsonResult.ToString());
            }
            dr.Close();
            dr.Dispose();
            return screens;
        }

        ///// <summary>
        ///// Method to save the master control
        ///// </summary>
        ///// <param name=""></param>
        ///// <returns>List of master controls</returns>
        //public bool SaveMasterControl(MasterControlSettings MasterControls)
        //{
        //    try
        //    {
        //        if (connection.State == System.Data.ConnectionState.Open)
        //            connection.Close();
        //        SqlCommand command = new SqlCommand();
        //        command.Connection = connection;
        //        command.CommandText = "[dbo].[usp_SaveMasterControlsData]";
        //        command.CommandType = CommandType.StoredProcedure;
        //        SqlParameter[] parameters = new SqlParameter[] { };
        //        if (MasterControls.controlTypeOptions != null && !string.IsNullOrEmpty(MasterControls.controlTypeOptions))
        //        {
        //            parameters = new SqlParameter[]
        //            {
        //              new SqlParameter("@controlName ", MasterControls.controlName),
        //              new SqlParameter("@controlType", MasterControls.controlType),
        //              new SqlParameter("@controlRequired ", MasterControls.controlRequired),
        //              new SqlParameter("@controlTooltip", MasterControls.controlTooltip),
        //              new SqlParameter("@controlTypeOptions", MasterControls.controlTypeOptions)
        //            };
        //        }
        //        else
        //        {
        //            parameters = new SqlParameter[]
        //            {
        //              new SqlParameter("@controlName ", MasterControls.controlName),
        //              new SqlParameter("@controlType", MasterControls.controlType),
        //              new SqlParameter("@controlRequired ", MasterControls.controlRequired),
        //              new SqlParameter("@controlTooltip", MasterControls.controlTooltip),
        //            };
        //        }


        //        SqlHelper.ExecuteReader(connection, command.CommandType, command.CommandText, parameters);
        //        command.Dispose();
        //    }
        //    catch (Exception ex)
        //    {
        //        throw;
        //        return false;
        //    }

        //    return true;
        //}
    }
}
