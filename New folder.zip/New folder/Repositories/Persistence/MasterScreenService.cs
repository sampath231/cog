﻿//-----------------------------------------------------------------------
// <copyright file="MasterScreenService.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Persistence
{
    using System.Data;
    using System.Data.SqlClient;
    using System.Reflection;
    using OneC_3601_CommonHelpers;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;
    using Google.Api;

    /// <summary>
    /// Class to get and set Master Screens Data
    /// </summary>
    public class MasterScreenService : IMasterScreen
    {
        private string connectionString;
        private SqlConnection connection = new SqlConnection();

        /// <summary>
        /// Constructor for Master Screen Service
        /// </summary>
        /// <param name="config"></param>
        public MasterScreenService(IConfiguration config)
        {
            connectionString = config.GetConnectionString("DefaultConnection");
            connection.ConnectionString = connectionString;
        }
        /// <summary>
        /// Method to get the list of Master Control data
        /// </summary>
        /// <returns>List of Master Control data</returns>
        public List<MasterControls> GetAllMasterControlTypes()
        {
            List<MasterControls> masterControls = new List<MasterControls>();

            SqlParameter[] parameters = new SqlParameter[]
                {
                new SqlParameter("@MasterType", "ControlType"),
                new SqlParameter("@MasterScreenID", "")
                };
            SqlDataReader dr = SqlHelper.ExecuteReader(connection, CommandType.StoredProcedure, "[dbo].[usp_GetMasterScreenData]", parameters);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    try
                    {
                        MasterControls controls = new MasterControls();
                        controls.ControlID = Int16.Parse(dr["ControlID"].ToString());
                        controls.ControlName = Convert.ToString(dr["ControlName"]);
                        controls.ControlToolTip = Convert.ToString(dr["ControlToolTip"]);
                        masterControls.Add(controls);

                    }
                    catch (Exception ex)
                    {
                        throw ex;
                    }

                }
            }
            dr.Close();
            dr.Dispose();

            return masterControls;
        }
        /// <summary>
        /// Method to get the list of Master Screens data
        /// </summary>
        /// <returns>List of Master Screens data</returns>
        public List<MasterScreens> GetMasterScreens()
        {
            List<MasterScreens> masterScreens = new List<MasterScreens>();

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@MasterType", "Screen"),
                new SqlParameter("@MasterScreenID", "")
            };
            SqlDataReader dr = SqlHelper.ExecuteReader(connection, CommandType.StoredProcedure, "[dbo].[usp_GetMasterScreenData]", parameters);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    MasterScreens screens = new MasterScreens();
                    screens.ScreenID = int.Parse(dr["ScreenID"].ToString());
                    screens.ScreenName = Convert.ToString(dr["ScreenName"]);
                    screens.IsActive = bool.Parse(dr["IsActive"].ToString());
                    screens.PKey_ColumnName = Convert.ToString(dr["PKey_ColumnName"]);
                    screens.Key_Datatype = Convert.ToString(dr["Key_Datatype"]);
                    screens.SchemaName = Convert.ToString(dr["SchemaName"]);
                    screens.IsCreated = bool.Parse(dr["IsCreated"].ToString());
                    masterScreens.Add(screens);

                }

            }
            dr.Close();
            dr.Dispose();

            return masterScreens;

        }

        /// <summary>
        /// Method to get the list of Reference table data
        /// </summary>
        /// <param name="masterScreenControlMapping">Master Screen Control Mapping</param>
        /// <returns>List of Reference Table data</returns>
        public List<CommonDataMaster> GetReferenceTableDataMaster(int refTable, int refColumn)
        {
            List<CommonDataMaster> objMasterlist = new List<CommonDataMaster>();
            try
            {
                SqlParameter[] parameters = new SqlParameter[]
                {
                new SqlParameter("@ReferenceTable", refTable),
                new SqlParameter("@ReferenceColumn",refColumn)
                };
                SqlDataReader dr = SqlHelper.ExecuteReader(connection, CommandType.StoredProcedure, "[dbo].[usp_GetReferenceTableDataforMaster]", parameters);
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        try
                        {
                            CommonDataMaster objCommonDataMaster = new CommonDataMaster();
                            objCommonDataMaster.DataKey = Convert.ToInt32(dr["DataKey"]);
                            objCommonDataMaster.Datavalue = dr["DataValue"].ToString();
                            objMasterlist.Add(objCommonDataMaster);
                        }
                        catch
                        {
                            return null;
                        }
                    }
                }
                dr.Close();
                dr.Dispose();
            }
            catch (Exception)
            {
                throw;
            }

            return objMasterlist;

        }
        /// <summary>
        /// Method to get the list of table records for the selected Master Screen
        /// </summary>
        /// <param name="master">MasterScreen ID</param>
        /// <returns>String of Table records for Selected MasterScreens</returns>
        public string GetScreenControlMasterData(int master)
        {
            SqlParameter[] parameters = new SqlParameter[]
                {
                new SqlParameter("@optionType", ""),
                new SqlParameter("@ScreenID", master)
                };
            try
            {
                DataSet ds = SqlHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "[dbo].[usp_GetMasterMaintenance]", parameters);
                var strSerializer = DataTableToJSON(ds.Tables[0]);
                return strSerializer;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// Method to get the list of Controls Data for the Master Screens
        /// </summary>
        /// <returns>String of Table records for Selected MasterScreens</returns>
        public string GetMasterDataControls()
        {
            SqlParameter[] parameters = new SqlParameter[]
                {
                new SqlParameter("@MasterType", "Data"),
                new SqlParameter("@MasterScreenID", "")
                };
            try
            {
                DataSet ds = SqlHelper.ExecuteDataset(connection, CommandType.StoredProcedure, "[dbo].[usp_GetMasterScreenData]", parameters);
                var strSerializer = DataTableToJSON(ds.Tables[0]);
                return strSerializer;
            }
            catch
            {
                return null;
            }
        }
        /// <summary>
        /// Method to get the list of Screen Controls 
        /// </summary>
        /// <param name="screenID">Screen ID</param>
        /// <returns>List of Screen Controls</returns>
        public List<GetMasterScreenControlMapping> GetScreenControlsByScreenID(int screenID)
        {
            List<GetMasterScreenControlMapping> screenControls = new List<GetMasterScreenControlMapping>();

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@MasterType", "ScreenControl"),
                new SqlParameter("@MasterScreenID",screenID)
            };
            SqlDataReader dr = SqlHelper.ExecuteReader(connection, CommandType.StoredProcedure, "[dbo].[usp_GetMasterScreenData]", parameters);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    GetMasterScreenControlMapping screensControls = new GetMasterScreenControlMapping();
                    screensControls.ScreenControl_MappingID = int.Parse(dr["ScreenControl_MappingID"].ToString());
                    screensControls.Master_ScreenID = int.Parse(dr["Master_ScreenID"].ToString());
                    screensControls.Control_Type_ID = Int16.Parse(dr["Control_Type_ID"].ToString());
                    screensControls.Control_Name = Convert.ToString(dr["Control_Name"]);
                    screensControls.Control_Required = bool.Parse(dr["Control_Required"].ToString());
                    screensControls.Control_ColumnType = Convert.ToString(dr["Control_ColumnType"]);
                    screensControls.Reference_Table = int.Parse(dr["Reference_Table"].ToString());
                    screensControls.Reference_Column = int.Parse(dr["Reference_Column"].ToString());
                    screensControls.IsCreated = bool.Parse(dr["IsCreated"].ToString());
                    screensControls.IsActive = bool.Parse(dr["IsActive"].ToString());
                    screensControls.Control_ColumnDataType = Convert.ToString(dr["Control_ColumnDataType"]);
                    screenControls.Add(screensControls);
                }
            }
            dr.Close();
            dr.Dispose();
            return screenControls;
        }
        /// <summary>
        /// Method to get the list of Reference Controls 
        /// </summary>
        /// <param name="screenID">Screen ID</param>
        /// <returns>List of Reference Controls</returns>
        public List<GetMasterScreenControlMapping> GetReferenceControlsByScreenID(int screenID)
        {
            List<GetMasterScreenControlMapping> screenControls = new List<GetMasterScreenControlMapping>();

            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@ReferenceTable",screenID)
            };
            SqlDataReader dr = SqlHelper.ExecuteReader(connection, CommandType.StoredProcedure, "[dbo].[usp_GetReferenceControlData]", parameters);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    GetMasterScreenControlMapping screensControls = new GetMasterScreenControlMapping();
                    screensControls.ScreenControl_MappingID = int.Parse(dr["ScreenControl_MappingID"].ToString());
                    screensControls.Master_ScreenID = int.Parse(dr["Master_ScreenID"].ToString());
                    screensControls.Control_Type_ID = Int16.Parse(dr["Control_Type_ID"].ToString());
                    screensControls.Control_Name = Convert.ToString(dr["Control_Name"]);
                    screensControls.Control_Required = bool.Parse(dr["Control_Required"].ToString());
                    screensControls.Control_ColumnType = Convert.ToString(dr["Control_ColumnType"]);
                    screensControls.Reference_Table = int.Parse(dr["Reference_Table"].ToString());
                    screensControls.Reference_Column = int.Parse(dr["Reference_Column"].ToString());
                    screensControls.IsCreated = bool.Parse(dr["IsCreated"].ToString());
                    screensControls.IsActive = bool.Parse(dr["IsActive"].ToString());
                    screensControls.Control_ColumnDataType = Convert.ToString(dr["Control_ColumnDataType"]);
                    screenControls.Add(screensControls);
                }
            }
            dr.Close();
            dr.Dispose();
            return screenControls;
        }
        /// <summary>
        /// Method to Create the table and add to Master Screens
        /// </summary>
        /// <param name="masterScreens">Master Screen Control Mapping</param>
        /// <returns>Integer of ScreenID created</returns>
        public int SaveMasterScreens(List<MasterScreens> masterScreens)
        {
            DataTable projectDatatable = new DataTable();
            projectDatatable = CreateDataTable<MasterScreens>(masterScreens);
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@MasterScreens", projectDatatable) {TypeName="[dbo].[Save_MasterScreens]"}
            };
            SqlHelper.ExecuteScalar(connection, CommandType.StoredProcedure, "[dbo].[usp_SaveMasterScreen]", parameters);
            return 1;
        }

        /// <summary>
        /// Method to Save the Screen Controls for MasterScreens
        /// </summary>
        /// <param name="masterScreenControlMapping">Master Screen Control Mapping</param>
        /// <returns>Integer of ScreenControl_MappingID created</returns>
        public int SaveScreenControlsByScreenID(List<MasterScreenControlMapping> masterScreenControlMapping)
        {
            DataTable projectDatatable = new DataTable();
            projectDatatable = CreateDataTable<MasterScreenControlMapping>(masterScreenControlMapping);
            SqlParameter[] parameters = new SqlParameter[]
            {
                new SqlParameter("@MasterScreenControlMapping", projectDatatable) {TypeName="[dbo].[Save_MasterScreenControlMapping]"},
                new SqlParameter("@Flag","Insert")
            };
            SqlHelper.ExecuteScalar(connection, CommandType.StoredProcedure, "[dbo].[usp_SaveScreenControlByScreenID]", parameters);
            return 1;

        }

        /// <summary>
        /// Method to set the Table record in JSON to the Master
        /// </summary>
        /// <param name="saveJsonMaster">Master Screen Control Mapping</param>
        /// <returns>true, if saved and false, if failed</returns>
        public bool SaveScreenControlsData(SaveJsonMaster saveJsonMaster)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[]
                {
                new SqlParameter("@JsonData", saveJsonMaster.jsonData),
                new SqlParameter("@Master_ScreenID",saveJsonMaster.Master_ScreenID),
                new SqlParameter("@Associate_Id", saveJsonMaster.AssociateId),
                };
                SqlHelper.ExecuteScalar(connection, CommandType.StoredProcedure, "[dbo].[usp_SaveJsonValueToMaster]", parameters);
                return true;
            }
            catch (Exception)
            {
                return false;
            }
        }
        /// <summary>
        /// Method to update the Table record in JSON to the Master
        /// </summary>
        /// <param name="updateJsonMaster">Master Screen Control Mapping</param>
        /// <returns>true, if saved and false, if failed</returns>
        public int UpdateScreenControlsData(UpdateJsonMaster updateJsonMaster)
        {
            try
            {
                SqlParameter[] parameters = new SqlParameter[]
                {
                new SqlParameter("@JsonData", updateJsonMaster.jsonData),
                new SqlParameter("@Master_ScreenID",updateJsonMaster.Master_ScreenID),
                new SqlParameter("@primaryID",updateJsonMaster.PrimaryKey),
                new SqlParameter("@Associate_Id", updateJsonMaster.AssociateId),
                };
                SqlHelper.ExecuteScalar(connection, CommandType.StoredProcedure, "[dbo].[usp_UpdateJsonValueToMaster]", parameters);
            }
            catch (Exception)
            {
            }

            return updateJsonMaster.Master_ScreenID;

        }
        /// <summary>
        /// Method to convert DataTable to JSON
        /// </summary>
        /// <param name="table">DataTable</param>
        /// <returns>String of the data from table in DB</returns>
        public static string DataTableToJSON(DataTable table)
        {
            var list = new List<Dictionary<string, object>>();
            foreach (DataRow row in table.Rows)
            {
                var dict = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    dict[col.ColumnName] = row[col];
                }
                list.Add(dict);
                System.Text.Json.JsonSerializer.Serialize(list);
            }
            return System.Text.Json.JsonSerializer.Serialize(list);
        }
        /// <summary>        
        /// To create data table from class.        
        /// </summary>        
        /// <typeparam name="T">Class type..</typeparam>        
        /// <param name="list">Name of the list.</param>        
        /// <returns>Data table.</returns>                      
        public static DataTable CreateDataTable<T>(IEnumerable<T> list)
        {
            Type type = typeof(T);
            var properties = type.GetProperties();
            DataTable dataTable = new DataTable();
            foreach (PropertyInfo info in properties)
            {
                dataTable.Columns.Add(new DataColumn(info.Name, info.PropertyType));
            }
            foreach (T entity in list)
            {
                object[] values = new object[properties.Length];
                for (int i = 0; i < properties.Length; i++)
                {
                    values[i] = properties[i].GetValue(entity);
                }
                dataTable.Rows.Add(values);
            }
            return dataTable;
        }
        
    }

}


