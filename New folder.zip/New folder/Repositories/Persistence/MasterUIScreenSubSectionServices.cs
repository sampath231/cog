﻿//-----------------------------------------------------------------------
// <copyright file="MasterUIScreenSubSectionServices.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------


namespace OneC_3601_AdminAPI.Repositories.Persistence
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Text;
    using Microsoft.Extensions.Configuration;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;
    using OneC_3601_CommonHelpers;

    // <summary>
    /// Class to get master ui screen subsection details
    /// </summary>
    public class MasterUIScreenSubSectionServices : IMasterUIScreenSubSections
    {
        private string connectionString;
        private SqlConnection connection = new SqlConnection();

        /// <summary>
        /// Constructor for Master Screen SubSection Service
        /// </summary>
        /// <param name="config"></param>
        public MasterUIScreenSubSectionServices(IConfiguration config)
        {
            connectionString = config.GetConnectionString("DefaultConnection");
            connection.ConnectionString = connectionString;
        }

        /// <summary>
        /// Method to get the list of master ui screen subsections
        /// </summary>
        /// <param name=""></param>
        /// <returns>List of master ui screen subsections</returns>
        public List<MasterUIScreenSubSections> GetMasterUIScreenSubSections(int SectionId)
        {
            List<MasterUIScreenSubSections> subSections = new List<MasterUIScreenSubSections> { };
            StringBuilder JsonResult = new StringBuilder();
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@SectionId", SectionId);
            SqlDataReader dr = SqlHelper.ExecuteReader(connection, "[dbo].[usp_GetMasterUIScreenSubSectionsData]", parameters);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    JsonResult.Append(Convert.ToString(dr[0]));
                }
                subSections = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MasterUIScreenSubSections>>(JsonResult.ToString());
            }
            dr.Close();
            dr.Dispose();
            return subSections;
        }

        
    }
}
