﻿//-----------------------------------------------------------------------
// <copyright file="CacheServices.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Persistence
{

    using Dapr.Client;
    using OneC_3601_AdminAPI.Repositories.Interfaces;

    /// <summary>
    /// Class for Cache Services
    /// </summary>
    public class CacheServices : ICacheServices
    {
        const string storeName = "statestore";

        /// <summary>
        /// To Get the State
        /// </summary>
        /// <param name="key">key name</param>
        /// <returns>string value</returns>
        public async Task<string> GetState(string key)
        {
            using (var client = new DaprClientBuilder().Build())
            {
                /* For saving data to state store */
                return await client.GetStateAsync<string>(storeName, key);
            }
        }
    }
}
