﻿//-----------------------------------------------------------------------
// <copyright file="AutoSearchServices.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Repositories.Persistence
{
    using System.Data;
    using System.Data.SqlClient;
    using System.Reflection;
    using OneC_3601_CommonHelpers;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;
    using Google.Api;
    using Newtonsoft.Json;
    using System.Text;

    /// <summary>
    /// Class to get and set AutoSearch data
    /// </summary>
    public class AutoSearchServices : IAutoSearch
    {
        private string connectionString;
        private SqlConnection connection = new SqlConnection();

        /// <summary>
        /// Constructor for AutoSearchServices
        /// </summary>
        /// <param name="config"></param>
        public AutoSearchServices(IConfiguration config)
        {
            connectionString = config.GetConnectionString("DefaultConnection");
            connection.ConnectionString = connectionString;
        }
       
        /// <summary>        
        /// To get the data by id.        
        /// </summary>        
        /// <typeparam name="T">Class type..</typeparam>        
        /// <param name="id">id by list.</param>        
        /// <returns>Data table.</returns>      
        public List<MasterSearchFieldConfiguration> GetSearchFieldConfigById(int id)
        {
           List< MasterSearchFieldConfiguration> objdata = new List<MasterSearchFieldConfiguration>(); 
            StringBuilder JsonResult = new StringBuilder();
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@id", id);
            SqlDataReader dr = SqlHelper.ExecuteReader(connection, "[dbo].[usp_GetMasterSearchFieldConfigById]", parameters);
           
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    JsonResult.Append(Convert.ToString(dr[0]));
                }
                objdata = JsonConvert.DeserializeObject<List<MasterSearchFieldConfiguration>>(JsonResult.ToString());
            }
            dr.Close();
            dr.Dispose();
            return objdata;

        }
        /// <summary>
        /// Method to save the data masterfield data
        /// </summary>
        /// <param name="master"></param>
        /// <returns>data table</returns>  
        public int SaveSearchFieldConfig(MasterSearchFieldConfiguration master)
        {
            int recordsaved = 0;
            if (connection.State == System.Data.ConnectionState.Open)
                connection.Close();
            SqlParameter[] parameters;
            parameters = new SqlParameter[6];
            parameters[0] = new SqlParameter("@id", master.SearchControlID);
            parameters[1] = new SqlParameter("@MinLength", master.MinLength);
            parameters[2] = new SqlParameter("@SearchControl", master.SearchControl);
            parameters[3] = new SqlParameter("@AutoFieldColumn", master.AutoFieldColumn);
            parameters[4] = new SqlParameter("@DepColumn", master.DepColumn);
            parameters[5] = new SqlParameter("@ApiUrl", master.ApiUrl);
            SqlHelper.ExecuteReader(connection,CommandType.StoredProcedure,"[dbo].[usp_SaveMasterSearchFieldConfig]",parameters);
            return recordsaved;


        }
       
    }
}


        

