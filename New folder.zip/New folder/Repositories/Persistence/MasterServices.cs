﻿//-----------------------------------------------------------------------
// <copyright file="MasterServices.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Persistence
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Text;
    using Microsoft.Extensions.Configuration;
    using Newtonsoft.Json;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;
    using OneC_3601_CommonHelpers;
   
    /// <summary>
    /// Class to get master details
    /// </summary>
    public class MasterServices : IMasterServices
    {
        private string connectionString;
        private SqlConnection connection = new SqlConnection();

        /// <summary>
        /// Constructor for Master Service
        /// </summary>
        /// <param name="config"></param>
        public MasterServices(IConfiguration config)
        {
            connectionString = config.GetConnectionString("DefaultConnection");
            connection.ConnectionString = connectionString;
        }


        /// <summary>
        /// Method to get the list of key values
        /// </summary>
        /// <param name="keyName">Key Name</param>
        /// <returns>List of Key Values</returns>
        public List<MasterKeyValues> GetMasterKeyValues(string keyName)
        {
            List<MasterKeyValues>? keyvalues = new List<MasterKeyValues>();

            StringBuilder JsonResult = new StringBuilder();

            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0]=new SqlParameter("@KeyName", keyName);

            SqlDataReader dr = SqlHelper.ExecuteReader(connection, "[dbo].[usp_GetMasterKeyValues]", parameters);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    JsonResult.Append(Convert.ToString(dr[0]));
                }
                keyvalues = JsonConvert.DeserializeObject<List<MasterKeyValues>>(JsonResult.ToString());
            }
            dr.Close();
            dr.Dispose();

            return keyvalues ?? new List<MasterKeyValues>();   
        }

        /// <summary>
        /// Method to get the list of countries
        /// </summary>
        /// <param name="countryName">Country Name</param>
        /// <returns>List of countries</returns>
        public List<Country> GetCountries(string? countryName)
        {
            List<Country>? countries = new List<Country>();

            StringBuilder JsonResult = new StringBuilder();

            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@countryName", countryName != null ? countryName : string.Empty);

            SqlDataReader dr = SqlHelper.ExecuteReader(connection, "[dbo].[usp_GetCountries]", parameters);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    JsonResult.Append(Convert.ToString(dr[0]));
                }
                countries = JsonConvert.DeserializeObject<List<Country>>(JsonResult.ToString());
            }
            dr.Close();
            dr.Dispose();

            return countries ?? new List<Country>();
        }


        /// <summary>
        /// Method to get the list of visas
        /// </summary>
        /// <param name="visaName">Visa Name</param>
        /// <param name="countryId">Country ID</param>
        /// <returns>List of Visa Types</returns>
        public List<VisaType> GetVisaTypes(string? visaName, int? countryId)
        {
            List<VisaType>? visaTypes = new List<VisaType>();

            StringBuilder JsonResult = new StringBuilder();

            SqlParameter[] parameters;
            parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@visaName", visaName != null ? visaName : string.Empty);
            parameters[1] = new SqlParameter("@countryID", countryId != null ? countryId : 0);

            SqlDataReader dr = SqlHelper.ExecuteReader(connection, "[dbo].[usp_GetVisaType]", parameters);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    JsonResult.Append(Convert.ToString(dr[0]));
                }
                visaTypes = JsonConvert.DeserializeObject<List<VisaType>>(JsonResult.ToString());
            }
            dr.Close();
            dr.Dispose();

            return visaTypes?? new List<VisaType>();
        }


      

    }
}
