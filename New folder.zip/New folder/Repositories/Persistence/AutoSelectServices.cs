﻿//-----------------------------------------------------------------------
// <copyright file="AutoSelectServices.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------
namespace OneC_3601_AdminAPI.Repositories.Persistence
{
    using System.Data;
    using System.Data.SqlClient;
    using System.Reflection;
    using OneC_3601_CommonHelpers;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;
    using Google.Api;
    using Newtonsoft.Json;
    using System.Text;
    using System.Diagnostics.Metrics;

    /// <summary>
    /// Class to get and set  AutoSelect Data
    /// </summary>
    public class AutoSelectServices : IAutoSelect
    {
        private string connectionString;
        private SqlConnection connection = new SqlConnection();
        /// <summary>
        /// Constructor for AutoSearchServices
        /// </summary>
        /// <param name="config"></param>
        public AutoSelectServices(IConfiguration config)
        {
            connectionString = config.GetConnectionString("DefaultConnection");
            connection.ConnectionString = connectionString;
        }
        /// <summary>
        /// Method to get the selectcontrol  Data
        /// </summary>
        /// <param name="controlId"></param>
        /// <returns>get the data</returns> 
        public List<MasterSelect> GetSelectControlConfig(int controlId)
        {
            List<MasterSelect> objdata = new List<MasterSelect>();
            StringBuilder JsonResult = new StringBuilder();
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@SelectID", controlId);
            SqlDataReader dr = SqlHelper.ExecuteReader(connection, "[dbo].[usp_MasterSelectSetting]", parameters);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    JsonResult.Append(Convert.ToString(dr[0]));
                }
                objdata = JsonConvert.DeserializeObject<List<MasterSelect>>(JsonResult.ToString());
            }
            dr.Close();
            dr.Dispose();
            return objdata;
        }

        /// <summary>
        /// Method to save the control type is select
        /// </summary>
        /// <param name="master"></param>
        /// <returns>get the data</returns> 
        public int SaveSelectControlConfig(MasterSelect selectConfig)
        {
            int recordsaved = 0;
            if (connection.State == System.Data.ConnectionState.Open)
                connection.Close();
            SqlParameter[] parameters;
            parameters = new SqlParameter[5];
            {
                parameters[0] = new SqlParameter("@id", selectConfig.SelectID);
                parameters[1] = new SqlParameter("@ApiEndPoint", selectConfig.ApiEndPoint);
                parameters[2] = new SqlParameter("@KeyColumn", selectConfig.KeyColumn);
                parameters[3] = new SqlParameter("@ValueColumn", selectConfig.ValueColumn);
                parameters[4] = new SqlParameter("@SearchControl", selectConfig.SearchControl);
             };
            SqlHelper.ExecuteReader(connection, CommandType.StoredProcedure, "[dbo].[usp_SaveMasterSelectSetting]", parameters);
            return recordsaved;
        }

    }
}




