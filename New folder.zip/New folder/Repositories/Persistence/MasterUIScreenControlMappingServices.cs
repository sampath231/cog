﻿//-----------------------------------------------------------------------
// <copyright file="MasterUIScreenControlMappingServices.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Repositories.Persistence
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Text;
    using Microsoft.Extensions.Configuration;
    using Nancy.Json;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;
    using OneC_3601_CommonHelpers;

    // <summary>
    /// Class to save master ui screen control mapping details
    /// </summary>
    public class MasterUIScreenControlMappingServices:IMasterUIScreenControlMapping
    {
        private string connectionString;
        private SqlConnection connection = new SqlConnection();

        /// <summary>
        /// Constructor for Master ui screen control mappingService
        /// </summary>
        /// <param name="config"></param>
        public MasterUIScreenControlMappingServices(IConfiguration config)
        {
            connectionString = config.GetConnectionString("DefaultConnection");
            connection.ConnectionString = connectionString;
        }

        /// <summary>
        /// Method to save the master ui screen control mapping
        /// </summary>
        /// <param name="masterUIScreenControlMapping">masterUIScreenControlMapping</param>
        /// <returns>true</returns>
        public bool SaveMasterUIScreenControlMapping(MasterUIScreenControlMapping masterUIScreenControlMapping)
        {

            List<ControlMapping> controlMappingList = new List<ControlMapping>();
            foreach (int depId in masterUIScreenControlMapping.ControlDependencyID)
            {
                var depControl = new ControlMapping() 
                { 
                    DepControlID = depId 
                };
                controlMappingList.Add(depControl);
            }
            var controlMapping = new Control()
            {
                controlID = masterUIScreenControlMapping.ControlID,
                depControl = controlMappingList
            };
            var json = new JavaScriptSerializer().Serialize(controlMapping);
            

            if (connection.State == System.Data.ConnectionState.Open)
                connection.Close();
            SqlCommand command = new SqlCommand();
            command.Connection = connection;
            command.CommandText = "[dbo].[usp_SaveMasterUIScreenControlMappingData]";
            command.CommandType = CommandType.StoredProcedure;
            SqlParameter[] parameters;
            parameters = new SqlParameter[6];
            parameters[0] = new SqlParameter("@ScreenID ", masterUIScreenControlMapping.ScreenID);
            parameters[1] = new SqlParameter("@SectionID ", masterUIScreenControlMapping.SectionID);
            parameters[2] = new SqlParameter("@SubSectionID ", masterUIScreenControlMapping.SubSectionID);
            parameters[3] = new SqlParameter("@ControlID ", masterUIScreenControlMapping.ControlID);
            parameters[4] = new SqlParameter("@ControlSequence ", masterUIScreenControlMapping.ControlSequence);
            parameters[5] = new SqlParameter("@ControlMappingJson ", json);
            SqlHelper.ExecuteReader(connection, command.CommandType, command.CommandText, parameters);
            command.Dispose();
            return true;
        }
    }
}
