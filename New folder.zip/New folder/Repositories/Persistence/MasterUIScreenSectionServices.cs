﻿//-----------------------------------------------------------------------
// <copyright file="MasterUIScreenSectionServices.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------


namespace OneC_3601_AdminAPI.Repositories.Persistence
{
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Text;
    using Microsoft.Extensions.Configuration;
    using OneC_3601_AdminAPI.Models;
    using OneC_3601_AdminAPI.Repositories.Interfaces;
    using OneC_3601_CommonHelpers;

    // <summary>
    /// Class to get master screen section details
    /// </summary>
    public class MasterUIScreenSectionServices : IMasterUIScreenSections
    {
        private string connectionString;
        private SqlConnection connection = new SqlConnection();

        /// <summary>
        /// Constructor for Master screen section Service
        /// </summary>
        /// <param name="config"></param>
        public MasterUIScreenSectionServices(IConfiguration config)
        {
            connectionString = config.GetConnectionString("DefaultConnection");
            connection.ConnectionString = connectionString;
        }

        /// <summary>
        /// Method to get the list of master ui screen sections
        /// </summary>
        /// <param name=""></param>
        /// <returns>List of master ui screen sections</returns>
        public List<MasterUIScreenSections> GetMasterUIScreenSections(int screenId)
        {
            List<MasterUIScreenSections> sections = new List<MasterUIScreenSections> { };
            StringBuilder JsonResult = new StringBuilder();
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@ScreenId", screenId);
            SqlDataReader dr = SqlHelper.ExecuteReader(connection, "[dbo].[usp_GetMasterUIScreenSectionsData]", parameters);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    JsonResult.Append(Convert.ToString(dr[0]));
                }
                sections = Newtonsoft.Json.JsonConvert.DeserializeObject<List<MasterUIScreenSections>>(JsonResult.ToString());
            }
            dr.Close();
            dr.Dispose();
            return sections;
        }

    }
}
