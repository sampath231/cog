﻿//-----------------------------------------------------------------------
// <copyright file="RequestLogFilter.cs" company="CTS">
//     Copyright (c) . All rights reserved.
// </copyright>
//-----------------------------------------------------------------------

namespace OneC_3601_AdminAPI.Filters
{
	using System;
	using System.Linq;
	using Microsoft.AspNetCore.Mvc;
	using Microsoft.AspNetCore.Mvc.Filters;
	using OneC_3601_CommonHelpers;

	/// <summary>
	///  class to filter the request datas and log them
	/// </summary>
	public class RequestLogFilter : Attribute, IActionFilter
	{
		public string SASTXSSEnable = "";
		public string serializationEnable = "";
		public bool SanitizeDataEnabled { get; set; }

		/// <summary>
		/// request log filter constructor
		/// </summary>
		public RequestLogFilter()
		{
			SanitizeDataEnabled = true;

			//Need to get from config manager
			SASTXSSEnable = "1";
			serializationEnable = "1";
		}

		/// <summary>
		/// To do filter before processing the requests
		/// </summary>
		/// <param name="filterContext">context</param>
		public void OnActionExecuting(ActionExecutingContext filterContext)
		{
			try
			{
				//string SASTXSSEnable = ConfigurationManager.AppSettings["SASTXSSEnable"].ToString();
				//string serializationEnable = ConfigurationManager.AppSettings["SASTXSSEnable"].ToString();
				if (SASTXSSEnable == "1")
				{
					if (SanitizeDataEnabled)
					{
						if (filterContext != null && filterContext.ActionArguments != null && filterContext.ActionArguments.Keys != null && filterContext.ActionArguments.Keys.Count > 0)
						{
							var _fContext = (Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor)filterContext.ActionDescriptor;

							string _clientIP = filterContext.HttpContext.Request.HttpContext.Connection.RemoteIpAddress == null ? "" :
													filterContext.HttpContext.Request.HttpContext.Connection.RemoteIpAddress.ToString();

							var logData = new Tuple<string, string, string>(_fContext.ControllerName, _fContext.ActionName, _clientIP);

							foreach (var item in filterContext.ActionArguments.Keys.ToList())
							{
								var currentObject = filterContext.ActionArguments[item];

								if (currentObject != null)
								{
									currentObject = InputSanitizer.GetInputSanitized(currentObject, serializationEnable, logData);
								}
								filterContext.ActionArguments[item] = currentObject;
							}
						}
					}
				}
			}
			catch (Exception ex)
			{
				var _apiUrl = (Microsoft.AspNetCore.Mvc.Controllers.ControllerActionDescriptor)filterContext.ActionDescriptor;
				LogHelper.LogExceptionAsync(ex, _apiUrl.ControllerName, _apiUrl.ActionName);
				filterContext.Result = new JsonResult(new { statusCode = 500, statusDesc = "Invalid input" });
			}
		}

		/// <summary>
		/// Operation to be performed after the action completed
		/// </summary>
		/// <param name="context">context</param>
		public void OnActionExecuted(ActionExecutedContext context)
		{

		}
	}
}
