import { Component, OnInit } from '@angular/core';
import { ControlService } from '../Service/control.service';
import { ModalService } from '../Service/modal.service';

@Component({
  selector: 'app-tab-selection-master',
  templateUrl: './tab-selection-master.component.html',
  styleUrls: ['./tab-selection-master.component.scss']
})
export class TabSelectionMasterComponent implements OnInit {



  Country: any;
  VisaType: any;
  SectionType: any;
  TabAlignment: string = "Horizontal";
  DynamicScroll: string = "Enable";
  AccordionView: string = "Off";




  AlignmentSettingList: any = [];
  TickerText: any;
  public pageNumber: number = 1;
  public Count: number;
  Title: any;

  Name: any;

  ButtonText: any;

  Description: any;

  Modal: any = null;

  ModalList: any = [];

  constructor(private service: ControlService, private modalService: ModalService) { }


  openModal(name: any) {

    this.modalService.openModal(name);

  }

  ngOnInit(): void {
    this.getControllData();
    this.getModalData();
    this.onPageChange(2);
  }

  getControllData() {
    this.service.getTabAlignmentData().subscribe((data: any) => {
      if (data) {
        this.AlignmentSettingList = data;
      }
    });
  }
  saveTabAlignment() {
    const Model = {
      CountryName: this.Country,
      VisaType: this.VisaType,
      TabAlignment: this.TabAlignment,
      TickerText: this.TickerText,
      DynamicScroll: this.DynamicScroll,
      IsAllowAccordion: this.AccordionView
    }

    this.service.postTabSelection(Model).subscribe((data: any) => {
      debugger
      if (data) {
        this.AlignmentSettingList = data;

        //this.getControllData();
      }
    });
  }
  saveNewModal() {

    const NewModal = {

      modalTitle: this.Title,

      modalName: this.Name,

      modalButtonText: this.ButtonText,

      modalDescription: this.Description

    }

    debugger;

    this.service.postModalData(NewModal).subscribe((data: any) => {

      debugger;

      if (data) {

        this.ModalList = data;

      }

    });

  }

  getModalData() {

    this.service.getModalData(this.Modal).subscribe((data: any) => {

      if (data) {

        debugger;

        this.ModalList = data;

      }

    });

  }

  onPageChange(pageNumber) {
    const Model = {
      CountryName: this.Country,
      VisaType: this.VisaType,
      TabAlignment: this.TabAlignment,
      TickerText: this.TickerText
    }

    this.service.postTabSelectionpagination(pageNumber).subscribe((data: any) => {
      debugger
      if (data) {
        this.AlignmentSettingList = data.items;
        this.pageNumber = data.pageIndex;
        this.Count = data.count;
        //this.AlignmentSettingList = data;

        //this.getControllData();
      }
    });
  }
}
