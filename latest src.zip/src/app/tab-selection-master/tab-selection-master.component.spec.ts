import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TabSelectionMasterComponent } from './tab-selection-master.component';

describe('TabSelectionMasterComponent', () => {
  let component: TabSelectionMasterComponent;
  let fixture: ComponentFixture<TabSelectionMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TabSelectionMasterComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(TabSelectionMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
