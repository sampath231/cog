import { Component, EventEmitter, Input, OnChanges, OnInit, Output } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Subject, switchMap, takeUntil, tap } from 'rxjs';
import { ControlService } from 'src/app/Service/control.service';

import { FieldConfig } from '../../models/field-config.interface';
import * as $ from 'jquery';
// import { validateForm } from '../form-validation/helper-functions/validate-form';

import { validateForm } from '../../dynamic-form-validation/form-validation/helper-functions/validate-form';
@Component({
  exportAs: 'dynamicForm',
  selector: 'dynamic-form',
  styleUrls: ['dynamic-form.component.scss'],
  template: `
    <form
      class="dynamic-form " 
      [formGroup]="form" *ngIf="form"
      (submit)="handleSubmit($event)" style="margin-left: 50px;">
      <ng-container class="col"
        *ngFor="let field of config;"
        dynamicField
        [config]="field"
        [group]="form">
      </ng-container>
    </form>
  `
})
export class DynamicFormComponent implements OnChanges, OnInit {
  @Input()
  // config: FieldConfig[] = [];
  config: FieldConfig[] = [];

  @Input()
  public tabType: string = ""; 

  @Output()
  submit: EventEmitter<any> = new EventEmitter<any>();

  form!: FormGroup;

  get controls() { return this.config.filter((control:any) => control.type !== 'button'); }
  get changes() { return this.form.valueChanges; }
  get valid() { return this.form.valid;}
  get value() { return this.form.value;}
  private unsubscribe = new Subject<void>()
  
  constructor(private fb: FormBuilder,private service: ControlService) {}

  ngOnInit() {
    // //console.log('config',this.config);
    // var cont = this.controls.filter((control:any)=> control.formtabname == this.tabType);
    // if(cont.length !=0){
    //   this.form = this.createGroup();
    //   this.setValueChange();
    // }   

   
    if(this.controls.length != 0){
      this.form = this.createGroup();
      this.setValueChange();

      this.form.valueChanges.pipe(
        switchMap((formValue:any) => 
          this.service.postJsonData(formValue,'USA','PR')
          ),
        takeUntil(this.unsubscribe)
    ).subscribe(() => console.log('Saved'))

      
    
    }
   
  }

  saveData(Data:any){

  }

  ngOnChanges() {
    // if (this.form) {
    //   debugger;
    //   const controls = Object.keys(this.form.controls);
    //   const configControls = this.controls.map((item) => item.name);

    //   controls
    //     .filter((control) => !configControls.includes(control))
    //     .forEach((control) => this.form.removeControl(control));

    //   configControls
    //     .filter((control) => !controls.includes(control))
    //     .forEach((name) => {
    //       const config = this.config.find((control) => control.name === name);
    //       this.form.addControl(name, this.createControl(config));         
    //     });

    // }
  }

  createGroup() {
    debugger;
    const group = this.fb.group({});
    // var cont = this.controls.filter((control:any)=> control.formtabname == this.tabType);
    // //console.log('cont',cont);
    this.controls.forEach((control:any) => {
      // if(control.formtabname == this.tabType){
      //   group.addControl(control.name, this.createControl(control))
      // }
     
      group.addControl(control.name, this.createControl(control))
     });
    return group;
  }

  setValueChange(){
    this.controls.forEach((control:any) => {

      if(control.id != undefined)
      {

      this.service.getcontrolgrouping(control.id).subscribe((res1: any) =>{

        if(control.id == 8 && res1 != null && res1 != '' && res1[0].eventtype == 'valuechange'){
          if( res1[1].eventtype == 'disable'){
            this.setDisabled('StateName', true);
          }
       this.form.controls['CountryName'].valueChanges.subscribe((value: any) => {
       
             
              if(value.trim() != ''){                
                this.setDisabled('StateName', false);
                $('#StateName').show();
                var objlocalModel = {
                  optSelect  : value.trim(),
                  optionType  : 'CITYSELECT'
                }
                this.service.postApi(objlocalModel,'/GetMasterCityInformation').subscribe((res: any) => {
                  $('#StateName').empty().append('<option value="null">-Select City-</option>'); // Line 3
         
                  for (var i = 0; i <= res.length-1; i++) { // Line 8
                    $('#StateName').append('<option value="' + res[i].id + '">' + res[i].name + '</option>'); // Line 9
                  }
                });
                sessionStorage.setItem("SelectedOption",value.trim())
              }else{
                this.setDisabled('StateName', true);
                $('#StateName').hide();

              }
              
       });}
     });
     }});
  }

  createControl(config: any) {
    const { disabled, validation, value } = config;
    return this.fb.control({ disabled, value }, validation);
  }

  handleSubmit(event: Event) {
debugger;
    validateForm(this.form);
    if(this.form.valid){
      event.preventDefault();
      event.stopPropagation();
      this.submit.emit(this.value);
    }else{
    
        this.form.markAllAsTouched();
    
    }
    
  }

  setChangeEvent(_name: string){

  }

  setDisabled(name: string, disable: boolean) {
    if (this.form.controls[name]) {
      const method = disable ? 'disable': 'enable';
      this.form.controls[name][method]();
      return;
    }

    this.config = this.config.map((item) => {
      if (item.name === name) {
        item.disabled = disable;
      }
      return item;
    });
  }

  setValue(name: string, value: any) {
    this.form.controls[name].setValue(value, {emitEvent: true});   
  }

  // ngAfterViewInit(){
  //     this.form.controls['firstName'].valueChanges.subscribe((value:any) => {
  //       //console.log(value);
  //     });
  // }
}