import { Injectable } from '@angular/core';
import { ControlService } from 'src/app/Service/control.service';
import { validationMessages } from '../helper-functions/validation-message';

@Injectable({
  providedIn: 'root'
})
export class FormValidationService {
  private errorMessages: any = validationMessages;

  constructor(private service: ControlService) { }

  /**
   * @description Processes the form control id and return error-validation-message
   * @param id {string}, defaults to `generic-required`
   * @returns error-message {string}
   */

//    async getWorkExp() {
//     await this.service.getApi('/GetAllExpe').subscribe((data: any) => { this.tableData = data; });

//     await this.service.getApi('/GetPreVisa').subscribe((data: any) => { this.tablePreExpData = data; });

//  }

 async getValidationMessage(id,errorType): Promise<string> {
    debugger;
    var errormsg = ""

    var objlocalModel = {
      controlID: id,
      optionType: 'S',
      validationType : errorType
    }


    await this.service.postApi(objlocalModel, '/GetControlValidation').subscribe((res: any) => {
      //this.projQustionModel = res 
      console.log(res);
      if(res.length !=0){
        errormsg = res[0].validationMessage;
      }else{
        errormsg =  'This field is required'
      }
    });

    return errormsg;

    // return this.errorMessages[id] || this.errorMessages[`generic-${id.split('-')[1]}`];
  }
}
