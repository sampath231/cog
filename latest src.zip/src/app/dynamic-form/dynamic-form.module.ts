import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

import { DynamicFieldDirective } from './components/dynamic-field/dynamic-field.directive';
import { DynamicFormComponent } from './containers/dynamic-form/dynamic-form.component';
import { FormButtonComponent } from './components/form-button/form-button.component';
import { FormInputComponent } from './components/form-input/form-input.component';
import { FormSelectComponent } from './components/form-select/form-select.component';
import { FormRadioComponent } from './components/form-radio/form-radio.component';
import { FormCheckComponent } from './components/form-check/form-check.component';
import { FormLabelComponent } from './components/form-label/form-label.component';
import { FormDatePickerComponent } from './components/form-date-picker/form-date-picker.component';
import { FormFileUploadComponent } from './components/form-file-upload/form-file-upload.component'
import {MaterialModule} from '../material-module';
import { ProductFilterPipe } from  './filters/select-filter.pipe';
import {DynamicTableComponent} from './components/form-table/dynamic-table.component';
import {FormtableComponent} from './components/form-table/form-table.component';
import { FormsModule } from '@angular/forms';
import { ErrorComponent } from '../dynamic-form/dynamic-form-validation//form-validation/error-component/error-component';
import { FormControlValidationDirective } from '../dynamic-form/dynamic-form-validation/form-validation/directives/form-control-validation.directive';
import { FormGroupValidationDirective } from '../dynamic-form/dynamic-form-validation/form-validation/directives/form-group-validation.directive';
import {
  NgxMatDatetimePickerModule,
  NgxMatNativeDateModule,
  NgxMatTimepickerModule
} from '@angular-material-components/datetime-picker';




@NgModule({
  imports: [
    CommonModule,
    ReactiveFormsModule,MaterialModule,FormsModule, NgxMatDatetimePickerModule,
    NgxMatNativeDateModule,
    NgxMatTimepickerModule
  ],
  declarations: [
    DynamicFieldDirective,
    DynamicFormComponent,
    FormButtonComponent,
    FormInputComponent,
    FormSelectComponent,FormRadioComponent,FormCheckComponent,
    FormLabelComponent, FormDatePickerComponent,FormFileUploadComponent,
    ProductFilterPipe,
    DynamicTableComponent,FormtableComponent,
    ErrorComponent,
    FormControlValidationDirective,
    FormGroupValidationDirective,
    
    
    
  
    
    
  ],
  exports: [
    DynamicFormComponent
  ],
  entryComponents: [
    FormButtonComponent,
    FormInputComponent,
    FormSelectComponent,FormRadioComponent
  ]
})
export class DynamicFormModule {}
