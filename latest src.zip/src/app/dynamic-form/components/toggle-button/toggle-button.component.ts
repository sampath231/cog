import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';

@Component({
  selector: 'app-toggle-button',
  templateUrl: './toggle-button.component.html',
  styleUrls: ['./toggle-button.component.scss']
})
export class ToggleButtonComponent implements Field {
  config!: FieldConfig;
  group!: FormGroup;
  model: any = {};
  
  public options = [
  {value: "yes", id:"YES"},
  {value: "no", id:"NO"},
]

onSubmit() {
  alert('SUCCESS!! :-)\n\n' + this.model)
}
}