import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../../models/field-config.interface';
import { Field } from '../../models/field.interface';

@Component({
  selector: 'form-radio',
  template: `
  <div class="dynamic-field row mb-3"
      [formGroup]="group">
      <label class="col-sm-2 col-form-label">{{ config.label }}:<span *ngIf="config.required == true" style="color: red;">*</span> &nbsp;&nbsp;&nbsp;</label>
      <div class="col-sm-6">
      <ul class="">
        <li class="list-group-item form-control" *ngFor="let option of config.options">
           <input type="radio"
           [formControlName]="config.name" id="{{ config.name }}" [value]="option.id" />
           {{option.name}}
        </li>
      </ul>
      </div>
  </div>
  `,
  styleUrls: ['./form-radio.component.scss']
})
export class FormRadioComponent implements Field {

  config!: FieldConfig;
  group!: FormGroup;

}
