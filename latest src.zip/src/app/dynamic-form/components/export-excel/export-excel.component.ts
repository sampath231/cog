import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-export-excel',
  templateUrl: './export-excel.component.html',
  styleUrls: ['./export-excel.component.scss']
})
export class ExportExcelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
