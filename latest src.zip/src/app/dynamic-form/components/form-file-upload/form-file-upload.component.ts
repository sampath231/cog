import { Component, OnInit } from '@angular/core';
import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';
import { FormGroup } from '@angular/forms';

@Component({
  selector: 'app-form-file-upload',
  template: `
   <div 
      class="dynamic-field row mb-3" 
      [formGroup]="group">
      <label class="col-sm-2 col-form-label">{{ config.label }}:<span *ngIf="config.required == true" style="color: red;">*</span> &nbsp;&nbsp;&nbsp;</label>
      <div class="col-sm-6">
      <input type="file" class="form-control file-upload" [formControlName]="config.name" onchange="//console.log(event.target.files)">
      </div>
    </div>
  `,
  styleUrls: ['./form-file-upload.component.scss']
})
export class FormFileUploadComponent implements Field {

  config!: FieldConfig;
  group!: FormGroup;

}
