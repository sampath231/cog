import { Component, Input, Output, EventEmitter, OnInit, ViewChild } from '@angular/core';
import { FormArray, FormGroup, FormControl } from '@angular/forms';
import { ControlService } from 'src/app/Service/control.service';
import { MatTableDataSource } from '@angular/material/table';
import { MatSelectChange } from '@angular/material/select';
import { Data } from '@angular/router';
import {MatSort,Sort} from '@angular/material/sort';
import { LiveAnnouncer } from '@angular/cdk/a11y';
import {MatPaginator} from '@angular/material/paginator';

@Component({
  selector: 'dinamic-table',
  template: `
  <div class="mt-2">

  <mat-form-field appearance="fill">
  <mat-label>Columns</mat-label>
  <mat-select [(ngModel)]="selectedHeaders" multiple>
    <mat-select-trigger>
      <!-- {{selectedHeaders.value?.[0] || ''}}
      <span *ngIf="(selectedHeaders.value?.length || 0) > 1" class="example-additional-selection">
        (+{{(selectedHeaders.value?.length || 0) - 1}} {{selectedHeaders.value?.length === 2 ? 'other' : 'others'}})
      </span> -->
    </mat-select-trigger>
    <mat-option *ngFor="let header of selectDropdownAllColoumns" [value]="header">{{header}}</mat-option>
  </mat-select>
</mat-form-field>

<a class="btn btn-success me-1" (click)="setColumnPreference()">Select Column</a>
<!-- <div [ngClass]="{'form-scroll': DynamicScroll}">
  <table class="table" >
    <thead class="">
        <tr>
            <th *ngFor="let head of headers">{{head}}</th>
            <th *ngIf="currentTable == 'EmployeeExperienceDetails'"><button class="btn btn-light" (click)="add()">Add</button></th>
        </tr>
    </thead>
    <tbody>
        <tr *ngFor="let item of formArray.controls;let i=index" [formGroup]="formGroup(i)">
            <ng-container *ngIf="editIndex==i">
               <td *ngFor="let column of columns">
               
              <div *ngIf="column=='fromDate';else other_content">
                  <input type="date" id="column" [formControlName]="column">
              </div>
              <ng-template #other_content>
                  <input [formControlName]="column">
              </ng-template>  

                 
               </td>
            </ng-container>
            <ng-container *ngIf="editIndex!=i">
               <td *ngFor="let column of columns">
                   {{formArray.at(i).value[column]}}
               </td>
            </ng-container>
            <td *ngIf="currentTable == 'EmployeeExperienceDetails'">
              <a class="btn btn-success me-1" (click)="edit(i)">{{editIndex==i?'ok':'edit'}}</a>
              <a class="btn btn-link" *ngIf="editIndex==i" (click)="cancel(i)">cancel</a>
              <a *ngIf="editIndex!=i" class="btn btn-danger" (click)="formArray.removeAt(i)"> </a>
              <a *ngIf="editIndex!=i" class="btn btn-danger" (click)="remove(i)">remove</a>
            </td>
        </tr>
    </tbody>
</table> 
</div> -->
</div>

<div class="row">



<!-- filters - country/visatype/duration -->
<ng-container *ngIf="currentTable == 'EmployeePreviousVisa'">
  <mat-form-field appearance="fill" *ngFor="let visafilter of visaFilters">
      <mat-label>{{visafilter.name}}</mat-label>
      <mat-select [(value)]="visafilter.defaultValue" (selectionChange)="applyVisaFilter($event,visafilter)">
        <mat-option *ngFor="let op of visafilter.options" [value]="op">
          {{op}}
        </mat-option>
      </mat-select>
  </mat-form-field>
</ng-container >
<!-- search -->
<div>
<mat-form-field appearance="fill" style="display: flex;margin-left: auto;">
  <mat-label>Search</mat-label>
  <input matInput (keyup)="applyFilter($event.target.value)" placeholder="Search columns" #input>
</mat-form-field>
</div>

<!-- Add new row/ remove rows -->
<article *ngIf="currentTable == 'EmployeeExperienceDetails'" class="table-header">
  <button class="button-remove-rows" mat-button (click)="removeSelectedRows()"> Remove Rows</button>
  <button class="button-add-row" mat-button (click)="addRow()">Add Row</button>
</article>

<div [ngClass]="{'form-scroll': DynamicScroll}">

<table mat-table [dataSource]="visaDataFilter" matSort (matSortChange)="announceSortChange($event)">
  <ng-container [matColumnDef]="col.key" *ngFor="let col of tableHeaders">
    <th mat-header-cell *matHeaderCellDef mat-sort-header sortActionDescription="Sort by {{col.label}}">{{ col.label }}</th>
    <td mat-cell *matCellDef="let element">
      <div [ngSwitch]="col.type" *ngIf="!element.isEdit">
        <ng-container *ngSwitchCase="'isSelected'">
          <mat-checkbox (change)="element.isSelected = $event.checked"></mat-checkbox>
        </ng-container>
        <div class="btn-edit" *ngSwitchCase="'isEdit'">
          <button mat-button (click)="element.isEdit = !element.isEdit">Edit</button>
          <button mat-button class="button-remove" (click)="removeRow(element.workExpID)">Delete</button>
        </div>
        <span *ngSwitchCase="'date'">{{ element[col.key] }}</span>
        <span *ngSwitchDefault>{{ element[col.key] }}</span>
      </div>
      <div [ngSwitch]="col.type" *ngIf="element.isEdit">
        <div *ngSwitchCase="'isSelected'"></div>
        <div class="btn-edit" *ngSwitchCase="'isEdit'">
          <button mat-button (click)="saveNewRow(element)">Done</button>
        </div>
        <mat-form-field class="form-input" *ngSwitchCase="'date'" appearance="fill">
          <mat-label>Choose a date</mat-label>
          <input matInput [matDatepicker]="picker" [(ngModel)]="element[col.key]"/>
          <mat-datepicker-toggle matSuffix [for]="picker"></mat-datepicker-toggle>
          <mat-datepicker #picker></mat-datepicker>
        </mat-form-field>
        <mat-form-field class="form-input" *ngSwitchDefault>
          <input [type]="col.type" matInput [(ngModel)]="element[col.key]" />
        </mat-form-field>
      </div>
    </td>
  </ng-container>
  <tr mat-header-row *matHeaderRowDef="displayedColumns; sticky:true"></tr>
  <tr mat-row *matRowDef="let row; columns: displayedColumns"></tr>
</table>
  <!--<table mat-table [dataSource]="visaDataFilter" class="mat-elevation-z8">
    <ng-container [matColumnDef]="column" *ngFor="let column of tableHeaders">
      <th mat-header-cell *matHeaderCellDef> {{column}} </th>
      <td mat-cell *matCellDef="let col"> {{col[column]}} </td>
    </ng-container>
    <tr mat-header-row *matHeaderRowDef="tableHeaders"></tr>
    <tr mat-row *matRowDef="let row; columns: tableHeaders;"></tr>
  </table>-->
</div>


<!--   
<mat-form-field appearance="standard">
  <mat-label>Filter</mat-label>
  <input matInput (keyup)="applyFilter($event)" placeholder="Search columns" #input>
</mat-form-field>

<mat-table #table [dataSource]="tableData">

<ng-container *ngFor="let column of tableHeaders" [cdkColumnDef]="column">
  <mat-header-cell *cdkHeaderCellDef>{{ column }}</mat-header-cell>
  <mat-cell *cdkCellDef="let row">{{ column(row) }}</mat-cell>
</ng-container>
<mat-header-row *matHeaderRowDef="tableHeaders"></mat-header-row>
<mat-row *matRowDef="let row; columns: tableHeaders;"></mat-row>
</mat-table> -->



</div>
<!-- <button type="submit" class="btn btn-primary" (click)="submit.next(formArray.value)">submit</button> -->
  `,
  styles: [`
  table .btn{
    padding:.1rem 1rem;
    font-size:.85rem
  }

  .form-scroll {
  height: 370px;
  overflow-x: hidden;
  overflow-y: auto;
  overflow-x: scroll;
}
.mat-form-field {
  width: fit-content;
}
.mat-table {
  overflow-x: scroll;
  max-width: 99%;
}

.mat-cell,
.mat-header-cell {
  word-wrap: initial;
  display: table-cell;
  padding: 0px 10px;
  line-break: unset;
  width: 100%;
  white-space: nowrap;
  overflow: hidden;
  vertical-align: middle;
}

.mat-row,
.mat-header-row {
  display: table-row;
}
  `],
})
export class DynamicTableComponent implements OnInit  {
  formArray = new FormArray([]);
  columns: string[] = [];
  headers: string[] = [];
  editIndex: number = -1;
  oldValue: any;
  selectedHeaders;

  
  DynamicScroll : boolean = true;
  AlignmentSetting : any;
  Country: any = 'USA';
  VisaType: any = 'PR';
  currentTable = "";



  //mat table filter
  
  tableHeaders;
  tableData;
  visaData;
  visaDataFilter;
  country: string[]=['All', 'Singapore', 'United Kingdom', 'Netherlands'];
  visaType: string[]=['All','1', '2'];
  duration: string[]=['All','181','3','5675', '6', '7', '5'];
  visaFilters: VisaFilters[]=[];
  displayedColumns: string[];
  defaultValue: string = "All";
  filterDictionary= new Map<string,string>();
  selectDropdownAllColoumns: string[] = [];
  //mat table filter


  @Output() submit: EventEmitter<any[]> = new EventEmitter<any[]>()  
  formGroup(i) {
    return this.formArray.at(i) as FormGroup;
  }
  @Input('data') set _data(value: any[]) {
    this.tableData = value; 
    this.visaData = value;//mat table filter
    this.visaDataFilter = new MatTableDataSource(value);//mat table filter
   
  }
  @ViewChild(MatSort) sort: MatSort;

  
  constructor(private service: ControlService, private _liveAnnouncer: LiveAnnouncer) {

    this.currentTable = sessionStorage.getItem('tableName');
    this.service.getTabAlignmentData().subscribe((data: any) => {
      if (data) {
        this.AlignmentSetting = data.filter((tab: any) => tab.visaType == this.VisaType && tab.countryName == this.Country);
        if (this.AlignmentSetting != null && this.AlignmentSetting.length >0) {
          this.DynamicScroll = this.AlignmentSetting[0].dynamicScroll == "Enable" ? true : false
        }
      }
    });
    this.getColumnPreference();
    
  }
  //mat table filter
  ngOnInit(): void {
    
    this.visaFilters.push({name:'country',options:this.country,defaultValue:this.defaultValue});
    this.visaFilters.push({name:'visaType',options:this.visaType,defaultValue:this.defaultValue});
    this.visaFilters.push({name:'duration',options:this.duration,defaultValue:this.defaultValue});
    this.visaDataFilter =  new MatTableDataSource(this.tableData);
    this.visaDataFilter.filterPredicate = function (record, filter) {
      let isMatch = false; debugger;
      var map = new Map(JSON.parse(filter));
      for (let [key, value] of map) { 
        isMatch = value == 'All' || record[key as keyof PreviousVisa] == value;
        console.log(record[key as keyof PreviousVisa], value);
        if (!isMatch) return false;
      }
      return isMatch;
    };

  }

  ngAfterViewInit() {
    
    this.visaDataFilter.sort = this.sort;

  }
  announceSortChange(sortState: Sort) {
   
    if (sortState.direction) {
      this._liveAnnouncer.announce(`Sorted ${sortState.direction}ending`);
    } else {
      this._liveAnnouncer.announce('Sorting cleared');
    }
  }
  applyFilter(event: any) {
    
    let quickResult = this.visaData.filter(obj => Object.values(obj).some(val => val?val.toString().toLowerCase().includes(event):false));

   console.log(quickResult);
   this.visaDataFilter = quickResult;
  }
  applyVisaFilter(ob: MatSelectChange, vf: VisaFilters) {
    debugger;
    this.filterDictionary.set(vf.name, ob.value);

    var jsonString = JSON.stringify(
      Array.from(this.filterDictionary.entries())
    );

    this.visaDataFilter.filter = jsonString;
    //console.log(new MatTableDataSource(this.visaDataFilter));
  }
  addRow(){
    const json = {};
    for(var i = 0 ; i < this.headers.length; i++)
    {
      json[this.headers[i]] = "";
    }
    json['isEdit'] = true;
    this.visaData = [json, ...this.visaData];
    this.visaDataFilter = new MatTableDataSource(this.visaData);

  }
  saveNewRow(element:any){
   // debugger;
    console.log(element);
    const date = new Date();
    const newRowData = {nominationId : "SGWP00000001",
                fromDate:date,
                employerName: this.visaData[0].employerName,
                designation: this.visaData[0].designation,
                country: this.visaData[0].country,
                state: this.visaData[0].state
              };
    var objlocalModel = {
      visaType: 'PR', 
      countryType: 'USA',
      tabname: 'EmployeeExperienceDetails',
      JsonData: JSON.stringify(newRowData),
      optionType: 'I',
      rowID:"0"
    }
  
    this.service.postApi(objlocalModel, '/saveWorkExpe').subscribe((res: any) => {
      element.workExpID = res[res.length-1].workExpID;
      element.isEdit = false;
    });

  }
  matTableHeader(headers: any){
    //debugger;
    var i =0;
    this.tableHeaders = [];
    if(this.currentTable == 'EmployeeExperienceDetails')
      this.tableHeaders.push({'key':'isSelected', 'type':'isSelected', 'label': ''});
    for(i = 0;i < headers.length;i++)
    {
      if(headers[i].toLowerCase().indexOf("date") > -1 || headers[i].indexOf("createdBy") > -1 || headers[i].indexOf("createdOn") > -1 )
        this.tableHeaders.push({'key': headers[i], 'type': 'date', 'label': headers[i] }); 
      else
        this.tableHeaders.push({'key': headers[i], 'type': 'input', 'label': headers[i]});
    }
    if(this.currentTable == 'EmployeeExperienceDetails')
      this.tableHeaders.push({'key':'isEdit', 'type':'isEdit', 'label': ''});
    //console.log(this.tableHeaders);
    this.displayedColumns = this.tableHeaders.map((col) => col.key);


    console.log(this.tableHeaders,'tableheader');
    console.log(this.selectedHeaders,'selectheader');
  
  }
  removeRow(id: number) {

    if(id != null){
      if (confirm("Are you sure to delete the row")) {

        var objlocalModel = {
          visaType: 'PR',
          countryType: 'USA',
          tabname: 'EmployeeExperienceDetails',
          JsonData: '',
          optionType: 'D',
          rowID: id.toString()
        }
    
        this.service.postApi(objlocalModel, '/saveWorkExpe').subscribe((res: any) => {
          
        });

        this.visaData = this.visaData.filter((u: any) => u.workExpID !== id);
        this.visaDataFilter = new MatTableDataSource(this.visaData);
      }
      }
      else{
        alert("Select at least one row");
      }
    //this.dataSource = this.dataSource.filter((u) => u.id !== id);
  }
  removeSelectedRows() {  
    if(this.visaData.filter((u: any) => u.isSelected).length > 0){
    if (confirm("Are you sure to delete the rows")) {
      this.visaDataFilter = new MatTableDataSource(this.visaData.filter((u: any) => !u.isSelected));
      for(var i = 0 ; i < this.visaData.filter((u: any) => u.isSelected).length ; i++){
        var objlocalModel = {
          visaType: 'PR',
          countryType: 'USA',
          tabname: 'EmployeeExperienceDetails',
          JsonData: '',
          optionType: 'D',
          rowID: this.visaData.filter((u: any) => u.isSelected)[i].workExpID.toString()
        }
        //alert(this.visaData.filter((u: any) => u.isSelected)[i].workExpID.toString());
        this.service.postApi(objlocalModel, '/saveWorkExpe').subscribe((res: any) => {
        });
      }
      this.visaData = this.visaDataFilter;
    }
    }
    else{
      alert("select the rows");
    }
  }
  //mat table filter
  onColumnChange() {
    debugger;
    this.headers;
    this.selectedHeaders
    this.tableData;


    // var myArray = this.columns.filter( ( el ) => this.selectedHeaders.includes( el ) );

    this.columns = this.selectedHeaders;
    this.headers = this.columns.map(
      (x) => x[0].toUpperCase() + x.substr(1).toLowerCase()
    );
    this.matTableHeader(this.headers);//mat table header
    this.selectedHeaders.forEach(elements => {

    });

    
    this.formArray = new FormArray(this.tableData.map((data) => this.createGroup(data)));


  }

  getColumnPreference() {
    debugger;
    this.service.getApi('/getColumnPreference').subscribe((res: any) => {


      if (res.length != 0) {
        var seleColm = res.filter((tab: any) => tab.tableName == sessionStorage.getItem('tableName'));

        this.selectedHeaders = JSON.parse(seleColm[0].columnJsonData);

        if (this.selectedHeaders) {
          this.columns = this.selectedHeaders;
          this.matTableHeader(this.columns);//mat table header
          this.selectDropdownAllColoumns = Object.keys(this.tableData[0]);
          // this.columns = Object.keys(this.tableData[0]);
          //this.tableHeaders = this.columns;
          // this.selectedHeaders = this.columns;

        } else {
          this.columns = Object.keys(this.tableData[0]);
          this.matTableHeader(this.columns);//mat table header
          this.selectedHeaders = this.columns;
          this.selectDropdownAllColoumns = this.columns;
        }


        this.headers = this.columns.map(
          (x) => x[0].toUpperCase() + x.substr(1).toLowerCase()
        );

        this.formArray = new FormArray(this.tableData.map((data) => this.createGroup(data)));


      } else {
        this.columns = Object.keys(this.tableData[0]);
        this.matTableHeader(this.columns);//mat table header
        this.selectedHeaders = this.columns;
        this.selectDropdownAllColoumns = this.columns;
        this.headers = this.columns.map(
          (x) => x[0].toUpperCase() + x.substr(1).toLowerCase()
        );

        this.formArray = new FormArray(this.tableData.map((data) => this.createGroup(data)));

      }


    });

  }

  setColumnPreference() {
    debugger;
    this.columns = this.selectedHeaders;
    this.matTableHeader(this.columns);
    this.headers = this.columns.map(
      (x) => x[0].toUpperCase() + x.substr(1).toLowerCase()
    );
    this.formArray = new FormArray(this.tableData.map((data) => this.createGroup(data)));

    if (sessionStorage.getItem('tableName') == 'EmployeeExperienceDetails') {

      var objlocalModel = {
        visaType: 'PR',
        countryType: 'USA',
        tabname: sessionStorage.getItem('tableName'),
        JsonData: JSON.stringify(this.selectedHeaders)
      }

    } else {

      var objlocalModel = {
        visaType: 'H1',
        countryType: 'USA',
        tabname: sessionStorage.getItem('tableName'),
        JsonData: JSON.stringify(this.selectedHeaders)
      }

    }

    this.service.postApi(objlocalModel, '/setColumnPreference').subscribe((res: any) => {


    });

  }

  createGroup(data: any = null) {
    if (!data) {
      data = {};
      this.columns.forEach(x => {
        data[x] = null;
      })
    }
    const formGroup = new FormGroup({});
    Object.keys(data).forEach((key: string) => {
      formGroup.addControl(key, new FormControl(data[key]));
    });
    return formGroup;
  }
  edit(index) {
    this.editIndex = this.editIndex == index ? -1 : index;
    this.oldValue = { ...this.formArray.at(index).value };

    if (this.editIndex) {
      var objlocalModel = {
        visaType: 'PR',
        countryType: 'USA',
        tabname: 'EmployeeExperienceDetails',
        JsonData: JSON.stringify(this.oldValue),
        optionType: 'I'
      }

      this.service.postApi(objlocalModel, '/saveWorkExpe').subscribe((res: any) => {



      });
    }

  }
  add() {
    this.oldValue = null;
    this.editIndex = this.formArray.controls.length;
    this.formArray.push(this.createGroup())
  }
  cancel(index) {
    if (this.oldValue)
      this.formArray.at(index).setValue(this.oldValue);
    else
      this.formArray.removeAt(index);

    this.editIndex = -1;
  }

  remove(index) {
    debugger;

    var deleted = this.formArray.at(index).getRawValue();


    var objlocalModel = {
      visaType: 'PR',
      countryType: 'USA',
      tabname: 'EmployeeExperienceDetails',
      JsonData: '',
      optionType: 'D',
      rowID: deleted.workExpID.toString()
    }

    this.service.postApi(objlocalModel, '/saveWorkExpe').subscribe((res: any) => {

      this.tableData = res;
      debugger;
      //mat table filter
      this.visaData = res; 
      this.visaDataFilter = new MatTableDataSource(res);
      this.displayedColumns = this.headers; 
      //mat table filter
      this.onColumnChange();

    });

  }
}

export interface VisaFilters {
  name:string;
  options:string[];
  defaultValue:string;
}

export interface PreviousVisa {
  prevVisaId: number;
  nominationId: string;	
  country:string;
  visaType: number;
  visaTypeDesc: string;
  validFrom: Date;	
  validTo: Date;
  duration: string;	
  typeOfEntry: string;
  ishcmdata: boolean;
  createdBy: string;	
  createdOn: Data;
  updatedBy: string;	
  updatedOn: Date;	
  isDeniedCase: boolean;
}
