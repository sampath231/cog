import { Component } from '@angular/core';
import { FormGroup } from '@angular/forms';

import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';

@Component({
  selector: 'form-select',
  styleUrls: ['form-select.component.scss'],
  template: `
    <div 
      class="dynamic-field row mb-3" 
      [formGroup]="group">
      <label class="col-sm-2 col-form-label">{{ config.label }} :<span *ngIf="config.required == true" style="color: red;">*</span> &nbsp;&nbsp;&nbsp;</label>
      <div class="col-sm-6">{{config.formtooltip}}
      <select class="form-control" [title]="config.formtooltip" required  
      appFormControlValidation
      validationMsgId={{config.id}}
      [formControlName]="config.name" [id]="config.name" style="height: 45px;">
        <option value="">{{ config.placeholder }}</option>
        <option *ngFor="let option of config.options" value={{option.id}}>
          {{ option.name }}
        </option>
      </select>
      </div>
    </div>
  `
})
export class FormSelectComponent implements Field {
  
  config!: FieldConfig;
  group!: FormGroup;
}
