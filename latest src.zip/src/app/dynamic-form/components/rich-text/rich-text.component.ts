import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ModalService } from 'src/app/Service/modal.service';
import { ControlService } from 'src/app/Service/control.service';


@Component({
  selector: 'app-rich-text',
  templateUrl: './rich-text.component.html',
  styleUrls: ['./rich-text.component.scss']
})
export class RichTextComponent implements  Field {
  config!: FieldConfig;
  group!: FormGroup;
 
  @ViewChild('editor') editor;
  description: string = "Rich text Editor";

  setStyle(style: string) {
    let bool = document.execCommand(style, false, null);
  }

  onChange() {
    console.log(this.editor.nativeElement["innerHTML"]);
  }
}



