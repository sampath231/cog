import { Component, OnInit } from '@angular/core';
import { Field } from '../../models/field.interface';
import { FieldConfig } from '../../models/field-config.interface';
import { FormGroup } from '@angular/forms';


@Component({
  selector: 'app-form-date-picker',
  template: `
     <div 
      class="dynamic-field row mb-3" 
      [formGroup]="group">
      <label class="col-sm-2 col-form-label">{{ config.label }}:<span *ngIf="config.required == true" style="color: red;">*</span></label>
      <!-- <my-date-picker  [attr.name]="config.name" [formControlName]="config.name"
      [attr.placeholder]="config.placeholder">
      </my-date-picker>
       -->
       <div class="col-sm-6">
      <!-- <input class="form-control" matInput [matDatepicker]="picker" [formControlName]="config.name">
      <mat-datepicker-toggle matSuffix [for]="picker"></mat-datepicker-toggle>
      <mat-datepicker #picker></mat-datepicker> -->

      <mat-form-field appearance="fill">
  <mat-label>{{ config.label }}</mat-label>
  
  
  <input *ngIf = "config.pastDate == 'true' && config.featureDate == 'false'" class="form-control" matInput [ngxMatDatetimePicker]="picker" [min]="today" [formControlName]="config.name">
  <input *ngIf = "config.pastDate == 'false' && config.featureDate == 'true'" class="form-control" matInput [ngxMatDatetimePicker]="picker" [max]="today" [formControlName]="config.name">
  <input *ngIf = "config.pastDate == 'true' && config.featureDate == 'true'" class="form-control" matInput [ngxMatDatetimePicker]="picker" [min]="today" [max]="today" [formControlName]="config.name">
  <input *ngIf = "config.pastDate == 'false' && config.featureDate == 'false'" class="form-control" matInput [ngxMatDatetimePicker]="picker" [formControlName]="config.name">

  <!-- <mat-hint>MM/DD/YYYY</mat-hint> -->
  
  <mat-datepicker-toggle matSuffix [for]="picker" ></mat-datepicker-toggle>
  <ngx-mat-datetime-picker #picker></ngx-mat-datetime-picker>
</mat-form-field>
      </div>
    </div>
  `,
  styleUrls: ['./form-date-picker.component.scss']
})    
export class FormDatePickerComponent implements Field {

  config!: FieldConfig;
  group!: FormGroup;

  public today = new Date();


}

