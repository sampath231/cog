"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.FormInputComponent = void 0;
var core_1 = require("@angular/core");
(0, core_1.Component)({
    selector: 'form-input',
    styleUrls: ['form-input.component.scss'],
    template: "\n\n    <div class=\"form-group\"\n\n      [formGroup]=\"group\">\n\n      <label  class=\"label\">{{ config.name}}</label>  \n\n      <!-- <input type=\"text\" [attr.placeholder]=\"config.placeholder\"\n\n        [formControlName]=\"config.name\" [value]=\"config.label\"> -->\n\n        <label class=\"lbl\">{{ config.section }}</label>  \n\n        <br/>\n\n    </div>\n  "
});
var FormInputComponent = /** @class */ (function () {
    function FormInputComponent() {
    }
    return FormInputComponent;
}());
exports.FormInputComponent = FormInputComponent;
//# sourceMappingURL=form-input.component.js.map