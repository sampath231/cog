import { Component, OnInit, Inject } from '@angular/core';

import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

import { ModalService } from 'src/app/Service/modal.service';



@Component({

  selector: 'app-modal',

  templateUrl: './modal.component.html',

  styleUrls: ['./modal.component.scss']

})

export class ModalComponent implements OnInit {
  modalTitle: string;
  modalName: string;
  
  
  isPopupVisible:any=false;


  constructor(

    public dialogRef: MatDialogRef<ModalComponent>,@Inject(MAT_DIALOG_DATA) public modalData: any, private modalService: ModalService) {

    //console.log(modalData);
    
  }



  ngOnInit() { 
 debugger
    this.isPopupVisible=this.modalData.Isshowcontrols
    
  }



  actionFunction() {

    if(this.modalData.actionButtonText == "Logout")

      this.modalService.modalAction(this.modalData);

    this.closeModal();

  }



  closeModal() {

    this.dialogRef.close();

  }



  



}