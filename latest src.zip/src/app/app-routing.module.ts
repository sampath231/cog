import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FormviewComponent } from './formview/formview.component';
import { FormcontrolComponent } from './formcontrol/formcontrol.component';
import { HomeComponent } from './home/home.component';
import {FormdataviewComponent} from './formdataview/formdataview.component';
import { TabSelectionMasterComponent } from './tab-selection-master/tab-selection-master.component';

const routes: Routes = [
  { path:'',component:HomeComponent },
  { path: 'View/:id', component: FormviewComponent },
  { path: 'View', component: FormviewComponent },
  { path: 'Settings', component: FormcontrolComponent},
  { path:'Home',component:HomeComponent },
  {path:'DataView',component:FormdataviewComponent} ,
  { path: 'TabView', component: TabSelectionMasterComponent }
  
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { 

//   const routes: Routes = [
//     { path: 'aboutUs', component: FormviewComponent },
//     { path: 'index', component: FormcontrolComponent}
//  ];
}
