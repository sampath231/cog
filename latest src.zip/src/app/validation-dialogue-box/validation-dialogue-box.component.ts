import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ControlService } from '../Service/control.service';

//export class DialogData {
//  GridData: [];
//  ValidationType: string = "Req";
//  ValidationMessage: string = "This is Req.";
//  ControlID: any;
//}
@Component({
  selector: 'app-validation-dialogue-box',
  templateUrl: './validation-dialogue-box.component.html',
  styleUrls: ['./validation-dialogue-box.component.scss']
})
export class ValidationDialogueBoxComponent implements OnInit {
  ValidationType: string;
  ValidationMessage: string;
  ValidationList: [];
  constructor(private service: ControlService,
    public dialogRef: MatDialogRef<ValidationDialogueBoxComponent>,
    @Inject(MAT_DIALOG_DATA) public DialogDataToPass: any
  ) { }

  ngOnInit() {
    this.onGetValidations();
  }


  onNoClick(): void {
    this.dialogRef.close();
  }
  onSubmit(): void {
    
    var ModelData = {
      validationType : this.ValidationType,
      validationMessage: this.ValidationMessage,
      controlID: this.DialogDataToPass 
    }
    this.service.postApi(ModelData, '/SubmitFormContrlValidation').subscribe((data: any) => {
      if (data) {
        this.ValidationList = data;
      }
    });
    //this.dialogRef.close({ event: "SaveValidation", data: ModelData });
  }
  onGetValidations() {
    this.service.getApi('/getFormContrlValidation?ControlID=' +this.DialogDataToPass ).subscribe((data: any) => {

      if (data) {
        this.ValidationList = data;
      }

    });
  }
  
}
