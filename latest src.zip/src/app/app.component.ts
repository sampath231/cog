import { Component, ViewChild } from '@angular/core';
import { Router } from '@angular/router';

import { Validators } from '@angular/forms';
import { FieldConfig } from './dynamic-form/models/field-config.interface';
import { DynamicFormComponent } from './dynamic-form/containers/dynamic-form/dynamic-form.component';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {
  title = 'MobilePOC';
  


  constructor(private router: Router) {
    this.badgeCount = 5;
  }

  goToIndex() {
    this.router.navigate(['/', 'View']);
  }
  goToAboutUs() {
    this.router.navigate(['/', 'Settings']);
  }
  goToHome(){
    this.router.navigate(['/', 'Home']);
  }
  gotoView(){
    this.router.navigate(['/', 'DataView']);
  }
  gotoTabSelection() {
    this.router.navigate(['/', 'TabView']);
  }
  badgeCount: number;

  

  incrementCount() {
    this.badgeCount++;
  }

  clearCount() {
    this.badgeCount = 0;
  }  
}

