import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormviewComponent } from './formview/formview.component';
import { FormcontrolComponent } from './formcontrol/formcontrol.component';

import { DynamicFormModule } from './dynamic-form/dynamic-form.module';
import { FormsModule } from '@angular/forms';
import { MaterialModule } from './material-module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HomeComponent } from './home/home.component';
import { FormdataviewComponent } from './formdataview/formdataview.component';

import { HttpClientModule } from '@angular/common/http';
import { ControlService } from './Service/control.service';

import { TabSelectionMasterComponent } from './tab-selection-master/tab-selection-master.component';
import { NgxPaginationModule } from 'ngx-pagination';

import { ModalComponent } from './components/modal/modal.component';

import { LoaderComponent } from './components/loader/loader.component';
import { Injectable } from '@angular/core';
import { TimeoutComponent } from './components/timeout/timeout.component';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { LoaderInterceptor } from './interceptors/loader.interceptor';
import { TimeoutInterceptor } from './interceptors/timeout.interceptor';
import { ValidationDialogueBoxComponent } from './validation-dialogue-box/validation-dialogue-box.component';
import { FormPopupComponent } from './dynamic-form/components/form-popup/form-popup.component';
import { MatDialogRef } from '@angular/material/dialog';
import { ToggleButtonComponent } from './dynamic-form/components/toggle-button/toggle-button.component';
import { RichTextComponent } from './dynamic-form/components/rich-text/rich-text.component';
import {
  NgxMatDatetimePickerModule,
  NgxMatNativeDateModule,
  NgxMatTimepickerModule
} from '@angular-material-components/datetime-picker';
import { TreeChecklistComponent } from './dynamic-form/components/tree-checklist/tree-checklist.component';
import { ExportExcelComponent } from './dynamic-form/components/export-excel/export-excel.component';

@NgModule({
  declarations: [
    AppComponent,
    FormviewComponent,
    FormcontrolComponent,
    HomeComponent, FormdataviewComponent, TabSelectionMasterComponent,
    ModalComponent, LoaderComponent, TimeoutComponent,ValidationDialogueBoxComponent,FormPopupComponent,ToggleButtonComponent, RichTextComponent, TreeChecklistComponent, ExportExcelComponent,
  ],
  
  imports: [
    HttpClientModule,
    BrowserModule,
    AppRoutingModule,
    DynamicFormModule, FormsModule, MaterialModule, 
    BrowserAnimationsModule, NgxPaginationModule,MatProgressSpinnerModule,NgxMatDatetimePickerModule,
    NgxMatNativeDateModule,
    NgxMatTimepickerModule
  ],
  providers: [{
    provide: HTTP_INTERCEPTORS,
    useClass: TimeoutInterceptor,
    multi: true
  },{
    provide: MatDialogRef,
    useClass: TimeoutInterceptor,
    multi: true
  },{
    provide: HTTP_INTERCEPTORS,
    useClass: LoaderInterceptor,
    multi: true,
  },FormPopupComponent,ControlService],
  bootstrap: [AppComponent]
})
export class AppModule { }
