import { InterpolationConfig } from '@angular/compiler';
import { Component, Inject, OnInit } from '@angular/core';
import { questionObj } from '../QuestionModel/questionobjModel';
import { ControlService } from '../Service/control.service';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormsModule } from '@angular/forms';
import { ValidationDialogueBoxComponent } from '../validation-dialogue-box/validation-dialogue-box.component';
import * as XLSX from 'xlsx';


@Component({
  selector: 'app-formcontrol',
  templateUrl: './formcontrol.component.html',
  styleUrls: ['./formcontrol.component.scss']
})
export class FormcontrolComponent implements OnInit {
  Lablename: any;
  ControlType: any;
  ControlRequired: any;
  Country: any;
  VisaType: any;
  SectionType: any;
  ControlName: any;
  ControlSequence: number = 0;
  projQustionModel: any = [];
  tabModel: any = [];
  sectionModel: any = [];
  sectionData: any = [];
  TabType: any;
  tooltip: any;
  DateFormat: any;
  PastDate: any;
  FeatureDate: any;
  showdropdown: boolean = false;
  page: number = 1;
  id: number = 0;
  selectedTabREcord: any = [];
  selectedTabSection: any = [];
  EventType:any;

 TableSelected:any;
  SelectedTableColumns:any;
  TableColumns:any;
  tableData:any;
  TableModel:any;
  TableHeaders:any;
  columns: string[] = [];
  headers: string[] = [];
  ApiEndPoint:string;
  ApiEndPointText:string;
  SelectAll:any;
  ColumnFilters: any;
fileName= 'ExcelSheet.xlsx';



  // question : questionObj[]=[
  //   new questionObj(1,'INDIA','PR','EMPDETAILS','NULL','','',false,0,'',''),
  //   new questionObj(1,'INDIA','PR','EMPDETAILS','NULL','prjName','Project Name',false,1,'TEXT',''),
  //   new questionObj(1,'INDIA','PR','EMPDETAILS','NULL','prjEmail','Project Email',false,2,'TEXT','email'),
  //   new questionObj(1,'INDIA','PR','EMPDETAILS','NULL','prjType','Project Type',false,2,'TEXT','number'),
  // ]



  // section: string;
  // value: string;
  // key: string;
  // label: string;
  // required: boolean;
  // order: number;
  // controlType: string;
  // type: ;
  constructor(private service: ControlService, public dialog: MatDialog) { }

  ngOnInit(): void {
    debugger
    // var data = sessionStorage.getItem('projQustionModel');
    // if (data != null) {
    //   this.projQustionModel = JSON.parse(data);
    // }

    this.getControllData();

    this.service.getApi('/getAvailableTables').subscribe((data: any) => {
      this.TableModel = data.map(obj => obj.tableName)

    });





  }

  getControllData() {
    this.service.getQuestions().subscribe((data: any) => {
      debugger
      var projQustionModel = data;
      projQustionModel.forEach((element: any) => {
        const res = new questionObj(
          element.formControlsId,
          element.formControlsCountry,
          element.formControlsVisaType,
          element.formControlsSection,
          '', '',
          element.formControlsName,
          (element.formControlsIsActive == 1) ? true : false,
          element.formControlsSequence, '',
          element.formControlsType,
          element.formControlsClassName, '', false,
          element.formtabname, '',
          element.formtooltip,
          element.dateFormat,
          element.pastDate,
          element.featureDate);



        this.projQustionModel.push(res);
      });
    });
  }

  savecontrol() {
    debugger;
    // new questionObj(1, 'INDIA', 'PR', 'EMPDETAILS', '', '', 'Project name', true, 0, '', 'input','inpPrjName');
    const data = new questionObj(0, this.Country, this.VisaType, this.SectionType, '', '',
      this.Lablename, this.ControlRequired, this.ControlSequence, '', this.ControlType, this.ControlName)


    // this.projQustionModel.push(data);
    var seltab = this.sectionData.filter((tab: any) => tab.formTabId == +this.TabType);

    const visaType = {
      FormControlsSequence: this.ControlSequence,
      FormControlsName: this.Lablename,
      FormControlsType: this.ControlType,
      FormControlsSection: this.SectionType,
      FormControlsIsActive: 1,
      FormControlsIsCreatedAt: new Date(),
      FormControlsCountry: this.Country,
      FormControlsVisaType: this.VisaType,
      FormControlsValidationType: "",
      FormControlsValidationMessage: "",
      FormControlsClassName: this.ControlName,
      FormControlsIsMandatory: 1,
      Formtabname: seltab[0].tabName,
      Formtooltip: this.tooltip,
      DateFormat: this.DateFormat,
      PastDate: this.PastDate,
      FeatureDate: this.FeatureDate,



    }

    this.service.postQuestions(visaType).subscribe((data: any) => {
      if (data) {
        this.getControllData();
      }
    });

    // sessionStorage.setItem('projQustionModel', JSON.stringify(this.projQustionModel));

  }


  // onVisaChange(){
  //   debugger;
  //   this.service.getApi('/GetMasterTab').subscribe((data: any) => {
  //     this.sectionData = data;
  //     this.tabModel = data.filter((tab: any) => tab.visaType == this.VisaType);
  //   });
  // }



  handleChange() {
    this.showdropdown = false;

    if (this.ControlType == "DatePicker") {
      this.showdropdown = true;
    }
  }
  deleteControl(id: number) {
    if (id != null) {
      if (confirm("Are you sure to delete control")) {
        this.service.deleteFormControl(id).subscribe((data: any) => {
          this.getControllData();
        })
      }
    } else {
      alert("Select at least one row");
    }
  }
  OnSectionChange() {

  }
  editControl(data: any) {

    this.id = data.id,
      this.Country = data.countryName,
      this.VisaType = data.visaType,
      this.TabType = data.formtabname,
      //this.SectionType = data.section,
      this.ControlName = data.name,
      this.Lablename = data.label,
      this.ControlType = data.type,
      this.ControlRequired = data.required,
      this.ControlSequence = data.order,
      this.tooltip = data.formtooltip,
      this.DateFormat = data.dateFormat,
      this.PastDate = data.pastDate,
      this.FeatureDate = data.featureDate,
      this.onVisaChange(this.TabType),
      this.onTabChange(data.section)
    // this.selectedTabREcord= this.tabModel.filter((tab: any) => tab.tabName ==tabtypename);
    // if (this.selectedTabREcord ! = null && this.selectedTabREcord.length>0)
    // {
    //   this.TabType=this.selectedTabREcord[0].formTabId
    // }

  }
  onTabChange(sectiontypename: any) {
    debugger;
    this.SectionType = null;
    this.service.getApi('/GetMasterSection').subscribe((data: any) => {
      //this.sectionData = data;
      this.sectionModel = data.filter((tab: any) => tab.formTabId == this.TabType);
      if (sectiontypename != null) {
        this.SectionType = sectiontypename;
      }
      //this.selectedTabSection=this.sectionModel.filter((tab:any) => tab. sectionName ==this.SectionType);
      //this.SectionType =this.selectedTabSection[0].sectionName

    });
  }
  onVisaChange(tabtypename: any) {
    debugger;
    this.service.getApi('/GetMasterTab').subscribe((data: any) => {
      this.sectionData = data;
      this.tabModel = data.filter((tab: any) => tab.visaType == this.VisaType);
      this.selectedTabREcord = this.tabModel.filter((tab: any) => tab.tabName == this.TabType);
      if (this.selectedTabREcord[0] != null) {
        this.TabType = this.selectedTabREcord[0].formTabId;
      }


    });



  }

  AddValidation(data: any) {

    this.id = data.id;

    const dialogRef = this.dialog.open(ValidationDialogueBoxComponent, {
      data: this.id
    });

  }

  getColumns() {
    this.service.getApi('/getColumnPreference').subscribe((data: any) => {
      this.SelectedTableColumns = data.filter(obj => obj.tableName === this.TableSelected);
      this.TableHeaders = JSON.parse(this.SelectedTableColumns[0].columnJsonData);
      this.ApiEndPoint = this.SelectedTableColumns[0].apiEndPoint;
      this.ColumnFilters = JSON.parse(this.SelectedTableColumns[0].coloumnFilters);
      this.getColumnHeaders(this.ApiEndPoint);
    });
  }

  setColumnPreference() {
    debugger;
    this.columns = this.TableHeaders;
    this.headers = this.columns.map(
      (x) => x[0].toUpperCase() + x.substr(1).toLowerCase()
    );
    var objlocalModel = {
      visaType: this.SelectedTableColumns[0].visaType,
      countryType: this.SelectedTableColumns[0].countryType,
      tabname: this.TableSelected,
      JsonData: JSON.stringify(this.TableHeaders),
      apiEndPoint: this.ApiEndPoint,
      TableSeelctAll: this.SelectAll,
      coloumnFilters: JSON.stringify(this.ColumnFilters)
    }

    this.service.postApi(objlocalModel, '/setColumnPreference').subscribe((res: any) => {

      console.log('res', res);

    });
  }


  onSelectAllColumns() {
    this.TableHeaders = this.TableColumns;
  }

  onDeselectAllColumns() {
    this.TableHeaders = null;
  }

  getColumnHeaders(ApiEndPoint: string) {

    this.service.getApi('/' + this.ApiEndPoint).subscribe((data: any) => {
      this.tableData = data;
      this.TableColumns = Object.keys(this.tableData[0]);

    });
  }

  exportexcel(): void
  {
    debugger;
    /* pass here the table id */
    let element = document.getElementById('excel-table');
    const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
 
    /* generate workbook and add the worksheet */
    const wb: XLSX.WorkBook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Sheet1');
 
    /* save to file */  
    XLSX.writeFile(wb, this.fileName);
 
  }
  onChange(){


    
  }

}

