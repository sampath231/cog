import { Component, ComponentFactoryResolver, OnInit, ViewChild, ViewContainerRef } from '@angular/core';
import { ActivatedRoute, ParamMap, Router } from '@angular/router';

import { Validators } from '@angular/forms';
import { FieldConfig } from '../dynamic-form/models/field-config.interface';
import { DynamicFormComponent } from '../dynamic-form/containers/dynamic-form/dynamic-form.component';
import { questionObj } from '../QuestionModel/questionobjModel';
import { elementAt } from 'rxjs';
import { ControlService } from '../Service/control.service';

@Component({
  selector: 'app-formview',
  templateUrl: './formview.component.html',
  styleUrls: ['./formview.component.scss']
})
export class FormviewComponent implements OnInit {

  // @ViewChild('tabPanel', { static: true, read: ViewContainerRef })
  // entry!: ViewContainerRef;

  @ViewChild('tabPanel', { static: false, read: ViewContainerRef })
  entry!: ViewContainerRef;

  @ViewChild(DynamicFormComponent) form!: DynamicFormComponent;
  Country: any = 'USA';
  VisaType: any = 'PR';
  question: questionObj[] = [
    new questionObj(1, 'INDIA', 'PR', 'EMPDETAILS', '', '', 'Project name', true, 0, '', 'input', 'inpPrjName'),
    new questionObj(1, 'INDIA', 'PR', 'EMPDETAILS', '', '', 'Project name', true, 0, '', 'input', 'inpPrjName'),
    // new questionObj(2, 'INDIA', 'PR', 'EMPDETAILS', 'NULL', 'prjName', 'Project Name', false, 1, 'input', '',''),
    // new questionObj(3, 'INDIA', 'PR', 'EMPDETAILS', 'NULL', 'prjEmail', 'Project Email', false, 2, 'input', 'email',''),
    // new questionObj(4, 'INDIA', 'PR', 'EMPDETAILS', 'NULL', 'prjType', 'Project Type', false, 2, 'input', 'number',''),
  ]

  projQustionModel: questionObj[] = [];




  configTest: FieldConfig[] = [];
  config: FieldConfig[] = [
    {
      type: 'input',
      label: 'Project name',
      name: 'projname',
      placeholder: 'Enter your Project name',
      validation: [Validators.required, Validators.minLength(4)]
    },
    {
      type: 'input',
      label: 'last name',
      name: 'lastname',
      placeholder: 'Enter your last name',
      validation: [Validators.required, Validators.minLength(4)]
    },
    {
      type: 'select',
      label: 'Project Type',
      name: 'Type',
      options: [
        { id: '1', name: 'Internal' },
        { id: '2', name: 'External' },
        { id: '3', name: 'InHouse' },
        { id: '4', name: 'Offshore' }
      ],
      placeholder: 'Select an option',
      validation: [Validators.required]
    },
    {
      type: 'Radio',
      label: 'Project Type',
      name: 'ProjType',
      options: [
        { id: 'Y', name: 'Yes' },
        { id: 'N', name: 'No' },
      ],
      placeholder: 'Select an option',
      validation: [Validators.required]
    },
    {
      type: 'Check',
      label: 'Project Type',
      name: 'ProjCheck',
      options: [
        { id: '1', name: 'Internal' },
        { id: '2', name: 'External' },
        { id: '3', name: 'InHouse' },
        { id: '4', name: 'Offshore' }
      ],
      placeholder: 'Select an option',
      validation: [Validators.required]
    },
    {
      label: 'Submit',
      name: 'submit',
      type: 'button'
    }
  ];
  showForm: boolean = false;
  Countryoptions: any;
  Cityoptions: any;
  sectionData: any;
  tabModel: any;
  selectedControls: any;
  // public theBoundCallback!: Function;
  tableData : any;
  tablePreExpData : any;


  IsVerticalTab: boolean = false;
  AlignmentSetting: any;
  TickerText: any;
  active = 0;

  constructor(private route: ActivatedRoute, private service: ControlService, private resolver: ComponentFactoryResolver) {

    // //console.log(this.config);

this.getWorkExp();

  }


  ngOnInit(): void {

    this.service.getTabAlignmentData().subscribe((data: any) => {
      if (data) {
        debugger
        this.AlignmentSetting = data.filter((tab: any) => tab.visaType == this.VisaType && tab.countryName == this.Country);
        if (this.AlignmentSetting != null && this.AlignmentSetting.length >0) {
          this.IsVerticalTab = this.AlignmentSetting[0].tabAlignment == "Vertical" ? true : false;
          this.TickerText = this.AlignmentSetting[0].tickerText;
        }
      }
    });


    // this.VisaType = sessionStorage.getItem('VISA');
    // this.Country = sessionStorage.getItem('COUNTRY');
    this.service.getApi('/GetMasterCountryInfo').subscribe((res: any) => {
      this.Countryoptions = res;
      //  this.onLoadAppControll('Proposed Clinet Details');
      var objlocalModel = {
        optSelect: '',
        optionType: 'CITY'
      }
      this.service.postApi(objlocalModel, '/GetMasterCityInformation').subscribe((res: any) => {
        this.Cityoptions = res;
        this.onLoadAppControll('Proposed Clinet Details');
      });
    });
    // this.theBoundCallback = this.getControlsForTab.bind(this);
    this.service.getApi('/GetMasterTab').subscribe((data: any) => {
      this.sectionData = data;
      this.tabModel = data.filter((tab: any) => tab.visaType == this.VisaType);
    });

    this.service.changeOption$.subscribe(option => {
      debugger;
      this.Cityoptions = option.option;
    });

    this.route.paramMap.subscribe((params: ParamMap) => {
  
      var formid = +params.get('id')

      if (params.get('id')) {
        this.getselectedFormData(params.get('id'));
      }

    })

    // this.route.queryParams.subscribe(params => {
    //   var formid = params['id'];

    //   if(formid ! = ''){
    //     this.getselectedFormData(formid);
    //   }
    // });

  }

  getselectedFormData(formid: any) {
    debugger;
    var objlocalModel = {
      formid: formid,
    }

    this.service.postApi(objlocalModel, '/GetSelectedFormData').subscribe((res: any) => {
      //this.projQustionModel = res 
      this.selectedControls = res;

      res.forEach((element: any) => {

        var dataSource = element.formJsondata;
        this.selectedControls = JSON.parse(element.formJsondata);
        // data.formId = element.formId;
        // ////console.log(data, 'data');
        // this.JSONarray.push(data);      
        // ////console.log(this.JSONarray, 'JSONarray');
        // this.TableColoums.push('formId');
        // for (var key of Object.keys(data)) {
        //   if(this.TableColoums.indexOf(key) == -1)
        //     this.TableColoums.push(key);
        // }
        // this.TableColoums = this.TableColoums.filter(
        //   (key: any, i: any) => i === this.TableColoums.indexOf(key)
        // );
      });

    });
  }

  getControlsForTab(event: any) {
    this.onLoadAppControll();
    return this.configTest;
  }

  selectTab(event: any) {
    debugger;

    this.onLoadAppControll(event.tabName);
  }

  onLoadAppControll(tabName = '') {
    this.configTest = [];
    this.projQustionModel = []
    var objlocalModel = {
      tabname: tabName,
      optionType: 'GETCONTRLS'
    }


    this.service.postApi(objlocalModel, '/GetSelectedControls').subscribe((res: any) => {
      //this.projQustionModel = res 
      var projQustionModel = res
      console.log(res);


      projQustionModel.forEach((element: any) => {
        const data = new questionObj(element.formControlsId,
          element.formControlsCountry,
          element.formControlsVisaType,
          element.formControlsSectionType,
          '', '',
          element.formControlsName,
          element.formControlsIsActive,
          element.FormControlsSequence, '',
          element.formControlsType,
          element.formControlsName, '', false, 
          element.formtabname,'',
          
          element.formtooltip,'',element.pastDate,element.featureDate)


        this.projQustionModel.push(data);
      });

      this.projQustionModel = this.projQustionModel.filter((obj) => {
        return obj.visaType === this.VisaType && obj.countryName === this.Country;
      });

      this.projQustionModel.forEach(element => {
        switch (element.type) {
          
          case 'input':
            debugger;
            const data = new questionObj(element.id, element.countryName, element.visaType, element.section,
              element.value, element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name, '', false, element.formtabname,
              '',element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(data);
            break;
          case 'select':
            var options;
            if (element.label == 'CountryName') {

              const selectdata = new questionObj(element.id, element.countryName, element.visaType, element.section,
                element.value, element.key, element.label, element.required, element.order,
                element.controlType, element.type, element.name, this.Countryoptions, false, element.formtabname,
                '',element.formtooltip,'',element.pastDate,element.featureDate
              );
              this.configTest.push(selectdata);

            } else if (element.label == 'StateName') {

              var disable = false;
              const selectdata = new questionObj(element.id, element.countryName, element.visaType, element.section,
                element.value, element.key, element.label, element.required, element.order,
                element.controlType, element.type, element.name, this.Cityoptions, disable, element.formtabname,
                '',element.formtooltip,'',element.pastDate,element.featureDate
              );
              this.configTest.push(selectdata);
            }
            break;
          case 'Radio':
            var option = [
              { id: 'Y', name: 'Yes' },
              { id: 'N', name: 'No' },
            ]
            const Radiodata = new questionObj(element.id, element.countryName, element.visaType, element.section,
              element.value, element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name, option, false, element.formtabname,
              '',element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(Radiodata);
            break;
          case 'Check':
            break;
          case 'label':
            const labeldata = new questionObj(element.id, element.countryName, element.visaType, element.section,
              'L', element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name, '', false, element.formtabname,
              '',element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(labeldata);
            break;
          case 'DatePicker':
            const DatePicker = new questionObj(element.id, element.countryName, element.visaType, element.section,
              element.value, element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name, '', false, element.formtabname,
              '',element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(DatePicker);
            break;
          case 'FileUpload':
            const FileUpload = new questionObj(element.id, element.countryName, element.visaType, element.section,
              element.value, element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name, '', false, element.formtabname,
              '',element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(FileUpload);
            break;
          case 'Table':
            
            if (element.name == 'Previous Employee Details') {           
              sessionStorage.setItem('tableName','EmployeeExperienceDetails');
              const Table = new questionObj(element.id, element.countryName, element.visaType, element.section,
                element.value, element.key, element.label, element.required, element.order,
                element.controlType, element.type, element.name, '', false, element.formtabname, this.tableData,
                element.formtooltip,'',element.pastDate,element.featureDate
              );
              this.configTest.push(Table);

            }else if(element.name == 'Previous Visa Details'){
              debugger;
              sessionStorage.setItem('tableName','EmployeePreviousVisa');
              const Table = new questionObj(element.id, element.countryName, element.visaType, element.section,
                element.value, element.key, element.label, element.required, element.order,
                element.controlType, element.type, element.name, '', false, element.formtabname, this.tablePreExpData,
                element.formtooltip,'',element.pastDate,element.featureDate
              );
              this.configTest.push(Table);
            }

            // const Table = new questionObj(element.id, element.countryName, element.visaType, element.section,
            //   element.value, element.key, element.label, element.required, element.order,
            //   element.controlType, element.type, element.name, '', false, element.formtabname
            // );
            // this.configTest.push(Table);
            break;
          default:
            break;
        }
      });

      // Default Button setting 

      const btnData = new questionObj(0, '', '', '', '', '', 'Submit', true, 100, '', 'button', 'submit');
      const btnSaveData = new questionObj(0, '', '', '', '', '', 'Save', true, 101, '', 'button', 'submit');
      this.configTest.push(btnData);

      this.configTest = this.configTest.sort((a, b) => a.order - b.order);
      this.showForm = true;



      if (this.selectedControls) {
        Object.entries(this.selectedControls).forEach(([key, value]) => {
          //Find index of specific object using findIndex method.    
          var objIndex = this.configTest.findIndex((control) => control.label.toLowerCase() === key.toLowerCase() && control.value != 'L');
          //console.log(objIndex);
          if (objIndex > 0) {
            this.configTest[objIndex].value = value;
          }
        });
      }

      this.entry.clear();
      const factory = this.resolver.resolveComponentFactory(DynamicFormComponent);
      const componentRef = this.entry.createComponent(factory);
      var cont = this.configTest.filter((control: any) => control.formtabname == tabName || control.type == 'button');
      componentRef.instance.config = cont;
      componentRef.instance.tabType = tabName;
      componentRef.instance.submit.subscribe(val => { 
         this.submit(val) })
    });
  }

  async getWorkExp() {
     await this.service.getApi('/GetAllExpe').subscribe((data: any) => { this.tableData = data; });

     await this.service.getApi('/GetPreVisa').subscribe((data: any) => { this.tablePreExpData = data; });

  }


  ngAfterViewInit() {
    if (this.form) {
      let previousValid = this.form.valid;
      this.form.changes.subscribe(() => {
        if (this.form.valid !== previousValid) {
          previousValid = this.form.valid;
          this.form.setDisabled('submit', !previousValid);
        }
        // this.form.setDisabled('StateName', true);
        // this.form.controls['firstName'].valueChanges.subscribe((value:any) => {
        //   //console.log(value);
        // });
      });

      this.form.setDisabled('submit', true);

      // this.form.controls['firstName'].valueChanges.subscribe(value => {
      //   //console.log(value);
      // });
      // this.form.setValue('name', 'Todd Motto');
    }

  }

  submit(value: { [name: string]: any }) {
    debugger;

    const visaType = {
      FormControlsName: value
    }

    // let obj = JSON.parse(value);
    var queryString = Object.keys(value).map(key => key + '=' + value[key]).join('%26');
    queryString = queryString + "%26visaType=PR%26countryType=USA"
    this.service.postSaveQues(queryString).subscribe((data: any) => {
      if (data) {

      }
    });
  }


  myTabSelectedIndexChange(event: any) {
   
    this.onLoadAppControll(event.tab.textLabel);
  }


}
