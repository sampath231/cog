import { Injectable } from '@angular/core';
import { MatDialog,MatDialogConfig } from '@angular/material/dialog';
import { ModalComponent } from '../components/modal/modal.component';
import { ControlService } from '../Service/control.service';

@Injectable({
  providedIn: 'root'
})
export class ModalService {

  Modal:any= [];
  constructor(private service : ControlService, public matDialog: MatDialog) { }
  modalAction(modalData: any) {
    switch (modalData.name) {
      case "logout":
          alert("User has logged out.");
        break;
      default:
        break;
    }
  }
  
  openModal(modalName:any,Isshowcontrols?:any) {

    this.service.getModalData(modalName).subscribe((data: any) => {
      if (data) {
        debugger
        console.log(data);
       // console.log(data[0]);
        this.Modal= data[0];
        const userId = "user01";
        const dialogConfig = new MatDialogConfig();
        // The user can't close the dialog by clicking outside its body
        dialogConfig.disableClose = true;
        dialogConfig.id = "modal-component";
        dialogConfig.height = "350px";
        dialogConfig.width = "600px";
        dialogConfig.data = {
          name: this.Modal.modalName,
          title: this.Modal.modalTitle,
          description: this.Modal.modalDescription,
          actionButtonText: this.Modal.modalButtonText,
          text1: this.Modal.modalText1,
          text2: this.Modal.modalText2,
          text3: this.Modal.modalText3,
          userId: userId,
          Isshowcontrols:Isshowcontrols?true:false
        }
        // https://material.angular.io/components/dialog/overview
        const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);

      }
    });
  }

 
  // openLogoutModal() {
  //   const userId = "user01";
  //   const dialogConfig = new MatDialogConfig();
  //   // The user can't close the dialog by clicking outside its body
  //   dialogConfig.disableClose = true;
  //   dialogConfig.id = "modal-component";
  //   dialogConfig.height = "350px";
  //   dialogConfig.width = "600px";
  //   dialogConfig.data = {
  //     name: "logout",
  //     title: "Are you sure you want to logout?",
  //     description: "Click Logout if you want to exist from the session else plese click go back",
  //     actionButtonText: "Logout",
  //     userId: userId
  //   }
  //   // https://material.angular.io/components/dialog/overview
  //   const modalDialog = this.matDialog.open(ModalComponent, dialogConfig);
  // }
}
