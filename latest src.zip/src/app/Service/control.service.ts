import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, BehaviorSubject } from 'rxjs';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class ControlService {
  baseUrl = "https://localhost:7223/api/POCTest";
  dataStore: any;
  // question : questionObj[]=[
  //   new questionObj(1,'INDIA','PR','EMPDETAILS','NULL','','',false,0,'',''),
  //   new questionObj(1,'INDIA','PR','EMPDETAILS','NULL','prjName','Project Name',false,1,'TEXT',''),
  //   new questionObj(1,'INDIA','PR','EMPDETAILS','NULL','prjEmail','Project Email',false,2,'TEXT','email'),
  //   new questionObj(1,'INDIA','PR','EMPDETAILS','NULL','prjType','Project Type',false,2,'TEXT','number'),
  // ];

  // visaType = {
  //   FormControlsId : "4",
  //   FormControlsName : "TESTAPIDATA",
  //   FormControlsType:"",
  //   FormControlsSection:"",
  //   FormControlsIsActive : "",
  //   FormControlsIsCreatedAt : "",
  //   FormControlsCountry: "",
  //   FormControlsVisaType: "",
  //   FormControlsValidationType: "",
  //   FormControlsValidationMessage: "",
  //   FormControlsClassName: "",
  //   FormControlsIsMandatory: "" 
  // }

  // private enableDisableControl$ = new BehaviorSubject<any>({
  //   controlName : '',
  //   option : false,
  // });

  private selctControlOption$ = new BehaviorSubject<any>({
    controlName: '',
    option: [],
  });

  changeOption$ = this.selctControlOption$.asObservable();

  // changeOption$ = this.enableDisableControl$.asObservable();

  constructor(private http: HttpClient) { }

  // enableOption(option: any) {
  //   this.enableDisableControl$.next(option);
  // }

  // disableOption(option: any){
  //   this.enableDisableControl$.next(option);
  // }

  postForm(formData: any) {

  }

  setControl(controlValue: any) {
    this.selctControlOption$.next(controlValue);
  }

  getApi(method: string): any {
    return this.http.get(`${this.baseUrl}` + method);
  }

  postApi(postData: any, method: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
      })
    };
    return this.http.post<any>(`${this.baseUrl}` + method, postData, httpOptions);
  }

  //   saveUser(user: any): Observable<any> {

  //     const httpOptions = { headers: new HttpHeaders({ 'Content-Type': 'application/json',
  //     'Access-Control-Allow-Origin': '*',
  //     'Access-Control-Allow-Headers': 'Content-Type',
  //     'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
  //     }) };
  //     // this.http.post<any>(`${this.baseUrl}` + '/AddTestRecords', visaType, httpOptions).subscribe({
  //     //   next: data => {
  //     //     return data;
  //     //   }, error: error => {
  //     //     console.error('There was an error!', error);
  //     //   }
  //     // });

  //     return this.http.post<any>(`${this.baseUrl}` + '/AddTestRecords', visaType,httpOptions)
  //     .pipe(
  //       // catchError(this.handleError('addHero', hero))
  //     );
  //    // return this.http.post<any>('API-URL', user).pipe(
  //       //  tap(() => this.snackbarService.openSnackbar('Changes saved')),
  //       //  catchError(() => {
  //       //     this.snackbarService.openSnackbar('Failed to save changes');
  //       //     return EMPTY;
  //       //  })
  //     );
  //  }

  getQuestions(): any {
    return this.http.get(`${this.baseUrl}` + '/GetTestRecords');
  }

  getCountry(): any {
    return this.http.get(`${this.baseUrl}` + '/GetMasterCountryInfo');
  }

  getCity(): any {
    return this.http.get(`${this.baseUrl}` + '/GetMasterCityInformation');
  }


  

  getJSONFormData(search: any): any {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
      })
    };
    debugger;
    return this.http.get(`${this.baseUrl}` + '/GetFormData?searchText=' + search, httpOptions);
  }

  postQuestions(visaType: any): any {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
      })
    };
    // this.http.post<any>(`${this.baseUrl}` + '/AddTestRecords', visaType, httpOptions).subscribe({
    //   next: data => {
    //     return data;
    //   }, error: error => {
    //     console.error('There was an error!', error);
    //   }
    // });

    return this.http.post<any>(`${this.baseUrl}` + '/AddTestRecords', visaType, httpOptions)
      .pipe(
        // catchError(this.handleError('addHero', hero))
      );
  }

  postSaveQues(visaType: any): any {
    debugger;
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
      })
    };


    return this.http.post<any>(`${this.baseUrl}` + '/SubmitJSON?objFormControl=' + visaType, httpOptions)
      .pipe(
        // catchError(this.handleError('addHero', hero))
      );
  }

  postJsonData(postData: any, country: string, visa: string) {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
      })
    };

    var objlocalModel = {
      countryType: country,
      visaType: visa,
      JsonData: JSON.stringify(postData)
    }

    return this.http.post<any>(`${this.baseUrl}` + '/SaveJSON', objlocalModel, httpOptions);
  }


  postTabSelection(Model: any): any {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
      })
    };
    return this.http.post<any>(`${this.baseUrl}` + '/SubmitTabAlignement', Model, httpOptions)
      .pipe(
        // catchError(this.handleError('addHero', hero))
      );
  }


  postTabSelectionpagination(pageNumber: number): any {
    return this.http.get(`${this.baseUrl}` + '/postTabSelectionpagination?page=' + pageNumber)
      .pipe(
        // catchError(this.handleError('addHero', hero))
      );
  }


  getTabAlignmentData(): any {
    return this.http.get(`${this.baseUrl}` + '/getTabAlignmentData');
  }

  

  getModalData(Modal:any): any {
    return this.http.get(`${this.baseUrl}` + '/getModalData?Modal='+Modal);

  }

  postModalData(Modal: any): any {

    const httpOptions = {

      headers: new HttpHeaders({

        'Content-Type': 'application/json',

        'Access-Control-Allow-Origin': '*',

        'Access-Control-Allow-Headers': 'Content-Type',

        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'

      })

    };

    return this.http.post<any>(`${this.baseUrl}` + '/postModalData', Modal, httpOptions)

      .pipe(

        // catchError(this.handleError('addHero', hero))

      );

  }

  deleteFormControl(controlId: any) {

    const httpOptions = {
      headers: new HttpHeaders({

        'Content-Type': 'application/json',

        'Access-Control-Allow-Origin': '*',

        'Access-Control-Allow-Headers': 'Content-Type',

        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
      })
    };



    return this.http.delete<any>(this.baseUrl + "?id=" + controlId);

  }




  editQuestions(newControl: any): any {

    debugger;

    const httpOptions = {
      headers: new HttpHeaders({

        'Content-Type': 'application/json',

        'Access-Control-Allow-Origin': '*',

        'Access-Control-Allow-Headers': 'Content-Type',

        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS,DELETE,PUT'
      })
    };

    

    return this.http.post<any>(this.baseUrl + '/FormControl/editControl', newControl, httpOptions);



  }

  getcontrolgrouping(id: number):any {
    return this.http.get(`${this.baseUrl}` + '/Getcontrolgrouping?parentID='+id);
  }



}
