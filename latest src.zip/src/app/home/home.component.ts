import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FieldConfig } from '../dynamic-form/models/field-config.interface';
import { questionObj } from '../QuestionModel/questionobjModel';
import { ControlService } from '../Service/control.service';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})
export class HomeComponent implements OnInit {
  Country: any = 'USA';
  VisaType: any = 'H1';
  configTest: FieldConfig[] = [];
  projQustionModel: questionObj[] = [];
  showForm: boolean = false;
  constructor(private router: Router, private service: ControlService) { }

  ngOnInit(): void {
    this.onLoadAppControll();
  }


  goToIndex() {
    this.router.navigate(['/', 'View']);
  }
  goToAboutUs() {
    this.router.navigate(['/', 'Settings']);
  }

  goToForm() {
    debugger
    // sessionStorage.setItem('COUNTRY',this.Country);
    // sessionStorage.setItem('VISA',this.VisaType);
    this.router.navigate(['/', 'View']);
  }

  onLoadAppControll() {
    debugger;
    this.configTest = [];
    // var data = sessionStorage.getItem('projQustionModel');
    // this.projQustionModel = data !== null ? JSON.parse(data) : {};

    this.service.getQuestions().subscribe((res: any) => {
      //this.projQustionModel = res 
      var projQustionModel = res
      //console.log(this.projQustionModel);

      projQustionModel.forEach((element: any) => {
        const data = new questionObj(element.FormControlsSequence,
          element.formControlsCountry,
          element.formControlsVisaType,
          element.formControlsSectionType,
          '', '',
          element.formControlsName,
          element.formControlsIsActive,
          element.FormControlsSequence, '',
          element.formControlsType,
          element.formControlsName,'',false,'', '',
          element.formtooltip,'',element.pastDate,element.featureDate)


        this.projQustionModel.push(data);
      });

      this.projQustionModel = this.projQustionModel.filter((obj) => {
        return obj.visaType === this.VisaType && obj.countryName === this.Country;
      });


      // this.projQustionModel = this.projQustionModel.filter((obj) => {
      //   return obj.visaType === this.VisaType && obj.countryName === this.Country;
      // });


      this.projQustionModel.forEach(element => {
        switch (element.type) {
          case 'input':
            const data = new questionObj(element.id, element.countryName, element.visaType, element.section,
              element.value, element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name,'' ,false ,'','',element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(data);
            break;
          case 'select':
            var option = [
              { id: '1', name: 'Internal' },
              { id: '2', name: 'External' },
              { id: '3', name: 'InHouse' },
              { id: '4', name: 'Offshore' }
            ]
            const selectdata = new questionObj(element.id, element.countryName, element.visaType, element.section,
              element.value, element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name, option, false,'', '',element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(selectdata);
            break;
          case 'Radio':
            var option = [
              { id: 'Y', name: 'Yes' },
              { id: 'N', name: 'No' },
            ]
            const Radiodata = new questionObj(element.id, element.countryName, element.visaType, element.section,
              element.value, element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name, option, false,'','', element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(Radiodata);
            break;
          case 'Check':
            break;
          case 'label':
            const labeldata = new questionObj(element.id, element.countryName, element.visaType, element.section,
              element.value, element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name, '', false,'', '',element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(labeldata);
            break;
          case 'DatePicker':
            const DatePicker = new questionObj(element.id, element.countryName, element.visaType, element.section,
              element.value, element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name,'',false,'', '',element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(DatePicker);
            break;
          case 'FileUpload':
            const FileUpload = new questionObj(element.id, element.countryName, element.visaType, element.section,
              element.value, element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name,'',false,'','', element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(FileUpload);
            break;
            case 'richtext':
            const richtext = new questionObj(element.id, element.countryName, element.visaType, element.section,
              element.value, element.key, element.label, element.required, element.order,
              element.controlType, element.type, element.name,'',false,'','', element.formtooltip,'',element.pastDate,element.featureDate
            );
            this.configTest.push(richtext);
            break;
            case 'treetext':
              const treetext = new questionObj(element.id, element.countryName, element.visaType, element.section,
                element.value, element.key, element.label, element.required, element.order,
                element.controlType, element.type, element.name,'',false,'','', element.formtooltip,'',element.pastDate,element.featureDate
              );
              this.configTest.push(treetext);
              break;
            case 'ToggleButton':
              const ToggleButton = new questionObj(element.id, element.countryName, element.visaType, element.section,
                element.value, element.key, element.label, element.required, element.order,
                element.controlType, element.type, element.name,'',false,'','', element.formtooltip,'',element.pastDate,element.featureDate
              );
              this.configTest.push(ToggleButton);
            break;
            
            case 'popup':

            const popup = new questionObj(element.id, element.countryName, element.visaType, element.section,

              element.value, element.key, element.label, element.required, element.order,

              element.controlType, element.type, element.name,'',false,'','', element.formtooltip,'',element.pastDate,element.featureDate

            );

            this.configTest.push(popup);
            break;
          default:
            break;
        }
      });

      // Default Button setting 

      const btnData = new questionObj(0, '', '', '', '', '', 'submit', true, 10, '', 'button', 'submit');
      this.configTest.push(btnData);

      this.configTest = this.configTest.sort((a, b) => a.order - b.order);
      this.showForm =true;

    });
  }

  submit(value: { [name: string]: any }) {
 
  }

}
