import { Component, OnInit } from '@angular/core';
import { ControlService } from '../Service/control.service';

@Component({
  selector: 'app-formdataview',
  templateUrl: './formdataview.component.html',
  styleUrls: ['./formdataview.component.scss']
})
export class FormdataviewComponent implements OnInit {

  searchText: any = null;
  dataSource:any;
  FormData: any;
  FormColoumns: any = [];
  TableColoums:any = [];
  country:any = null;
  visa:any =  null;
  JSONarray:any = [];
  constructor(private service: ControlService) { }

  ngOnInit(): void {
    this.getFormData();
  }

  getFormData()
  { 
    debugger;
    this.service.getJSONFormData(this.searchText).subscribe((res: any) => {
      this.FormData = [];
      this.dataSource = [];
      this.JSONarray = [];
      this.TableColoums = [];
      console.log('res',res);
      debugger;
      res.forEach((element: any) => {

        this.dataSource = element.formJsondata; 
        var data = JSON.parse(this.dataSource); 
        data.formId = element.formId; 
        //console.log(data, 'data');
        this.JSONarray.push(data);      
        //console.log(this.JSONarray, 'JSONarray');
        this.TableColoums.push('formId');
        for (var key of Object.keys(data)) {
          if(this.TableColoums.indexOf(key) == -1)
            this.TableColoums.push(key);
        }
        this.TableColoums = this.TableColoums.filter(
          (key: any, i: any) => i === this.TableColoums.indexOf(key)
        );
      });
    });
  }
  searchFormData()
  {
    //debugger;console.log(this.searchText);
    this.getFormData();
  }
}
